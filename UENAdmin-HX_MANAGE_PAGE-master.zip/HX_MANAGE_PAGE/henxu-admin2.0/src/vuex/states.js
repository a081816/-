/**
 * Created by jingna on 2018/01/01.
 */
const states = {
  contentHeight: window.document.body && window.document.body.clientHeight - 170 + 'px'
}
export default states
