/**
 * Created by jingna on 2018/01/01.
 */
const state = {
  show: false,
  url: ''
}

const mutations = {
  PUSH_PREVIEW (state, payload) {
    state.show = true
    state.url = payload
  },
  SHIFT_PREVIEW (state) {
    state.show = false
  }
}
const getters = {
  imgPreview (state) {
    return state
  }
}
const actions = {
  openPreview (contaxt, playload) {
    contaxt.commit('PUSH_PREVIEW', playload)
  },
  closePreview (contaxt) {
    contaxt.commit('SHIFT_PREVIEW')
  }
}
export default {
  state,
  mutations,
  getters,
  actions
}
