/**
 * Created by jingna on 2018/01/01.
 */
const state = {
  user: Object.assign({}, JSON.parse(window.sessionStorage.getItem('user')) || {})
}
const getters = {
  userMenu (state) {
    return state.user
  },
  userInfo (state) {
    return state.user
  },
  isAdmin () {
    return state.user && state.user.roleId === 1
  },
  isLogin (state) {
    return state.user.sysUser && state.user.sysUser.id || false
  }
}
const mutations = {
  SET_USER_INFO (state, payload) {
    state.user = payload
    window.sessionStorage.setItem('user', JSON.stringify(state.user))
  }
}
export default {
  state,
  getters,
  mutations
}
