/**
 * Created by jingna on 2018/01/01.
 */
const state = {
  show: false,
  url: ''
}

const mutations = {
  PUSH_VIDEO_PREVIEW (state, payload) {
    state.show = true
    state.url = payload
  },
  SHIFT_VIDEO_PREVIEW (state) {
    state.show = false
  }
}
const getters = {
  videoPreview (state) {
    return state
  }
}
const actions = {
  openVideoPreview (contaxt, playload) {
    contaxt.commit('PUSH_VIDEO_PREVIEW', playload)
  },
  closeVideoPreview (contaxt) {
    contaxt.commit('SHIFT_VIDEO_PREVIEW')
  }
}
export default {
  state,
  mutations,
  getters,
  actions
}
