/**
 * Created by jingna on 2018/01/01.
 */
import Vue from 'vue'
import Vuex from 'vuex'
import state from './states'
// modules
import user from './modules/user'
import loading from './modules/loading'
import breadcrumbs from './modules/breadcrumbs'
import imgPreview from './modules/imgPreview'
import videoPreview from './modules/videoPreview'
// global actions
import actions from './actions'
// global mutations
import mutations from './mutations'
Vue.use(Vuex)
export default new Vuex.Store({
  state,
  actions,
  mutations,
  modules: {
    user,
    loading,
    breadcrumbs,
    imgPreview,
    videoPreview
  }
})
