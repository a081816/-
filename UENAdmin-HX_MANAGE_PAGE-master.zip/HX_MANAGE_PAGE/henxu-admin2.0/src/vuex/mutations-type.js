/**
 * Created by jingna on 2018/01/01.
 */
// 面包屑
export const UPDATE_BREADCRUMBS_LIST = 'UPDATE_BREADCRUMBS_LIST'
