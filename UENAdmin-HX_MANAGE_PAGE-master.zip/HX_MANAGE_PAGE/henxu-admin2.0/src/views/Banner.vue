<template>
  <div>
    <section class="table-wrapper">
      <div class="panel">
        <div class="content-t">轮播图设置
          <!--若当前数据少于6条显示可添加-->
          <div class="edit">
            <Button class="editbtn  ivu-btn-primary" @click="showAddBanner" v-if="showBtn('sys:banner:add')">新增</Button>
          </div>
        </div>
      </div>
      <!--<Button type="primary" @click.native="$router.push({name: 'SystemNewBanner'})" class="new-push">新增Banner</Button>-->
      <!--<app-table ref="table" :api="$api.banner.list" :row-handle="rowHandle" :column="model"></app-table>-->
      <Table ref="selection" :columns="columns7" :data="data6"
             @on-select="onSelect" @on-select-cancel="onSelectCancel" @on-select-all="selectAll"></Table>
      <div style="margin: 30px 0 0 30px">
        <Button @click="handleSelectAll(true)" class="border-raudius4">全选</Button>
        <Button @click="handleSelectAll(false)" class="border-raudius4">取消全选</Button>
        <Button class="border-raudius4 bg-color" @click="deleteBanner" v-if="showBtn('sys:banner:del')">删除</Button>
      </div>
    </section>
    <!--banner基本信息修改-->
    <Modal v-model="showEditbanner" width="800" style="padding: 0">
      <p slot="header" style=" padding: 0">
        <span>编辑轮播图</span>
      </p>
      <div class="form" v-if="editbanner">
        <Form ref="editbanner" :model="editbanner"  :rules="ruleValidate" label-position="left" :label-width="100" style="width: 700px; margin: 0 auto">
          <FormItem label="URL："  prop="linkUrl">
            <Input v-model="editbanner.linkUrl"/>
          </FormItem>
          <FormItem label="标题：" prop="bannerName">
            <Input v-model="editbanner.bannerName" placeholder="请输入标题" />
          </FormItem>
          <FormItem label="排序：" prop="order">
            <RadioGroup v-model="editbanner.order">
              <Radio label="1"></Radio>
              <Radio label="2"></Radio>
              <Radio label="3"></Radio>
              <Radio label="4"></Radio>
              <Radio label="5"></Radio>
              <Radio label="6"></Radio>
            </RadioGroup>
          </FormItem>
          <template v-if="editbanner.imageUrl">
            <FormItem label="图片：" prop="imageUrl">
              <img-upload2 v-model="editbanner.imageUrl" :max="1"></img-upload2>
              <!--<Button class="changebtn">替换</Button>-->
            </FormItem>
          </template>
          <template v-else>
            <FormItem label="图片：" prop="imageUrl">
              <img-upload2 v-model="editbanner.imageUrl" :max="1"></img-upload2>
            </FormItem>
          </template>
        </Form>
      </div>
      <div slot="footer" id="checkBtn" v-if="edittype === 1">
        <Button  @click="addbanner('editbanner')" class="checkBtn ivu-btn-primary">确认</Button>
      </div>
      <div slot="footer"  v-else>
        <Button  @click="handleSubmit('editbanner')" class="checkBtn ivu-btn-primary">修改</Button>
      </div>
    </Modal>
  </div>
</template>
<style lang="less" rel="stylesheet/less">
  @import "../less/table";
  .table-wrapper {
    background: white;
    padding: 10px 10px;
    .table {
      width: 100%;
    }
  }
  .border-raudius4 {
    border-radius: 4px;
  }
  .bg-color {
    background-color: #e27878;
    color: #ffffff;
    font-size: 14px;
    margin-left: 20px;
  }
  .new-push {
    margin: 10px 0;
  }
  .content-t {
    font-size: 16px;
    color: #333333;
    border-bottom: 2px solid #f0f0f0;
    padding: 20px;
    position: relative;
  }
  .edit {
    position: absolute;
    bottom: 14px;
    right: 50px;
  }
  .editbtn {
    background-color: #18b566;
    border-radius: 4px;
    color: #ffffff;
    font-size: 14px;
    padding: 8px 30px;
  }
  .checkBtn {
    background-color: #3dcb9d;
    width: 130px;
    border: none;
    margin: 0 auto;
    border-radius: 3px;
    display: block;
    color: #ffffff;
    font-size: 16px;
  }
  .changebtn {
    font-size: 14px;
    color: #ffffff;
    background-color: #5ad3ac;
    border-radius: 3px;
  }
  .ivu-modal-header {
    background-color: #3dcb9d;
  }
  .ivu-modal-header p{
    color: #ffffff !important;
  }
  #checkBtn .checkBtn:hover {
    background-color: #3dcb9d;
    color: #ffffff;
  }
</style>
<script type="text/ecmascript-6">
  export default{
    data () {
      const addBannerlinkUrl = (rule, value, callback) => {
        if (value === '') {
          return callback(new Error('请输入Url'))
        } else {
          callback()
        }
      }
      const addBannerbannerName = (rule, value, callback) => {
        if (value === '') {
          return callback(new Error('请输入标题'))
        } else {
          callback()
        }
      }
      const addBannerorder = (rule, value, callback) => {
        if (value === '') {
          return callback(new Error('请选择序号'))
        } else {
          callback()
        }
      }
      const addBannerimageUrl = (rule, value, callback) => {
        if (value === '') {
          return callback(new Error('请上传图片'))
        } else {
          callback()
        }
      }
      return {
        showEditbanner: false,
        editbanner: {
          id: '',
          imageUrl: '',
          bannerName: '',
          order: '1',
          linkUrl: ''
        },
        bannerSelectId: '',
        columns7: [
          {
            type: 'selection',
            width: 60,
            align: 'center'
          },
          {
            title: 'ID',
            key: 'id',
            width: 80
          },
          {
            title: '标题',
            key: 'bannerName'
          },
          {
            title: '缩略图',
            key: 'imageUrl',
            width: 300,
            render: (h, params) => {
              if (params.row.imageUrl) {
                return h('img', {
                  style: {
                    height: '100px',
                    width: '100%',
                    padding: '10px 0'
                  },
                  attrs: {
                    src: params.row.imageUrl
                  }
                })
              } else {
                return h('span', '无缩略图')
              }
            }
          },
          {
            title: 'URL',
            key: 'linkUrl'
          },
          {
            title: '排序',
            key: 'order',
            width: 80
          },
          {
            title: '操作',
            key: 'action',
            width: 200,
            align: 'center',
            render: (h, params) => {
              let buttonSet = this.$store.state.user.user.buttonSet
              if (buttonSet.indexOf('sys:banner:edit') >= 0) {
                return h('div', [
                  h('Button', {
                    props: {
                      size: 'small'
                    },
                    style: {
                      marginRight: '5px',
                      color: '#8bd5ff',
                      border: '1px solid #8bd5ff',
                      backgroundColor: '#ffffff',
                      fontSize: '16px',
                      width: '88px'
                    },
                    on: {
                      click: () => {
                        // this.show(params.index)
                        this.showEditbanner = true
                        this.editbanner = params.row
                        this.edittype = 2
                      }
                    }
                  }, '编辑')
                ])
              } else {
                return h('span', '')
              }
            }
          }
        ],
        data6: [],
        editRow: null,
        showEditModal: false,
        edittype: '',
        ruleValidate: {
          linkUrl: [
            { validator: addBannerlinkUrl, trigger: 'blur' }
          ],
          bannerName: [
            { validator: addBannerbannerName, trigger: 'blur' }
          ],
          order: [
            { validator: addBannerorder, trigger: 'blur' }
          ],
          imageUrl: [
            { validator: addBannerimageUrl, trigger: 'blur' }
          ]
        }
      }
    },
    methods: { // 全选状态改变
      handleSelectAll (status) {
        this.$refs.selection.selectAll(status)
        if (!status) {
          this.bannerSelectId = ''
        }
      },
      onSelect (selection) { // 获取勾选的值
        console.log(selection)
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.bannerSelectId = tableId.join(',')
        console.log(this.bannerSelectId)
      },
      onSelectCancel (selection) {  // 获取取消勾选的值
        console.log(selection)
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.bannerSelectId = tableId.join(',')
        console.log(this.bannerSelectId)
      },
      selectAll (selection) { //  获取全选的值
        console.log(selection)
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.bannerSelectId = tableId.join(',')
        console.log(this.bannerSelectId)
        return tableId
      },
      deleteBanner () { // 删除传递电站id字符串
        if (this.bannerSelectId) {
          this.$Modal.confirm({
            title: '确认删除',
            content: '操作无法撤销 是否执行?',
            onOk: () => {
              this.$http.delete('/banner/' + this.bannerSelectId).then(res => {
                if (res.code === 0) {
                  this.$Message.success('删除成功')
                  this.loadData()
                }
              })
            }
          })
        } else {
          this.$Message.error('请勾选删除项')
        }
      },
      show (index) {  // 点击操作获取当前行的id
        this.$Modal.info({
          title: 'User Info',
          content: `thisId：${this.data6[index].id}`
        })
      },
      loadData () {
        this.$nextTick(() => {
          this.$http.get('/banner/list').then(res => {
            this.data6 = res.infoBannerList
          })
        })
      },
      showAddBanner () {
        console.log(this.data6)
        console.log(this.data6.length)
        if (this.data6.length >= 6) {
          this.$Message.error('最多只能添加6个banner')
        } else {
          this.showEditbanner = true
          this.editbanner = {
            id: '',
            imageUrl: '',
            bannerName: '',
            order: '',
            linkUrl: ''
          }
          this.edittype = 1
        }
      },
      getRequestParams () {
        return Object.assign({}, {id: this.editbanner.id}, {imageUrl: this.editbanner.imageUrl}, {bannerName: this.editbanner.bannerName}, {order: this.editbanner.order}, {linkUrl: this.editbanner.linkUrl})
      },
      handleSubmit (name) { // 验证通过后提交
        this.$refs[name].validate((valid) => {
          if (valid) {
            this.$http.put('/banner/' + this.editbanner.id, this.getRequestParams()).then(res => {
              if (res.code === 0) {
                this.showEditbanner = false
                this.loadData()
              }
            })
          } else {
            this.$Message.error('请填写完整信息')
          }
        })
      },
      addbanner (name) { // 验证通过后提交
        this.$refs[name].validate((valid) => {
          if (valid) {
            this.$http.post('/banner', this.editbanner).then(res => {
              if (res.code === 0) {
                this.showEditbanner = false
                this.loadData()
              }
            })
          } else {
            this.$Message.error('表单验证失败!')
          }
        })
      }
    },
    mounted () {
      this.$nextTick(() => {
        this.loadData()
      })
    }
  }
</script>
