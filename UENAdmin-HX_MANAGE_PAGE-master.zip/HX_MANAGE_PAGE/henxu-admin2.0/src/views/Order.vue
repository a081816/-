<template>
  <div>
    <section class="search-panel">
      <div class="input-wrapper">
        <div class="input-container">
          <input class="inputs" v-model="condition" @keyup.enter="loadData" placeholder="订单号/联系人姓名/联系电话/订单地址" type="text">
          <Button type="success" @click="loadData" class="searchs">搜索</Button>
        </div>
      </div>
      <!--筛选-->
      <section class="filter-panel">
        <div class="filter-wrapper">
          <div class="status-filter">
            <div class="label">支付状态: </div>
            <ul class="options">
              <li @click="payStatusCode = ''" :class="{active: payStatusCode === ''}">全部</li>
              <li @click="payStatusCode = 0" :class="{active: payStatusCode === 0}">未支付</li>
              <li @click="payStatusCode = 1" :class="{active: payStatusCode === 1}">已支付</li>
            </ul>
          </div>
          <div class="city-filter">
            <div class="floatLeft">
              <div class="label">所在地点: </div>
              <div class="select-group">
                <area-select @on-city-update="(cityId) => {form.cid = cityId}"
                             @on-province-update="(provinceId) => {form.pid = provinceId}"></area-select>
              </div>
            </div>
            <div class="floatLeft">
              <div class="label">施工进度: </div>
              <Select style="width:200px" v-model="buildStatusCode" @on-change="loadData">
                <Option
                  v-for="(item, index) in advanceList"
                  :value="index" :key="index">{{ item }}
                </Option>
              </Select>
            </div>
          </div>
        </div>
      </section>
    </section>
    <!--table-->
    <section class="table-wrapper">
      <Table ref="selection" :columns="columns7" :data="data6"
             @on-select="onSelect" @on-select-cancel="onSelectCancel" @on-select-all="selectAll"></Table>
      <div style="margin: 30px 0 0 30px">
        <Button @click="handleSelectAll(true)" class="border-raudius4">全选</Button>
        <Button @click="handleSelectAll(false)" class="border-raudius4">取消全选</Button>
        <Button class="border-raudius4 bg-color" @click="deleteOrder" v-if="showBtn('sys:order:del')">删除</Button>
      </div>
      <!--page-->
      <Page style="margin: 100px auto 0; width: 800px;text-align: center; padding-bottom: 100px" :current="tableParams.current" :page-size="tableParams.size"
            :total="tableParams.total" placement="top" show-total
            show-elevator @on-change="onChangePage"></Page>
    </section>
  </div>
</template>
<style lang="less" rel="stylesheet/less">
  @import "../less/search";
  @import "../less/filter";
  @import "../less/table";

  .table-page {
    background-color: #ffffff;
    height: 40px;
    width: 90%;
    border: none;
    margin: 20px auto;
  }
  .table-wrapper {
    background: white;
    padding: 10px 10px;
    .table {
      width: 100%;
    }
  }
  .floatLeft {
    display:block;
    float: left;
  }
  .border-raudius4 {
    border-radius: 4px;
  }
  .bg-color {
    background-color: #e27878;
    color: #ffffff;
    font-size: 14px;
    margin-left: 20px;
  }

</style>
<script type="text/ecmascript-6">
  import AreaSelect from '../components/common/area-select.vue'

  export default {
    components: {
      AreaSelect
    },
    data () {
      return {
        payStatusCode: '',
        orderCodes: '',
        buildStatusCode: '',
        tableParams: {
          size: 10,
          current: 1,
          total: 0
        },
        advanceList: [
          '未开始', '材料进场', '基础建筑', '支架安装', '光伏板安装', '直流接线', '电箱逆变器', '汇流箱安装', '交流辅线', '防雷接地测试', '并网验收'
        ],
        columns7: [
          {
            type: 'selection',
            width: 60,
            align: 'center'
          },
          {
            title: '订单号',
            key: 'orderCode'
          },
          {
            title: '联系人',
            key: 'linkmanName'
          },
          {
            title: '手机号',
            key: 'linkmanTelephone',
            width: '140'
          },
          {
            title: '装机容量',
            key: 'orderCapacity'
          },
          {
            title: '订单金额',
            key: 'orderPrice'
          },
          {
            title: '下单时间',
            key: 'orderTime'
          },
          {
            title: '支付状态',
            key: 'payStatus'
          },
          {
            title: '施工进度',
            key: 'buildStatus'
          },
          {
            title: '操作',
            key: 'action',
            width: 150,
            align: 'center',
            render: (h, params) => {
              let buttonSet = this.$store.state.user.user.buttonSet
              if (buttonSet.indexOf('sys:order:detail') >= 0) {
                return h('div', [
                  h('Button', {
                    props: {
                      type: 'primary',
                      size: 'small'
                    },
                    style: {
                      marginRight: '5px',
                      border: '1px soild #3dcb9d',
                      color: '#3dcb9d',
                      backgroundColor: '#ffffff',
                      borderRadius: '3px'
                    },
                    on: {
                      click: () => {
                        this.show(params.index)
                      }
                    }
                  }, '订单详情')
                ])
              } else {
                return h('span', '')
              }
            }
          }
        ],
        data6: [],
        form: {
          pid: '',
          cid: ''
        },
        condition: '',
        list: [],
        provinceList: [],
        tableId: [],
        rowClick: (row) => {
          this.$router.push({name: 'StationDetail', query: {id: row.id}})
        }
      }
    },
    watch: {
      'form.cid': function (val) {
        this.loadData()
      },
      'form.pid': function (val) {
        this.loadData()
      },
      payStatusCode () {
        this.loadData()
      }
    },
    computed: {
      customParams () {
        let list = []
        Object.keys(this.form).forEach(key => {
          list.push({
            key: key,
            value: this.form[key]
          })
        })
        return list
      }
    },
    methods: { // 全选状态改变
      handleSelectAll (status) {
        this.$refs.selection.selectAll(status)
        if (!status) {
          this.orderSelectCode = ''
        }
      },
      onSelect (selection) { // 获取勾选的值
        let orderCode = []
        Object(selection).forEach(key => {
          orderCode.push(key.orderCode)
        })
        this.orderSelectCode = orderCode.join(',')
        console.log(this.orderSelectCode)
        return orderCode
      },
      onSelectCancel (selection) {  // 获取取消勾选的值
        let orderCode = []
        Object(selection).forEach(key => {
          orderCode.push(key.orderCode)
        })
        this.orderSelectCode = orderCode.join(',')
        console.log(this.orderSelectCode)
        return orderCode
      },
      selectAll (selection) { //  获取全选的值
        let orderCode = []
        Object(selection).forEach(key => {
          orderCode.push(key.orderCode)
        })
        this.orderSelectCode = orderCode.join(',')
        console.log(this.orderSelectCode)
        return orderCode
      },
      deleteOrder () { // 删除传递电站id字符串
        if (this.orderSelectCode) {
          this.$Modal.confirm({
            title: '确认删除',
            content: '操作无法撤销 是否执行?',
            onOk: () => {
              this.$http.delete('/order/' + this.orderSelectCode, {orderCodes: this.orderSelectCode}).then(res => {
                if (res.code === 0) {
                  this.$Message.success('删除成功')
                  this.loadData()
                }
              })
            }
          })
        } else {
          this.$Message.error('请勾选删除项')
        }
      },
      show (index) {  // 点击操作获取当前行的id
        console.log(this.data6[index].orderCode)
        this.$router.push({name: 'OrderDetail', query: {orderCode: this.data6[index].orderCode}})
      },
      getRequestParams () {
        return Object.assign({}, {
          current: this.tableParams.current - 1,
          size: this.tableParams.size
        }, this.form, {buildStatusCode: this.buildStatusCode}, {condition: this.condition}, {payStatusCode: this.payStatusCode})
      },
      onChangePage (page) {
        // 改变页码
        this.tableParams.current = page
        this.loadData()
      },
      loadData () {
        this.$nextTick(() => {
          this.$http.get('/order/page/' + this.tableParams.current, {params: {pid: this.form.pid, cid: this.form.cid, buildStatusCode: this.buildStatusCode, payStatusCode: this.payStatusCode, condition: this.condition}}).then(res => {
            this.data6 = res.vOrderInfoStatusPage.records
            this.tableParams.current = res.vOrderInfoStatusPage.current
            this.tableParams.size = res.vOrderInfoStatusPage.size
            this.tableParams.total = res.vOrderInfoStatusPage.total
          })
        })
      }
    },
    mounted () {
      this.loadData()
    }
  }
</script>
