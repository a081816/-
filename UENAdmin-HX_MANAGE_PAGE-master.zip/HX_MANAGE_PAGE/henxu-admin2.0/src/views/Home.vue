<template>
  <div>
    <Row class="cards" type="flex" justify="space-between">
      <i-col class="item power-info" shadow span="4">
        <Row class="cards">
          <i-col span="16">
            <p class="pstyle">用户总数(个)</p>
            <h3 class="htyle3">{{userTotal}}</h3>
          </i-col>
          <i-col span="8">
            <img class="cell-icon" :src="require('@/assets/Home/home1.png')" alt="" width="100%">
          </i-col>
        </Row>
      </i-col>
      <i-col class="item power-info" shadow span="4">
        <Row class="cards">
          <i-col span="16">
            <p class="pstyle">订单总数(个)</p>
            <h3 class="htyle3">{{orderTotal}}</h3>
          </i-col>
          <i-col span="8">
            <img class="cell-icon" :src="require('@/assets/Home/home2.png')" alt="" width="100%">
          </i-col>
        </Row>
      </i-col>
      <i-col class="item power-info" shadow span="4">
        <Row class="cards">
          <i-col span="16">
            <p class="pstyle">装机容量(KW)</p>
            <h3 class="htyle3">{{capacityTotal}}</h3>
          </i-col>
          <i-col span="8">
            <img class="cell-icon" :src="require('@/assets/Home/home3.png')" alt="" width="100%">
          </i-col>
        </Row>
      </i-col>
      <i-col class="item power-info" shadow span="4">
        <Row class="cards">
          <i-col span="16">
            <p class="pstyle">电站总数(个)</p>
            <h3 class="htyle3">{{stationTotal}}</h3>
          </i-col>
          <i-col span="8">
            <img class="cell-icon" :src="require('@/assets/Home/home4.png')" alt="" width="100%">
          </i-col>
        </Row>
      </i-col>
      <i-col class="item power-info" shadow span="4" style="background-color: #ffffff">
        <Row class="cards">
          <i-col span="16">
            <p class="pstyle">发电总量(KWH)</p>
            <h3 class="htyle3">{{kwhTotal}}</h3>
          </i-col>
          <i-col span="8">
            <img class="cell-icon" :src="require('@/assets/Home/home5.png')" alt="" width="100%">
          </i-col>
        </Row>
      </i-col>
    </Row>
    <Row :gutter="32" class="cards2">
      <i-col  span="12">
        <newOrde></newOrde>
      </i-col>
      <i-col  span="12" style="padding-right: 0">
        <newFault></newFault>
      </i-col>
    </Row>
    <Row :gutter="32" class="cards2">
      <i-col  span="12">
        <newUser></newUser>
      </i-col>
      <i-col  span="12" style="padding-right: 0">
        <newStation></newStation>
      </i-col>
    </Row>
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
  .cards {
    height: 120px;
    box-sizing: border-box;
    margin-bottom: 10px;
    &.second {
      background-color: #ffffff;
    }
    .item {
      padding: 30px;
      background: white;
      height: 100%;
      border-radius: 4px;
      .pstyle {
        font-size: 14px;
        color: #666666;
      }
      .htyle3{
        font-size: 26px;
        color: #ff7800;
      }
    }
  }
  .cards2 {
    box-sizing: border-box;
    margin-top: 30px;
    margin-right: 0 !important;
    .content {
      background-color: #ebfff9;
      padding-bottom: 36px;
      box-sizing: border-box;
      border-radius: 4px;
      .content_t {
        box-sizing: border-box;
        height: 60px;
        padding: 20px;
        color: #ffffff;
        font-size: 16px;
        background-color: #3dcb9d;
        position: relative;
        .more {
          position: absolute;
          top: 20px;
          right: 20px;
          a {
            color: #ffffff;
          }
        }
      }
      .content_b {
        background-color: #ffffff;
      }
    }
  }
</style>
<script type="text/ecmascript-6">
  import newOrde from '../components/Home/newOrde.vue'
  import newFault from '../components/Home/newFault.vue'
  import newUser from '../components/Home/newUser.vue'
  import newStation from '../components/Home/newStation.vue'

  export default {
    components: {
      newOrde,
      newFault,
      newUser,
      newStation
    },
    data () {
      return {
        userTotal: '',
        orderTotal: '',
        capacityTotal: '',
        stationTotal: '',
        kwhTotal: ''
      }
    },
    methods: {
      initData () {
        // 今日发电量
        this.$http.get('/index/total').then(res => {
          this.userTotal = res.userTotal
          this.kwhTotal = res.kwhTotal
          this.capacityTotal = res.capacityTotal
          this.stationTotal = res.stationTotal
          this.orderTotal = res.orderTotal
        })
      }
    },
    mounted () {
      this.initData()
    }
  }
</script>
