<template>
  <div>
    <!--电站基本信息-->
    <section class="panel">
      <div class="content-t">电站基本信息</div>
      <Row class="info-row bgf8fffd">
        <i-col :span="12">
          <div class="label">电站ID</div>
          <template>
            <span class="showdetail">{{thisStationInfo.id}}</span>
          </template>
        </i-col>
        <i-col :span="12">
          <div class="label">建站地址</div>
          <template>
            <span class="showdetail">{{thisStationInfo.stationAddress}}</span>
          </template>
        </i-col>
      </Row>
      <Row class="info-row">
        <i-col :span="12">
          <div class="label">装机容量</div>
          <template>
            <span class="showdetail">{{thisStationInfo.stationCapacity}}KW</span>
          </template>
        </i-col>
        <i-col :span="12">
          <div class="label">电站状态</div>
          <template>
            <span class="showdetail">{{thisStationInfo.stationStatus}}</span>
          </template>
        </i-col>
      </Row>
      <Row class="info-row bgf8fffd">
        <i-col :span="12">
          <div class="label">联系人</div>
          <template>
            <span class="showdetail">{{thisStationInfo.linkmanName}}</span>
          </template>
        </i-col>
        <i-col :span="12">
          <div class="label">联系电话</div>
          <template>
            <span class="showdetail">{{thisStationInfo.linkmanTelephone}}</span>
          </template>
        </i-col>
      </Row>
      <Row class="info-row" v-if="showBtn('sys:station:ammeterEdit')">
        <i-col :span="24">
          <div class="label">电表码</div>
          <template v-if="showammeter">
            <span class="showdetail">{{thisStationInfo.ammeterCode}}</span>
            <Button class="editbtn1 ivu-btn-primary" @click="showammeter = false"  style="margin-left: 30px">绑定电表</Button>
          </template>
          <template v-else>
            <input v-model="thisammeterCode" placeholder="请输入电表码"/>
            <Button class="editbtn1 ivu-btn-primary" @click="editammeter"  style="margin-left: 30px">确认</Button>
          </template>
        </i-col>
      </Row>
    </section>
    <!--订单材料清单-->
    <section class="panel">
      <div class="content-t">订单材料清单</div>
      <Row class="info-row bgf8fffd">
        <i-col :span="12">
          <div class="label">逆变器</div>
          <template>
            <span class="showdetail">三晶 6K（220V/50HZ）</span>
            <!--<span class="edit-btn" @click="showInverterSelect = true">修改</span>-->
          </template>
        </i-col>
        <i-col :span="12">
          <div class="label">电池板</div>
          <template>
            <span class="showdetail">南玻 CSG280-22</span>
            <!--<span class="edit-btn" @click="showBatterySelect = true">修改</span>-->
          </template>
        </i-col>
      </Row>
      <Row class="info-row">
        <i-col :span="12">
          <div class="label">保修年限</div>
          <template>
            <span class="showdetail">10年</span>
          </template>
        </i-col>
        <i-col :span="12">
          <div class="label">其他材料</div>
          <template>
            <span class="showdetail">汇流箱、监控器、防雷系统、支架钢材</span>
          </template>
        </i-col>
      </Row>
      <Row class="info-row bgf8fffd">
        <div class="label">选配项目</div>
        <template>
          <span class="showdetail">清洗服务、每年上门检查2次</span>
          <!--<span class="edit-btn" @click="showApolegamyDetail = true">查看详情</span>-->
        </template>
      </Row>
    </section>
    <!--发电折线图-->
    <section class="panel">
      <div class="content-t1">电量折线图
        <div class="chEcharts">
          <Row>
            <i-col :span="12" class="tab-item" @click.native="type=1" :class="{active: type===1}">发电折线图</i-col>
            <i-col :span="12" class="tab-item" @click.native="type=2" :class="{active: type===2}">用电折线图</i-col>
          </Row>
        </div>
      </div>
      <div class="showcharts">
        <!--发电记录-->
        <section class="panel" v-if="type===1">
          <generation-record-charts @on-click="handlerClick" :style="{height: (448 - 60) + 'px'}"
                                    :dataList="chartDataList"></generation-record-charts>
        </section>
        <!--用电记录-->
        <section class="panel" v-if="type===2">
          <electricity-record-charts @on-click="handlerClick" :style="{height: (448 - 60) + 'px'}"
                                     :dataList="chartDataList"></electricity-record-charts>
        </section>
        <!--<div id="generation-record-charts" style="width: 1000px; height: 500px; margin: 0 auto"></div>-->
      </div>
    </section>
    <!--列表-->
    <section class="tabs" style="margin-top: 30px">
      <Row>
        <i-col class="tab-item" :class="{'active': tabActive === 1}" @click.native="tabActive = 1" :span="3">电量详情列表
        </i-col>
        <i-col class="tab-item" :class="{'active': tabActive === 2}" @click.native="tabActive = 2" :span="3">故障列表
        </i-col>
      </Row>
    </section>
    <section class="filter">
      <Row>
        <i-col :span="12" style="text-align: center">
          <Date-picker type="daterange" placement="bottom-start" :value="[queryStartDtm, queryEndDtm]"
                       @on-change="changeDateRange" placeholder="选择日期"
                       style="width: 200px"></Date-picker>
          <Button type="primary" @click.native="selectloadData">时间段查询</Button>
        </i-col>
        <i-col :span="12">
          <Date-picker type="year" placeholder="选择年" @on-change="changeYear" style="width: 200px"></Date-picker>
          <Button type="primary" @click.native="selectloadData">年份查询</Button>
        </i-col>
      </Row>
    </section>
    <section class="table-wrapper" v-if="tabActive===1">
      <Table ref="selection" :columns="columns1" :data="data"></Table>
      <!--page-->
      <div class="table-page">
        <Page style="margin: 100px auto 0; width: 800px;text-align: center; padding-bottom: 100px" :current="pageParams.current" :page-size="pageParams.pageSize"
              :total="pageParams.total" placement="top" show-total
              show-elevator @on-change="onChangePage"></Page>
      </div>
    </section>
    <section class="table-wrapper" v-if="tabActive===2">
      <Table ref="table" :columns="columns2" :data="data2"></Table>
      <!--page-->
      <div class="table-page">
        <Page style="margin: 100px auto 0; width: 800px;text-align: center; padding-bottom: 100px" :current="pageParams1.current" :page-size="pageParams1.pageSize"
              :total="pageParams1.total" placement="top" show-total
              show-elevator @on-change="onChangePage1"></Page>
      </div>
    </section>
  </div>
</template>
<style  lang="less" rel="stylesheet/less">
  @import "../../less/table";
  .cards {
    height: 448px;
    box-sizing: border-box;
    margin-bottom: 10px;
    &.second {
      height: 380px;
    }
    .item {
      background: white;
      height: 100%;
      &.large {
        padding: 0 16px;
        box-sizing: inherit;
        background: transparent;
        .inner-container {
          width: 100%;
          height: 100%;
          background: white;
        }
      }
      &.business-database {
        .middle-wrapper {
          padding: 10px;
          height: 320px;
          .inner-container {
            background: #f6f6f6;
            position: relative;
            .info-box {
              width: 100%;
              align-self: center;
              flex: 1;
              padding-top: 20px;
              padding-left: 20px;
              text-align: left;
              .number {
                color: #ffd082;
                font-size: 22px;
              }
              .desc {
                color: #8b8b8b;
                font-size: 16px;
              }
            }
            .bg {
              position: absolute;
              right: 20px;
              bottom: 20px;
            }
          }
        }
        .card-group {
          height: 320px;
          padding: 10px;
          .inner-card {
            height: 140px;
            background: #f6f6f6;
            display: flex;
            padding: 10px;
            &:last-child {
              margin-top: 20px;
            }
            .img-wrapper {
              flex: 0 0 60px;
              align-self: center;
              margin-left: 20px;
              img {
                width: 100%;
                height: auto !important;
              }
            }
            .text {
              align-self: center;
              flex: 1;
              padding-right: 20px;
              text-align: right;
              .number {
                color: #ffd082;
                font-size: 22px;
              }
              .desc {
                color: #8b8b8b;
                font-size: 16px;
              }
            }
          }
        }
      }
      &:last-child {
        background: transparent;
        padding-right: 0;
      }
    }
  }
  .content-t {
    font-size: 16px;
    color: #333333;
    border-bottom: 2px solid #18b566;
    padding: 20px;
  }
  .content-t1 {
    font-size: 16px;
    color: #333333;
    padding: 20px;
    border-bottom: 2px solid #f0f0f0;
    position: relative;
  }
  .chEcharts {
    position: absolute;
    bottom: 0;
    right: 20px;
    .tab-item {
      background: white;
      line-height: 30px;
      padding: 10px;
      font-size: 18px;
      text-align: center;
      cursor: pointer;
      position: relative;
      &.active {
        border-bottom: 4px solid #3dcb9d;
        color: #3dcb9d;
        &:after {
          width: 0;
        }
      }
    }
  }
  .bgf8fffd {
    background-color: #f8fffd;
  }
  .edit-btn {
    color: #90a2ca;
    padding: 0 10px;
    cursor: pointer;
  }

  .tabs {
    background: white;
    margin-bottom: 15px;
    .tab-item {
      padding: 10px 0;
      text-align: center;
      position: relative;
      color: #b2b2b2;
      font-size: 14px;
      cursor: pointer;
      &:after {
        content: ' ';
        width: 1px;
        height: 20px;
        display: block;
        position: absolute;
        right: 0;
        top: 10px;
        background: #d2d2d2;
      }
      &:last-child {
        &:after {
          width: 0;
        }
      }
      &.active {
        background: #3dcb9d;
        color: white;
        &:after {
          width: 0;
        }
      }
    }
  }

  .table-wrapper {
    background: white;
    padding: 10px;
    margin-bottom: 20px;
  }

  .filter {
    margin: 15px 0;
    background: white;
    padding: 10px;
  }

  .info-row {
    border-bottom: 1px solid #f2f2f2;
    padding: 10px 15px;
    font-size: 16px;
    color: #b6b6b6;
    .label {
      width: 200px;
      display: inline-block;
      color: #999999;
    }
    .showdetail {
      color: #666666;
    }
  }

  .panel {
    background: white;
    margin-bottom: 30px;
  }

  .info-list {
    width: 100%;
    padding: 15px;
    .info-group {
      font-size: 18px;
      li {
        color: #b6b6b6;
        padding: 15px 0;
        border-bottom: 1px solid #dedede;
        width: 100%;
        &:last-child {
          border: none;
        }
        .label {
          width: 40%;
          display: inline-block;
        }
        .value {
          width: 60%;
          display: inline;
        }
      }
      &.without-border {
        li {
          padding: 3px 0;
          border: none;
        }
      }
    }
  }
  .showcharts {
    background-color: #fdfffe;
    padding: 20px 0;
  }
  .editbtn1 {
    background-color: #18b566;
    border-radius: 4px;
    color: #ffffff;
    font-size: 14px;
    padding: 3px 20px;
  }
</style>
<script type="text/ecmascript-6">
  import recordYear from '../../components/Station/record-year-charts.vue'
  import GenerationRecordCharts from '../../components/Station/generation-record-charts.vue'
  import ElectricityRecordCharts from '../../components/Station/electricity-record-charts.vue'
  const echarts = require('echarts')
  const theme = require('@/assets/echarts-theme.json')

  export default {
    components: {
      GenerationRecordCharts,
      ElectricityRecordCharts,
      recordYear
    },
    data () {
      return {
        type: 1,
        station: null,
        station1: null,
        stationUsrId: this.$route.query.id,
        stationInfo: null,
        showBatterySelect: false,
        showInverterSelect: false,
        form: {
          dAddr: '',
          stationId: this.$route.query.id,
          type: ''
        },
        queryEndDtm: '',
        queryStartDtm: '',
        queryYear: '',
        dAddrs: [],
        showMaterialDetail: false,
        showApolegamyDetail: false,
        tabActive: 1,
        chartDataList: [],
        thisStationInfo: '',
        dataList: [
          {
            createDtm: '2016年',
            kwh: '10.1'
          },
          {
            createDtm: '2017年',
            kwh: '180.1'
          },
          {
            createDtm: '2018年',
            kwh: '500'
          }
        ],
        dataList1: [
          {
            createDtm: '1月',
            kwh: '10.1'
          },
          {
            createDtm: '2月',
            kwh: '180.1'
          },
          {
            createDtm: '3月',
            kwh: '500'
          },
          {
            createDtm: '4月',
            kwh: '10.1'
          },
          {
            createDtm: '5月',
            kwh: '180.1'
          },
          {
            createDtm: '6月',
            kwh: '500'
          },
          {
            createDtm: '7月',
            kwh: '10.1'
          },
          {
            createDtm: '8月',
            kwh: '180.1'
          },
          {
            createDtm: '9月',
            kwh: '500'
          },
          {
            createDtm: '10月',
            kwh: '10.1'
          },
          {
            createDtm: '11月',
            kwh: '180.1'
          },
          {
            createDtm: '12月',
            kwh: '500'
          }
        ],
        dataList2: [
          {
            createDtm: '01日',
            kwh: '10.1'
          },
          {
            createDtm: '02日',
            kwh: '180.1'
          },
          {
            createDtm: '03日',
            kwh: '500'
          },
          {
            createDtm: '04日',
            kwh: '10.1'
          },
          {
            createDtm: '05日',
            kwh: '180.1'
          },
          {
            createDtm: '06日',
            kwh: '500'
          }
        ],
        dataList3: [
          {
            createDtm: '0时',
            kwh: '10.1'
          },
          {
            createDtm: '1时',
            kwh: '180.1'
          },
          {
            createDtm: '2时',
            kwh: '500'
          }
        ],
        plan: 0,
        params: {
          stationId: this.$route.query.id,
          type: '1',
          dateStr: 20,
          plan: 0
        },
        busying: false,
        plan_id: '',
        tableHandlemethoers: ['handleSelectAll'],
        columns1: [
          {
            title: '电站码',
            key: 'ammeterCode'
          },
          {
            title: '电量类型',
            key: 'elecType',
            filter: {
              '1': '发电',
              '2': '用电'
            },
            render: (h, params) => { // 根据值过滤
              const row = params.row.elecType
              const column = params.column.filter
              return h('span', column[row])
            }
          },
          {
            title: '当日电量kwh',
            key: 'kwh'
          },
          {
            title: '创建时间',
            key: 'recordTime'
          }
        ],
        columns2: [
          {
            title: '电站码',
            key: 'ammeterCode'
          },
          {
            title: '发生时间',
            key: 'recordTime'
          },
          {
            title: '故障原因',
            key: 'statusCodeDesc'
          },
          {
            title: '持续时间(分)',
            key: 'duration'
          }
        ],
        data: [
          {
            id: '1',
            ammeterCode: '123456',
            devConfCode: '1',
            kwh: '2016',
            createDtm: '2017/01/01'
          },
          {
            id: '2',
            ammeterCode: '654321',
            devConfCode: '2',
            kwh: '2016',
            createDtm: '2017/01/01'
          },
          {
            id: '3',
            ammeterCode: '123456',
            devConfCode: '1',
            kwh: '2016',
            createDtm: '2017/01/01'
          }
        ],
        data2: [
          {
            stationtime: '2017/01/01',
            dAddr: '故障原因',
            dType: '20'
          },
          {
            stationtime: '2017/01/02',
            dAddr: '故障原因2',
            dType: '10'
          }
        ],
        pageParams: {
          pageSize: 10,
          current: 1,
          total: 0
        },
        pageParams1: {
          pageSize: 10,
          current: 1,
          total: 0
        },
        xArea: [],
        realKwh: [],
        myChart: null,
        stationId: null,
        onclickNum: 0,
        showammeter: true,
        thisammeterCode: ''
      }
    },
    computed: {
      fullParams () {
        return [
          ...[
            {
              key: 'queryEndDtm',
              value: this.queryEndDtm
            },
            {
              key: 'queryStartDtm',
              value: this.queryStartDtm
            }
          ],
          ...this.customParams
        ]
      },
      customParams () {
        let list = []
        Object.keys(this.form).forEach(key => {
          list.push({
            key: key,
            value: this.form[key]
          })
        })
        return list
      }
    },
    watch: {
      tabActive () {
        this.params.plan = 0
        this.loadChartData()
        this.loadfaultData()
      },
      customParams () {
        this.$nextTick(() => {
          this.$refs.table.loadData()
        })
      },
      type () {
        this.$nextTick(() => {
          this.loadChartData()
        })
      },
      xArea: 'renderCharts',
      realKwh: 'renderCharts',
      wantKwh: 'renderCharts'
    },
    methods: {
      editammeter () {
        this.$http.put('/station/ammeter/' + this.$route.query.stationCode, {ammeterCode: this.thisammeterCode}).then(res => {
          if (res.code === 0) {
            this.$Message.success('操作成功')
            this.showammeter = true
            this.loadinfoData()
          } else {
            this.$Message.error(res.msg)
          }
        })
      },
      loadChartData () {
        if (this.$route.query.stationCode) {
          this.chartDataList = []
          this.$http.get('elecData/list/' + this.$route.query.stationCode, {params: {stationCode: this.$route.query.stationCode, elecType: this.type}}).then(res => {
            this.chartDataList = res.elecDataList
          })
        }
      },
      handlerClick (params) {
        if (this.busying) {
          return
        }
        if (this.onclickNum < 3) {
          this.onclickNum++
          this.busying = true
          this.$http.get('elecData/list/' + this.$route.query.stationCode, {params: params}).then(res => {
            this.chartDataList = res.elecDataList
            this.busying = false
          }).catch(() => {
            this.busying = false
          })
        } else {
          this.onclickNum = 0
          this.busying = true
          this.$http.get('elecData/list/' + this.$route.query.stationCode, {params: {stationCode: this.$route.query.stationCode, elecType: this.type}}).then(res => {
            this.chartDataList = res.elecDataList
            this.busying = false
          }).catch(() => {
            this.busying = false
          })
        }
      },
      initData () {
        let xArea = []
        let realKwh = []
        switch (this.type) {
          case 1:
            this.dataList1.forEach((column) => {
              xArea.push(column.createDtm)
              realKwh.push(column.kwh)
            })
            break
          case 2:
            this.dataList2.forEach((column) => {
              xArea.push(column.createDtm)
              realKwh.push(column.kwh)
            })
            break
          case 3:
            this.dataList3.forEach((column) => {
              xArea.push(column.createDtm)
              realKwh.push(column.kwh)
            })
            break
          default:
            this.dataList.forEach((column) => {
              xArea.push(column.createDtm)
              realKwh.push(column.kwh)
            })
        }
        this.xArea = xArea
        this.realKwh = realKwh
        this.renderCharts()
      },
      renderCharts () {
        echarts.registerTheme('macarons', theme)
        if (!this.myChart) {
          this.myChart = echarts.init(document.getElementById('generation-record-charts'), 'macarons')
        }
        // 绘制图表
        this.myChart.setOption({
          dataZoom: {
            xAxisIndex: 0,
            filterMode: 'weakFilter'
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'cross',
              crossStyle: {
                color: '#999'
              }
            }
          },
          legend: {
            data: ['实际发电量']
          },
          xAxis: [
            {
              type: 'category',
              data: this.xArea,
              axisPointer: {
                type: 'shadow'
              }
            }
          ],
          yAxis: [
            {
              type: 'value',
              name: 'kwh',
              min: 0,
              axisLabel: {
                formatter: '{value} kwh'
              }
            }
          ],
          series: [
            {
              name: '实际发电量',
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#9ed39f'
                }
              },
              data: this.realKwh
            }
          ]
        })
      },
      onChangePage (page) {
        // 改变页码
        this.pageParams.current = page
        this.loadData()
      },
      onChangePage1 (page) {
        // 改变页码
        this.pageParams1.current = page
        this.loadfaultData()
      },
      updateBattery (battery) {
        this.$Modal.confirm({
          title: '确认更新吗',
          content: '操作无法撤销 是否执行?',
          onOk: () => {
            this.$http.post('orderPlan/save', Object.assign({}, this.station && this.station.order && this.station.order.orderPlan, {
              batteryBoardId: battery.id,
              id: this.plan_id,
              batteryBoardBrand: battery.brandName,
              batteryBoardModel: battery.model
            })).then(res => {
              if (res.code === 200) {
                this.showBatterySelect = false
                this.$Message.success('更新成功!')
                window.location.reload()
              }
            })
          }
        })
      },
      updateInverter (inverter) {
        this.$Modal.confirm({
          title: '确认更新吗',
          content: '操作无法撤销 是否执行?',
          onOk: () => {
            this.$http.post('orderPlan/save', Object.assign({}, this.station && this.station.order && this.station.order.orderPlan, {
              inverterId: inverter.id,
              id: this.plan_id,
              inverterBrand: inverter.brandName,
              inverterModel: inverter.model
            })).then(res => {
              if (res.code === 200) {
                this.showInverterSelect = false
                this.$Message.success('更新成功!')
                window.location.reload()
              }
            })
          }
        })
      },
      getApolegamyText (apolegamys, detail = false) {
        if (detail) {
          return apolegamys
        } else {
          return apolegamys.substr(0, apolegamys.length - 1)
        }
      },
      getMaterialText (text, detail = false) {
        let materials = JSON.parse(text)
        if (detail) {
          return materials
        } else {
          let resultStr = ''
          if (materials) {
            materials.forEach((material) => {
              resultStr += material.devideName + '、'
            })
            return resultStr.substr(0, resultStr.length - 1)
          } else {
            return materials
          }
        }
      },
      changeYear (year) {
        this.queryYear = year
        this.changeDateRange([year + '-01-01', year + '-12-30'])
      },
      changeDateRange (time) {
        if (time && time.length === 2 && time[0] && time[1]) {
          this.queryStartDtm = time[0]
          this.queryEndDtm = time[1]
        } else {
          this.queryStartDtm = null
          this.queryEndDtm = null
        }
      },
      rowClick (row) {
        console.log('temStation item click')
      },
      loadData () {
        this.$nextTick(() => {
          if (this.$route.query.stationCode) {
            this.$http.get('/elecData/page/' + this.pageParams.current, {params: {current: this.pageParams.current, stationCode: this.$route.query.stationCode, startDate: this.queryStartDtm, endDate: this.queryEndDtm}}).then(res => {
              if (res.code === 0) {
                this.data = res.elecDataPage.records
                this.pageParams.current = res.elecDataPage.current
                this.pageParams.total = res.elecDataPage.total
              }
            })
          } else {
            this.$Message.error('请重新选择电站')
          }
        })
      },
      loadinfoData () {
        this.$nextTick(() => {
          if (this.$route.query.stationCode) {
            this.$http.get('/station/' + this.$route.query.stationCode, {params: {stationCode: this.$route.query.stationCode}}).then(res => {
              if (res.code === 0) {
                this.thisStationInfo = res.stationInfo
                this.thisammeterCode = res.stationInfo.ammeterCode
              }
            })
          } else {
            this.$Message.error('请重新选择电站')
          }
        })
      },
      loadfaultData () { // 故障列表
        this.$nextTick(() => {
          if (this.$route.query.stationCode) {
            this.$http.get('/ammeter/status/page/' + this.pageParams1.current, {params: {current: this.pageParams1.current, stationCode: this.$route.query.stationCode, startDate: this.queryStartDtm, endDate: this.queryEndDtm}}).then(res => {
              if (res.code === 0) {
                this.data2 = res.vAmmeterStatusRecordPage.records
                this.pageParams1.current = res.vAmmeterStatusRecordPage.current
                this.pageParams1.total = res.vAmmeterStatusRecordPage.total
              }
            })
          } else {
            this.$Message.error('请重新选择电站')
          }
        })
      },
      selectloadData () { // 判定是电量列表还是故障列表的筛选
        if (this.tabActive === 1) {
          this.loadData()
        } else {
          this.loadfaultData()
        }
      }
    },
    mounted () {
      this.$nextTick(() => {
        // this.initData()
        this.loadData()
        this.loadinfoData()
        this.loadfaultData()
        this.loadChartData()
      })
    }
  }
</script>
