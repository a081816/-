<template>
  <div>
    <Modal v-model="showEditModal" title="参数编辑" @on-ok="saveDevice">
      <template>
        <Row>
          <Row style="margin-bottom: 30px">
            <i-col :span="5" class="label">参数名称: </i-col>
            <i-col :span="16" class="value">
              <i-input></i-input>
            </i-col>
          </Row>
          <Row style="margin-bottom: 30px">
            <i-col :span="5" class="label">参数值: </i-col>
            <i-col :span="16" class="value">
              <i-input></i-input>
            </i-col>
          </Row>
          <Row style="margin-bottom: 30px">
            <i-col :span="5" class="label">备注说明: </i-col>
            <i-col :span="16" class="value">
              <i-input type="textarea" :rows="4"></i-input>
            </i-col>
          </Row>
        </Row>
      </template>
    </Modal>
    <section class="panel device-list">
      <template>
        <div class="title">
          电站管理系统参数
          <div class="addbtn">
            <Button class="btn" @click="showEditModal = true">新增参数</Button>
            <!--<Button class="btn" @click.native="showDevice(null, device)">展开</Button>-->
          </div>
        </div>
        <div>
          <div class="table-wrapper">
            <table class="order-detail">
              <thead>
              <tr>
                <th style="padding-left: 30px">参数</th>
                <th>参数值</th>
                <th>备注说明</th>
                <th>操作</th>
              </tr>
              </thead>
              <tbody class="table-style">
              <tr>
                <td style="padding-left: 30px">打发第三方</td>
                <td>100</td>
                <td>说明</td>
                <td>
                  <span class="editstyle">编辑</span>
                </td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </template>
    </section>
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
  @import "../../less/table";

  .table-wrapper {
    padding: 10px;
  }
  .table-page {
    display: block;
    height: 50px;
    width: 100%;
    background: white;
    margin-top: 20px;
    margin-bottom: 10px;
    padding: 10px;
  }
  .editstyle {
    color: #6dd7ff;
    font-size: 16px;
    border: 1px solid #6dd7ff;
    border-radius: 3px;
    background-color: #ffffff;
    padding: 5px 10px;
    cursor: pointer;
  }
  table {
    tr {
      border-bottom: 1px dashed #ababab;
      &:last-child {
        border: none;
      }
    }
  }

  .device-list {
    .title {
      font-size: 18px;
      padding: 20px;
      position: relative;
      border-bottom: 1px solid #cccccc;
    }
    .addbtn {
      position: absolute;
      right: 50px;
      bottom: 10px;
      .btn {
        color: #ffffff;
        background-color: #3dcb9d;
        font-size: 16px;
        padding: 3px 10px;
        border-radius: 3px;
        margin-left: 10px;
      }
    }
  }

  .panel {
    background: white;
    margin-bottom: 15px;
    .side {
      align-self: center;
      &.right {
        text-align: right;
        padding-right: 20px;
      }
    }
    .tab-item {
      background: white;
      line-height: 30px;
      padding: 10px;
      font-size: 18px;
      text-align: center;
      cursor: pointer;
      position: relative;
      &:after {
        content: ' ';
        width: 1px;
        height: 20px;
        display: block;
        background: #c4c4c4;
        position: absolute;
        right: 0;
        top: 15px;
      }
      &:last-child {
        &:after {
          width: 0;
        }
      }
      &.active {
        background: #90a2ca;
        color: white;
        &:after {
          width: 0;
        }
      }
    }
    .modal_t {
      color: #333333;
      font-size: 16px;
      padding: 20px;
      cursor: pointer;
    }
  }
  .table-style {
    padding: 10px !important;
  }
  .ivu-input {
    border-radius: 3px;
  }
</style>
<script type="text/ecmascript-6">

  export default {
    data () {
      return {
        showEditModal: false,
        paramEdit: {
          paramName: '',
          paramValue: '',
          remark: ''
        }
      }
    },
    methods: {
      loadData () {
      },
      saveDevice () {
        console.log(this.paramEdit)
      }
    },
    mounted () {
      this.loadData()
    }
  }
</script>
