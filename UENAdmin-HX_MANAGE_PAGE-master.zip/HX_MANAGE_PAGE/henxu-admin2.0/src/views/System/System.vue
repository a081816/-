<template>
  <div>
    <section class="panel">
      <Row style="display: flex">
        <i-col class="side modal_t" :span="8">
          系统参数
        </i-col>
        <i-col class="side right" :span="16">
          <Button type="primary" @click="showAddParamModal = true">新增模块</Button>
        </i-col>
      </Row>
    </section>
    <!--新增模块-->
    <Modal v-model="showAddParamModal" title="新增参数模块">
      <div class="form">
        <Form ref="addParamModal" :model="addParamModal" :rules="ruleValidate" label-position="left" :label-width="120">
          <FormItem label="模块名称：" prop="paramKey">
            <i-input v-model="addParamModal.paramKey"></i-input>
          </FormItem>
        </Form>
      </div>
      <div slot="footer">
        <Button  @click="addParamModalMethod('addParamModal')" class="checkBtn ivu-btn-primary">确认</Button>
      </div>
    </Modal>
    <!--编辑参数-->
    <Modal v-model="showEditModal" title="编辑参数">
      <div class="form" v-if="onEditDevice">
        <Form ref="onEditDevice" :model="onEditDevice" :rules="ruleValidate1" label-position="left" :label-width="120">
          <FormItem label="参数键：" prop="paramKey">
            <i-input v-model="onEditDevice.paramKey"></i-input>
          </FormItem>
          <FormItem label="参数值：" prop="paramValue">
            <i-input v-model="onEditDevice.paramValue"></i-input>
          </FormItem>
          <FormItem label="参数说明：">
            <i-input v-model="onEditDevice.remark" type="textarea" :rows="4"></i-input>
          </FormItem>
        </Form>
      </div>
      <div slot="footer">
        <Button  @click="saveDevice('onEditDevice')" class="checkBtn ivu-btn-primary">确认</Button>
      </div>
    </Modal>
    <section class="panel device-list" v-for="(device, index) in devices">
      <template>
        <div class="title">
          {{device.paramKey}}
          <div class="addbtn">
            <Button class="btn" @click.native="editDevice(null, device)">新增参数</Button>
            <Button class="btn" @click.native="showDevice(null, device)" v-if="device.expand">收起</Button>
            <Button class="btn" @click.native="showDevice(null, device)" v-else>展开</Button>
            <Button class="delete" @click.native="deleteParame(device)">删除</Button>
          </div>
        </div>
        <div v-if="device.expand" v-model="thisDeviceId">
          <div class="table-wrapper">
            <table class="order-detail">
              <thead>
              <tr>
                <th style="padding-left: 30px">参数</th>
                <th>参数值</th>
                <th>备注说明</th>
                <th>操作</th>
              </tr>
              </thead>
              <tbody class="table-style">
              <tr v-for="d in device.children">
                <td style="padding-left: 30px">{{d.paramKey}}</td>
                <td>{{d.paramValue}}</td>
                <td>{{d.remark}}</td>
                <td width="200">
                  <span class="editstyle" @click="editDevice(d)">编辑</span>
                  <span class="editstyle1" @click="deleteParame(d)">删除</span>
                </td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </template>
    </section>
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
  @import "../../less/table";

  .table-wrapper {
    padding: 10px;
  }
  .table-page {
    display: block;
    height: 50px;
    width: 100%;
    background: white;
    margin-top: 20px;
    margin-bottom: 10px;
    padding: 10px;
  }
  .editstyle {
    color: #6dd7ff;
    font-size: 16px;
    border: 1px solid #6dd7ff;
    border-radius: 3px;
    background-color: #ffffff;
    padding: 5px 10px;
    cursor: pointer;
  }
  .editstyle1 {
    color: #e27878;
    font-size: 16px;
    border: 1px solid #e27878;
    border-radius: 3px;
    background-color: #ffffff;
    padding: 5px 10px;
    cursor: pointer;
  }
  table {
    tr {
      border-bottom: 1px dashed #ababab;
      &:last-child {
        border: none;
      }
    }
  }

  .device-list {
    padding: 30px 0;
    .title {
      font-size: 18px;
      padding: 20px;
      position: relative;
      border-bottom: 1px solid #cccccc;
    }
    .addbtn {
      position: absolute;
      right: 50px;
      bottom: 10px;
      .btn {
        color: #ffffff;
        background-color: #3dcb9d;
        font-size: 16px;
        padding: 3px 10px;
        border-radius: 3px;
        margin-left: 10px;
        border-radius: 4px;
      }
      .delete {
        background-color: #e27878;
        color: #ffffff;
        font-size: 16px;
        margin-left: 20px;
        padding: 3px 10px;
        border-radius: 4px;
      }
    }
  }

  .panel {
    background: white;
    margin-bottom: 15px;
    .side {
      align-self: center;
      &.right {
        text-align: right;
        padding-right: 20px;
      }
    }
    .tab-item {
      background: white;
      line-height: 30px;
      padding: 10px;
      font-size: 18px;
      text-align: center;
      cursor: pointer;
      position: relative;
      &:after {
        content: ' ';
        width: 1px;
        height: 20px;
        display: block;
        background: #c4c4c4;
        position: absolute;
        right: 0;
        top: 15px;
      }
      &:last-child {
        &:after {
          width: 0;
        }
      }
      &.active {
        background: #90a2ca;
        color: white;
        &:after {
          width: 0;
        }
      }
    }
    .modal_t {
      color: #333333;
      font-size: 16px;
      padding: 20px;
      cursor: pointer;
    }
  }
  .table-style {
    padding: 10px !important;
  }
  .ivu-input {
    border-radius: 3px;
  }
</style>
<script type="text/ecmascript-6">
  export default {
    data () {
      const addparamKeyModal = (rule, value, callback) => {
        if (value === '') {
          return callback(new Error('请输入参数名称'))
        } else {
          let reg = /[\u4e00-\u9fa5]/g
          if (reg.test(value) === true) {
            return callback(new Error('参数名称不能含有中文'))
          } else {
            callback()
          }
        }
      }
      const addParamModal = (rule, value, callback) => {
        if (value === '') {
          return callback(new Error('请输入模块名称'))
        } else {
          callback()
        }
      }
      const addparamNameModal = (rule, value, callback) => {
        if (value === '') {
          return callback(new Error('请输入参数值'))
        } else {
          callback()
        }
      }
      return {
        type: 1,
        devices: [],
        editBrandIndex: null,
        newBrandName: '',
        brandName: '',
        showEditModal: false,
        showEditModal1: false,
        showAddParamModal: false,
        showtable: true,
        onEditDevice: null,
        thisDeviceId: '',
        addParamModal: {
          pid: 0,
          paramKey: ''
        },
        ruleValidate: {
          paramKey: [
            { validator: addParamModal, trigger: 'blur' }
          ]
        },
        ruleValidate1: {
          paramKey: [
            { validator: addparamKeyModal, trigger: 'blur' }
          ],
          paramValue: [
            { validator: addparamNameModal, trigger: 'blur' }
          ]
        }
      }
    },
    watch: {
      type: 'loadData'
    },
    methods: {
      addParamModalMethod (name) {
        this.showAddParamModal = true
        this.$refs[name].validate((valid) => {
          if (valid) {
            this.$http.post('/sysParam', Object.assign({}, this.addParamModal)).then(res => {
              if (res.code === 0) {
                this.$Message.info('新增成功')
                this.showAddParamModal = false
                this.loadData()
              } else {
                this.$Message.error('系统出现错误，请联系管理员!')
              }
            })
          } else {
            this.$Message.error('请把信息填写完整!')
          }
        })
      },
      editDevice (device, parent) {
        if (device) { // 编辑参数
          this.onEditDevice = device
          this.onEditDevice = {
            remark: device.remark,
            pid: device.pid,
            paramKey: device.paramKey,
            paramValue: device.paramValue,
            id: device.id
          }
        } else { // 新增参数
          this.onEditDevice = {
            remark: '',
            pid: parent.id,
            paramKey: '',
            paramValue: ''
          }
        }
        this.showEditModal = true
      },
      showDevice (device, parent) {
        parent.expand = !parent.expand
      },
      deleteParameter (deleteParameter) {
        this.$Modal.confirm({
          title: '确认删除',
          content: '操作无法撤销 是否执行?',
          onOk: () => {
            this.$http.post(this.$api.InvSolar.solardelete, Object.assign({})).then(res => {
              if (res.code === 200) {
                this.$Message.success('删除成功!')
                this.loadData()
              }
            })
          }
        })
      },
      deleteParame (parame) {
        console.log(parame.id)
        this.$Modal.confirm({
          title: '确认删除',
          content: '操作无法撤销 是否执行?',
          onOk: () => {
            this.$http.delete('/sysParam/' + parame.id).then(res => {
              if (res.code === 0) {
                this.$Message.success('删除成功!')
                this.loadData()
              } else {
                this.$Notice.error({
                  title: '网络错误',
                  desc: '网络出错，如果多次出现，请联系管理员或者稍后再试',
                  duration: 5
                })
              }
            })
          }
        })
      },
      saveDevice (name) {
        this.$refs[name].validate((valid) => {
          if (valid) {
            if (this.onEditDevice.id) {
              this.$http.put('/sysParam/' + this.onEditDevice.id, Object.assign({}, this.onEditDevice)).then(res => {
                if (res.code === 0) {
                  this.$Message.success('编辑成功!')
                  this.showEditModal = false
                  this.loadData()
                }
              })
            } else {
              this.$http.post('/sysParam', Object.assign({}, this.onEditDevice)).then(res => {
                if (res.code === 0) {
                  this.$Message.success('添加成功!')
                  this.showEditModal = false
                  this.loadData()
                }
              })
            }
          } else {
            this.$Message.error('请把信息填写完整!')
          }
        })
      },
      newBrand () {
        this.$Modal.confirm({
          render: (h) => {
            return h('Input', {
              props: {
                value: this.newBrandName,
                autofocus: true,
                placeholder: '请输入新模块的名称'
              },
              on: {
                input: (val) => {
                  this.newBrandName = val
                }
              }
            })
          },
          onOk: () => {
            this.$http.post(this.$api.brand.save, {
              brandName: this.newBrandName,
              type: this.type
            }).then(res => {
              if (res.code === 200) {
                this.$Message.success('提交成功!')
                window.location.reload()
              }
            })
          }
        })
      },
      updateBrand (index, brandName) {
        this.$http.post(this.$api.brand.save, {
          brandName: brandName,
          type: this.type,
          id: this.devices[index].id
        }).then(res => {
          if (res.code === 200) {
            this.$Message.info('更新成功')
            this.editBrandIndex = null
          }
        })
      },
      loadData () {
        this.$http.get('/sysParam/tree').then(res => {
          this.devices = res.sysParamTreeList
        })
      }
    },
    mounted () {
      this.loadData()
    }
  }
</script>
