<template>
  <div>
    <section class="table-wrapper">
      <div class="panel">
        <div class="content-t">角色列表
          <div class="edit">
            <Button class="editbtn ivu-btn-primary" @click="addRolemethod" v-if="showBtn('sys:role:add')">新增角色</Button>
          </div>
        </div>
      </div>
      <!--<Button type="primary" @click.native="$router.push({name: 'SystemNewBanner'})" class="new-push">新增Banner</Button>-->
      <!--<app-table ref="table" :api="$api.banner.list" :row-handle="rowHandle" :column="model"></app-table>-->
      <Table ref="selection" :columns="columns" :data="sysParamList"
             @on-select="onSelect" @on-select-cancel="onSelectCancel" @on-select-all="selectAll"></Table>
      <div style="margin: 30px 0 0 30px">
        <Button @click="handleSelectAll(true)" class="border-raudius4">全选</Button>
        <Button @click="handleSelectAll(false)" class="border-raudius4">取消全选</Button>
        <Button class="border-raudius4 bg-color" @click="deleteRole" v-if="showBtn('sys:role:del')">删除</Button>
      </div>
      <!--page-->
      <Page style="margin: 100px auto 0; width: 800px;text-align: center; padding-bottom: 100px" :current="tableParams.current" :page-size="tableParams.pageSize"
            :total="tableParams.total" placement="top" show-total
            show-elevator @on-change="onChangePage"></Page>
    </section>
    <!--新增角色-->
    <Modal v-model="addRole" width="800" style="padding: 0">
      <p slot="header" style=" padding: 0">
        <span>新增角色</span>
      </p>
      <div class="form">
        <Form ref="addRoleUser" :model="addRoleUser" :rules="ruleValidate" label-position="left" :label-width="120" style="width: 700px">
          <FormItem label="角色名称：" prop="name">
            <Input v-model="addRoleUser.name" placeholder="请输入角色名称" style="width: 250px"/>
          </FormItem>
        </Form>
      </div>
      <div slot="footer">
        <Button  @click="addRoleUserMethod('addRoleUser')" class="checkBtn ivu-btn-primary">确认</Button>
      </div>
    </Modal>
    <!--权限设置-->
    <Modal v-model="showPermissionSelect" title="权限设置" @on-ok="updateRole">
      <template>
        <div class="role_t">角色名称：<span v-model="roleName">{{roleName}}</span></div>
        <!--<CheckboxGroup v-model="selectPower">
           <Checkbox label="1" style="margin: 20px 30px 0 10px">超级管理员</Checkbox>
           <Checkbox label="2" style="margin: 20px 30px 0 10px">资讯管理员</Checkbox>
           <Checkbox label="3" style="margin: 20px 30px 0 10px">用户管理员</Checkbox>
           <Checkbox label="4" style="margin: 20px 30px 0 10px">电站管理员</Checkbox>
           <Checkbox label="5" style="margin: 20px 30px 0 10px">电站管理员</Checkbox>
         </CheckboxGroup>-->
        <Tree :data="roletree" @on-check-change="getSelectedNodes" show-checkbox multiple></Tree>
      </template>
    </Modal>
  </div>
</template>
<style lang="less" rel="stylesheet/less">
  @import "../less/table";
  @import "../less/filter";
  @import "../less/search";

  .table-wrapper {
    background: white;
    padding: 10px 10px;
    .table {
      width: 100%;
    }
  }
  .border-raudius4 {
    border-radius: 4px;
  }
  .bg-color {
    background-color: #e27878;
    color: #ffffff;
    font-size: 14px;
    margin-left: 20px;
  }
  .new-push {
    margin: 10px 0;
  }
  .content-t {
    font-size: 16px;
    color: #333333;
    border-bottom: 2px solid #f0f0f0;
    padding: 20px;
    position: relative;
  }
  .edit {
    position: absolute;
    bottom: 14px;
    right: 50px;
  }
  .editbtn {
    background-color: #3dcb9d;
    border-radius: 4px;
    color: #ffffff;
    font-size: 14px;
    padding: 8px 30px;
  }
  .checkBtn {
    background-color: #3dcb9d;
    width: 130px;
    border: none;
    margin: 0 auto;
    border-radius: 3px;
    display: block;
    color: #ffffff;
    font-size: 16px;
  }
  .changebtn {
    font-size: 14px;
    color: #ffffff;
    background-color: #5ad3ac;
    border-radius: 3px;
  }
  .ivu-modal-header {
    background-color: #3dcb9d;
  }
  .ivu-modal-header p {
    color: #ffffff !important;
  }
  .ivu-modal-header-inner {
    color: #ffffff !important;
  }
  .role_t {
    border-bottom: 1px solid #f0f0f0;
    padding-bottom: 20px;
    font-size: 14px;
    color: #333333;
    span {
      font-weight: bold;
    }
  }
</style>
<script type="text/ecmascript-6">

  export default{
    data () {
      const addRoleName = (rule, value, callback) => {
        if (value === '') {
          return callback(new Error('请输入角色名称'))
        } else {
          callback()
        }
      }
      return {
        addRole: false,
        showPermissionSelect: false,
        selectRole: '',
        roleSelectId: '',
        roleName: '',
        selectPower: [],
        tableParams: {
          pageSize: 10,
          current: 1,
          total: 0
        },
        columns: [
          {
            type: 'selection',
            width: 60,
            align: 'center'
          },
          {
            title: '角色ID',
            key: 'id'
          },
          {
            title: '角色名称',
            key: 'role'
          },
          {
            title: '操作',
            key: 'action',
            width: 200,
            align: 'center',
            render: (h, params) => {
              let buttonSet = this.$store.state.user.user.buttonSet
              if (buttonSet.indexOf('sys:role:permission') >= 0) {
                return h('div', [
                  h('Button', {
                    props: {
                      size: 'small'
                    },
                    style: {
                      marginRight: '5px',
                      color: '#8bd5ff',
                      border: '1px solid #8bd5ff',
                      backgroundColor: '#ffffff',
                      fontSize: '16px',
                      width: '88px',
                      borderRadius: '3px'
                    },
                    on: {
                      click: () => {
                        this.show(params.row)
                      }
                    }
                  }, '权限设置')
                ])
              } else {
                return h('span', '')
              }
            }
          }
        ],
        sysParamList: [],
        manage: {
          name: '',
          dept: '',
          phone: ''
        },
        ruleValidate: {
          name: [
            { validator: addRoleName, trigger: 'blur' }
          ]
        },
        roleList: [
          {
            value: 'all',
            label: '全部'
          },
          {
            value: 'admin',
            label: '超级管理员'
          }
        ],
        addRoleUser: {
          name: ''
        },
        roletree: [],
        classificationFinalSelected: [],
        mids: '',
        rid: ''
      }
    },
    watch: {
    },
    methods: {
      addRoleUserMethod (name) {
        this.$refs[name].validate((valid) => {
          if (valid) {
            this.$http.post('/sysRole', {role: this.addRoleUser.name}).then(res => {
              if (res.code === 0) {
                this.$Message.info('新增成功')
                window.location.reload()
              } else {
                this.$Message.error('系统出现错误，请联系管理员!')
              }
            })
          } else {
            this.$Message.error('系统出现错误，请联系管理员!')
          }
        })
      },
      updateRole () {
        this.$http.put('/sysRoleMenu', {rid: this.rid, mids: this.mids}).then(res => {
          if (res.code === 0) {
            this.$Message.info('保存成功')
            this.showPermissionSelect = false
            window.location.reload()
          } else {
            this.$Message.error('系统出现错误，请联系管理员!')
          }
        })
      },
      // 全选状态改变
      handleSelectAll (status) {
        this.$refs.selection.selectAll(status)
        if (!status) {
          this.roleSelectId = ''
        }
      },
      onSelect (selection) { // 获取勾选的值
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.roleSelectId = tableId.join(',')
        console.log(this.roleSelectId)
      },
      onSelectCancel (selection) {  // 获取取消勾选的值
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.roleSelectId = tableId.join(',')
        console.log(this.roleSelectId)
      },
      selectAll (selection) { //  获取全选的值
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.roleSelectId = tableId.join(',')
        console.log(this.roleSelectId)
        return tableId
      },
      addRolemethod () {
        this.addRole = true
      },
      deleteRole () { // 删除传递电站id字符串
        console.log(this.roleSelectId)
        if (this.roleSelectId) {
          this.$Modal.confirm({
            title: '确认删除',
            content: '操作无法撤销 是否执行?',
            onOk: () => {
              this.$http.delete('/sysRole/' + this.roleSelectId).then(res => {
                if (res.code === 0) {
                  this.$Message.success('删除成功')
                  this.loadData()
                }
              })
            }
          })
        } else {
          this.$Message.error('请勾选删除项')
        }
      },
      show (row) {
        // this.$router.push({name: 'NewsDetail', query: {id: row.id}})
        this.showPermissionSelect = true
        this.rid = row.id
        let planinfoarry = []
        const column = row.roleInfo
        for (let key in column) {
          planinfoarry.push(column[key].roleNum)
        }
        this.roleName = row.role
        this.$http.get('/sysMenu/tree/' + row.id).then(res => {
          this.roletree = res.sysMenuTreelist
        })
      },
      getRequestParams () {
        return Object.assign({}, {
          current: this.tableParams.current - 1,
          size: this.tableParams.pageSize
        })
      },
      onChangePage (page) {
        // 改变页码
        this.tableParams.current = page
        this.loadData()
      },
      loadData () {
        this.$nextTick(() => {
          this.$http.get('/sysRole/page/' + this.tableParams.current).then(res => {
            this.sysParamList = res.sysRolePage.records
            this.tableParams.current = res.sysRolePage.current
            this.tableParams.pageSize = res.sysRolePage.size
            this.tableParams.total = res.sysRolePage.total
          })
        })
      },
      getSelectedNodes (selectedArray) {
        let iddata = []
        for (let key in selectedArray) {
          iddata.push(selectedArray[key].id)
        }
        let iddatastr = iddata.join(',')
        this.mids = iddatastr
        console.log(this.mids)
      }
    },
    mounted () {
      this.$nextTick(() => {
        this.loadData()
      })
    }
  }
</script>
