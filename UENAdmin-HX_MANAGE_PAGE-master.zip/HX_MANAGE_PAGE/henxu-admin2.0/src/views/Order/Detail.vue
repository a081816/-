<template>
  <div>
    <!--订单基本信息-->
    <section class="panel">
      <div class="content-t">订单基本信息
        <div class="edit">
          <Button class="editbtn" @click="editOrderInfo = true" v-if="showBtn('sys:order:infoEdit')">编辑</Button>
        </div>
      </div>
      <Row class="info-row bgf8fffd">
        <i-col :span="12">
          <div class="label">订单编号</div>
          <template>
            <span class="showdetail">{{orderinfo.orderCode}}</span>
          </template>
        </i-col>
        <i-col :span="12">
          <div class="label">建站地址</div>
          <template>
            <span class="showdetail">{{orderinfo.orderAddress}}</span>
          </template>
        </i-col>
      </Row>
      <Row class="info-row">
        <i-col :span="12">
          <div class="label">联系人</div>
          <template>
            <span class="showdetail">{{orderinfo.linkmanName}}</span>
          </template>
        </i-col>
        <i-col :span="12">
          <div class="label">联系电话</div>
          <template>
            <span class="showdetail">{{orderinfo.linkmanTelephone}}</span>
          </template>
        </i-col>
      </Row>
      <Row class="info-row bgf8fffd">
        <i-col :span="12">
          <div class="label">装机容量</div>
          <template>
            <span class="showdetail">{{orderinfo.orderCapacity}}KW</span>
          </template>
        </i-col>
        <i-col :span="12">
          <div class="label">订单金额</div>
          <template>
            <span class="showdetail">{{orderinfo.orderPrice}}元</span>
          </template>
        </i-col>
      </Row>
    </section>
    <!--订单材料清单-->
    <section class="panel">
      <div class="content-t">订单材料清单
        <div class="edit">
          <Button class="editbtn" @click="editMaterialInfo = true" v-if="showBtn('sys:order:materialEdit')">编辑</Button>
        </div>
      </div>
      <Row class="info-row bgf8fffd">
        <i-col :span="12">
          <div class="label">逆变器</div>
          <template>
            <span class="showdetail" v-if="orderProject">{{orderProject.inverterBrand}}/{{orderProject.inverterModel}}</span>
            <span class="showdetail" v-else>无</span>
            <!--<span class="edit-btn" @click="showInverterSelect = true">修改</span>-->
          </template>
        </i-col>
        <i-col :span="12">
          <div class="label">电池板</div>
          <template>
            <span class="showdetail" v-if="orderProject">{{orderProject.solarPanelBrand}}/{{orderProject.solarPanelModel}} </span>
            <span class="showdetail" v-else>无</span>
            <!--<span class="edit-btn" @click="showBatterySelect = true">修改</span>-->
          </template>
        </i-col>
      </Row>
      <Row class="info-row">
        <i-col :span="12">
          <div class="label">逆变器保修年限</div>
          <template>
            <span class="showdetail" v-if="orderProject">{{orderProject.inverterWarrantyPeriod}}年</span>
            <span class="showdetail" v-else>无</span>
          </template>
        </i-col>
        <i-col :span="12">
          <div class="label">电池板保修年限</div>
          <span class="showdetail" v-if="orderProject">{{orderProject.solarPanelWarrantyPeriod}}年</span>
          <span class="showdetail" v-else>无</span>
        </i-col>
      </Row>
      <Row class="info-row bgf8fffd">
        <div class="label">其他材料</div>
        <span class="showdetail" v-if="orderProject">{{orderProject.otherMeterial}}</span>
        <span class="showdetail" v-else>无</span>
      </Row>
      <Row class="info-row">
        <div class="label">选配项目</div>
        <span class="showdetail" v-if="orderProject">{{getApolegamyText(orderSelectionList)}}</span>
        <span class="showdetail" v-else>无</span>
      </Row>
    </section>
    <!--订单进度-->
    <section class="panel">
      <div class="content-t">订单进度</div>
      <Row class="info-row bgf8fffd">
        <i-col :span="4">
          <div class="label">支付状态</div>
        </i-col>
        <i-col :span="18">
          <template v-if="showEditPay">
            <Row>
              <i-col :span="8">
                <Select style="width:200px" v-model="paydata">
                  <Option
                    v-for="(item, index) in ['未支付' ,'已支付']"
                    :value="index" :key="index">{{ item }}
                  </Option>
                </Select>
              </i-col>
              <i-col :span="6">
                  <Button class="editbtn1" @click="updataPay">确定修改</Button>
              </i-col>
            </Row>
          </template>
          <template v-else>
            <Row>
              <i-col :span="4">
                <span class="showdetail">{{orderStatus.payStatus}}</span>
              </i-col>
              <i-col :span="6">
                <Button class="editbtn1" @click="showEditPay = true"  v-if="showBtn('sys:order:paymentEdit')">编辑</Button>
              </i-col>
            </Row>
          </template>
        </i-col>
      </Row>
      <Row class="info-row">
        <i-col :span="4">
          <div class="label">施工进度</div>
        </i-col>
        <i-col :span="18">
          <template v-if="showEditAdvance">
          <Row>
            <i-col :span="8">
              <Select style="width:200px" v-model="buildStatusData">
                <Option
                  v-for="(item, index) in buildStepBFilter"
                  :value="index" :key="index">{{ item }}
                </Option>
              </Select>
            </i-col>
            <i-col :span="6">
              <Button class="editbtn1"  @click="updataPay">确认修改</Button>
            </i-col>
          </Row>
          </template>
          <template v-else>
            <Row>
              <i-col :span="4">
                <span class="showdetail">{{orderStatus.buildStatus}}</span>
              </i-col>
              <i-col :span="6">
                <Button class="editbtn1" @click="showEditAdvance = true"  v-if="showBtn('sys:order:constructionEdit')">编辑</Button>
              </i-col>
            </Row>
          </template>
        </i-col>
      </Row>
      <Row class="info-row bgf8fffd">
        <i-col :span="4">
          <div class="label">创建电站</div>
        </i-col>
        <i-col :span="18">
          <template v-if="enableShowed">
            <Row>
              <i-col :span="4">
                <span class="showdetail">未创建电站</span>
              </i-col>
              <i-col :span="6">
                <Button class="editbtn1" @click="greatStation">创建</Button>
              </i-col>
            </Row>
          </template>
          <template v-else>
            <Row>
              <i-col :span="8">
                <span class="showdetail">已创建电站</span>
              </i-col>
            </Row>
          </template>
        </i-col>
      </Row>
    </section>
    <!--订单基本信息修改-->
    <Modal v-model="editOrderInfo" width="800" style="padding: 0">
      <p slot="header" style=" padding: 0">
        <span>订单基本信息修改</span>
      </p>
      <div class="form">
        <Form ref="OrderValidate" :model="OrderValidate" :rules="ruleValidate" label-position="left" :label-width="120" style="width: 700px">
          <FormItem label="订单编号：">
            <span v-model="OrderValidate.orderCode">{{OrderValidate.orderCode}}</span>
          </FormItem>
          <FormItem label="建站地址：" prop="orderAddress">
            <Input v-model="OrderValidate.orderAddress" placeholder="请输入建站地址" />
          </FormItem>
          <FormItem label="联系人：" prop="linkmanName">
            <Input v-model="OrderValidate.linkmanName" placeholder="请输入联系人姓名" />
          </FormItem>
          <FormItem label="联系电话：" prop="linkmanTelephone">
            <Input v-model="OrderValidate.linkmanTelephone" placeholder="请输入联系电话" />
          </FormItem>
          <FormItem label="装机容量：" prop="orderCapacity">
            <Input v-model="OrderValidate.orderCapacity" placeholder="请输入装机容量" />
          </FormItem>
          <FormItem label="订单金额：" prop="orderPrice">
            <Input v-model="OrderValidate.orderPrice" placeholder="请输入订单金额" />
          </FormItem>
        </Form>
      </div>
      <div slot="footer">
        <Button  @click="handleSubmit('OrderValidate')" class="checkBtn">确认修改</Button>
      </div>
    </Modal>
    <!--订单材料清单修改-->
    <Modal v-model="editMaterialInfo" width="800" style="padding: 0">
      <p slot="header" style=" padding: 0">
        <span>订单材料清单修改</span>
      </p>
      <div class="form">
        <Form ref="materialValidate" :model="materialValidate" :rules="ruleValidate1" label-position="left" :label-width="120" style="width: 700px">
          <FormItem label="适用装机容量：" prop="capacity">
            <Input v-model="materialValidate.capacity" placeholder="请输入适用装机容量" style="width: 250px"/>
          </FormItem>
          <FormItem label="逆变器：">
            <Row>
              <Col span="11">
              <FormItem prop="inverterBrand">
                <Input v-model="materialValidate.inverterBrand" placeholder="请输入设备品牌" style="width: 250px" />
              </FormItem>
              </Col>
              <Col span="11" offset="1">
              <FormItem prop="inverterModel">
                <Input v-model="materialValidate.inverterModel" placeholder="请输入设备型号" style="width: 250px"/>
              </FormItem>
              </Col>
            </Row>
          </FormItem>
          <FormItem label="电池板：">
            <Row>
              <Col span="11">
              <FormItem prop="solarPanelBrand">
                <Input v-model="materialValidate.solarPanelBrand" placeholder="请输入设备品牌" style="width: 250px"/>
              </FormItem>
              </Col>
              <Col span="11" offset="1">
              <FormItem prop="solarPanelModel">
                <Input v-model="materialValidate.solarPanelModel" placeholder="请输入设备型号" style="width: 250px"/>
              </FormItem>
              </Col>
            </Row>
          </FormItem>
          <FormItem label="其他材料：" prop="otherMeterial">
            <Input v-model="materialValidate.otherMeterial" type="textarea" :autosize="{minRows: 4,maxRows: 5}" placeholder="其他材料" />
          </FormItem>
          <FormItem label="配选项目："  prop="checkbox">
            <CheckboxGroup v-model="materialValidateCheckbox">
              <Checkbox :label="item.id" v-for="item in selectionProjectList">{{item.projectName}}</Checkbox>
            </CheckboxGroup>
          </FormItem>
        </Form>
      </div>
      <div slot="footer">
        <Button  @click="handleSubmit('materialValidate')" class="checkBtn">确认修改</Button>
      </div>
    </Modal>
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
  .cards {
    height: 448px;
    box-sizing: border-box;
    margin-bottom: 10px;
    &.second {
      height: 380px;
    }
    .item {
      background: white;
      height: 100%;
      &.large {
        padding: 0 16px;
        box-sizing: inherit;
        background: transparent;
        .inner-container {
          width: 100%;
          height: 100%;
          background: white;
        }
      }
    }
  }
  .content-t {
    font-size: 16px;
    color: #333333;
    border-bottom: 2px solid #18b566;
    padding: 20px;
    position: relative;
  }
  .bgf8fffd {
    background-color: #f8fffd;
  }
  .edit-btn {
    color: #90a2ca;
    padding: 0 10px;
    cursor: pointer;
  }
  .editbtn {
    background-color: #18b566;
    border-radius: 4px;
    color: #ffffff;
    font-size: 14px;
    padding: 8px 30px;
  }
  .editbtn1 {
    background-color: #18b566;
    border-radius: 4px;
    color: #ffffff;
    font-size: 14px;
    padding: 3px 20px;
  }
  .edit {
    position: absolute;
    bottom: 14px;
    right: 50px;
  }
  .info-row {
    border-bottom: 1px solid #f2f2f2;
    padding: 10px 15px;
    font-size: 16px;
    color: #b6b6b6;
    .label {
      width: 200px;
      display: inline-block;
      color: #999999;
    }
    .showdetail {
      color: #666666;
    }
  }
  .panel {
    background: white;
    margin-bottom: 30px;
  }
  .modal_t {
    color: #ffffff;
    font-size: 16px;
    padding: 20px;
    background-color: #3dcb9d;

  }
  .ivu-modal-header { padding: 0px !important;}
  .checkBtn {
    background-color: #3dcb9d;
    width: 130px;
    border: none;
    margin: 0 auto;
    border-radius: 3px;
    display: block;
    color: #ffffff;
    font-size: 16px;
  }
  .border-radius3 {
    border-radius: 3px !important;
  }
</style>
<script type="text/ecmascript-6">
  export default {
    data () {
      const validateAddr = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('建站地址不能为空'))
        } else {
          callback()
        }
      }
      const validateName = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('联系人不能为空'))
        } else {
          callback()
        }
      }
      const validatePhone = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('联系电话不能为空'))
        } else {
          let reg = /^(13[0-9]{9})|(18[0-9]{9})|(14[0-9]{9})|(17[0-9]{9})|(15[0-9]{9})$/
          if (reg.test(value) === false) {
            return callback(new Error('请输入正确的手机号码'))
          } else {
            callback()
          }
        }
      }
      const validateKw = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('装机容量不能为空'))
        } else {
          callback()
        }
      }
      const validateMoney = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('订单金额不能为空'))
        } else {
          callback()
        }
      }
      const validatecapacity = (rule, value, callback) => {
        if (value.length === 0) {
          callback(new Error('请输入装机容量'))
        } else {
          callback()
        }
      }
      const validateinverterBrand = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入逆变器品牌'))
        } else {
          callback()
        }
      }
      const validateinverterModel = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入逆变器型号'))
        } else {
          callback()
        }
      }
      const validateBatteryBrand = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入电池板品牌'))
        } else {
          callback()
        }
      }
      const validateBatteryModel = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入电池板型号'))
        } else {
          callback()
        }
      }
      const validateothers = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入其他材料'))
        } else {
          callback()
        }
      }
      return {
        editOrderInfo: false,
        editMaterialInfo: false,
        showEditPay: false,
        showEditAdvance: false,
        orderuid: '',
        paydata: '',
        orderinfo: '',
        orderProject: '',
        orderSelectionList: '',
        orderStatus: '',
        thispayStatus: '',
        thisbuildStatus: '',
        selectionProjectList: '',
        buildStatusData: '',
        materialValidateCheckbox: [],
        OrderValidate: {
          orderCode: '',
          orderAddress: '',
          linkmanName: '',
          linkmanTelephone: '',
          orderCapacity: '',
          orderPrice: ''
        },
        materialValidate: {
          capacity: '',
          inverterBrand: '',
          inverterModel: '',
          solarPanelBrand: '',
          solarPanelModel: '',
          otherMeterial: '',
          checkbox: [],
          selectionIds: ''
        },
        buildStepBFilter: [
          '未开始', '材料进场', '基础建筑', '支架安装', '光伏板安装', '直流接线', '电箱逆变器', '汇流箱安装', '交流辅线', '防雷接地测试', '并网验收'
        ],
        ruleValidate1: {
          capacity: [
            { validator: validatecapacity, trigger: 'blur' }
          ],
          inverterBrand: [
            { validator: validateinverterBrand, trigger: 'blur' }
          ],
          inverterModel: [
            { validator: validateinverterModel, trigger: 'blur' }
          ],
          solarPanelBrand: [
            { validator: validateBatteryBrand, trigger: 'blur' }
          ],
          solarPanelModel: [
            { validator: validateBatteryModel, trigger: 'blur' }
          ],
          otherMeterial: [
            { validator: validateothers, trigger: 'blur' }
          ],
          checkbox: [
            { required: true, type: 'array', min: 1, message: '最少选择一个配选项目', trigger: 'change' }
          ]
        },
        ruleValidate: {
          orderAddress: [
            { validator: validateAddr, trigger: 'blur' }
          ],
          linkmanName: [
            { validator: validateName, trigger: 'blur' }
          ],
          linkmanTelephone: [
            { validator: validatePhone, trigger: 'blur' }
          ],
          orderCapacity: [
            { validator: validateKw, trigger: 'blur' }
          ],
          orderPrice: [
            { validator: validateMoney, trigger: 'blur' }
          ]
        },
        enableShowed: true
      }
    },
    watch: {
      'materialValidateCheckbox': function (val) {
        this.materialValidate.checkbox = this.materialValidateCheckbox
      },
      orderStatus () {
        this.paydata = this.thispayStatus
        this.buildStatusData = this.thisbuildStatus
      }
    },
    methods: {
      handleSubmit (name) {
        if (name === 'materialValidate') {
          this.$refs[name].validate((valid) => {
            if (valid) {
              this.$http.put('/orderProject/' + this.$route.query.orderCode, this.getRequestParams1()).then(res => {
                if (res.code === 0) {
                  this.editMaterialInfo = false
                  this.loadData1()
                } else {
                  this.$Message.error('网络出错，请重新再试')
                }
              })
            } else {
              this.$Message.error('请把信息填写完整')
            }
          })
        } else {
          this.$refs[name].validate((valid) => {
            if (valid) {
              // this.$Message.success('Success!')
              this.$http.put('/order/' + this.$route.query.orderCode, this.getRequestParams()).then(res => {
                if (res.code === 0) {
                  this.editOrderInfo = false
                  this.loadData()
                } else {
                  this.$Message.error('网络出错，请重新再试')
                }
              })
            } else {
              this.$Message.error('请把信息填写完整')
            }
          })
        }
      },
      getRequestParams () {
        return Object.assign({}, this.OrderValidate)
      },
      getRequestParams1 () {
        return Object.assign({}, {
          orderCode: this.$route.query.orderCode,
          solarPanelBrand: this.materialValidate.solarPanelBrand,
          solarPanelModel: this.materialValidate.solarPanelModel,
          inverterBrand: this.materialValidate.inverterBrand,
          inverterModel: this.materialValidate.inverterModel,
          otherMeterial: this.materialValidate.otherMeterial,
          capacity: this.materialValidate.capacity,
          selectionIds: this.materialValidate.checkbox.join(',')
        })
      },
      updataPay () {
        // if (this.paydata === '') {
        //  alert('请选择支付状态')
        //  return
        // }
        if (this.$route.query.orderCode) {
          this.$http.put('/orderStatus/' + this.$route.query.orderCode, {payStatusCode: this.paydata, buildStatusCode: this.buildStatusData}).then(res => {
            if (res.code === 0) {
              this.loadData2()
              this.showEditPay = false
              this.showEditAdvance = false
            } else {
              this.$Message.error('网络出错，请重试')
            }
            // this.data6 = res.vOrderInfoStatusPage.records
          })
        } else {
          this.$Message.error('网络出错，请重新选择相应订单')
        }
      },
      getApolegamyText (apolegamys, detail = false) {
        if (detail) {
          return apolegamys
        } else {
          let resultStr = ''
          apolegamys.forEach((material) => {
            resultStr += material.projectName + '/' + material.price + '元、'
          })
          return resultStr.substr(0, resultStr.length - 1)
        }
      },
      loadData () {
        this.$nextTick(() => {
          if (this.$route.query.orderCode) {
            this.$http.get('/order/' + this.$route.query.orderCode).then(res => {
              this.orderinfo = res.order
              this.OrderValidate = res.order
              this.orderuid = res.order.uid
              console.log(this.orderuid)
              // this.data6 = res.vOrderInfoStatusPage.records
            })
          } else {
            this.$Message.error('网络出错，请重新选择相应订单')
          }
        })
      },
      loadData1 () {
        this.$nextTick(() => {
          if (this.$route.query.orderCode) {
            this.$http.get('/orderProject/' + this.$route.query.orderCode).then(res => {
              if (res.orderProject) {
                this.orderProject = res.orderProject
                this.materialValidate = res.orderProject
              }
              this.orderSelectionList = res.orderSelectionList
              if (res.orderSelectionList.length !== 0) {
                let selectionLIstId = []
                Object(res.orderSelectionList).forEach(key => {
                  selectionLIstId.push(key.sid)
                })
                this.materialValidateCheckbox = selectionLIstId
                // this.data6 = res.vOrderInfoStatusPage.records
              }
            })
          } else {
            this.$Message.error('网络出错，请重新选择相应订单')
          }
        })
      },
      loadData2 () {
        this.$nextTick(() => {
          if (this.$route.query.orderCode) {
            this.$http.get('/orderStatus/' + this.$route.query.orderCode).then(res => {
              this.orderStatus = res.orderStatus
              this.thispayStatus = res.orderStatus.payStatusCode
              this.thisbuildStatus = res.orderStatus.buildStatusCode
              this.enableShowed = res.enableShowed
            })
          } else {
            this.$Message.error('网络出错，请重新选择相应订单')
          }
        })
      },
      loadData3 () {
        this.$nextTick(() => {
          if (this.$route.query.orderCode) {
            this.$http.get('/selectionProject/list').then(res => {
              this.selectionProjectList = res.selectionProjectList
            })
          } else {
            this.$Message.error('网络出错，请重新选择相应订单')
          }
        })
      },
      greatStation () {
        if (this.enableShowed) {
          this.$http.post('/station', Object.assign({}, {orderCode: this.$route.query.orderCode, uid: this.orderuid})).then(res => {
            if (res.code === 0) {
              this.enableShowed = false
            } else {
              this.$Message.error(res.msg)
            }
          })
        } else {
          this.$Message.error('该订单已创建电站')
        }
      }
    },
    mounted () {
      this.loadData()
      this.loadData1()
      this.loadData2()
      this.loadData3()
    }
  }
</script>

