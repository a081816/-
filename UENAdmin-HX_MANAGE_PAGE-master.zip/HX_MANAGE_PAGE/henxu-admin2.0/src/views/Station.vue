<template>
  <div>
    <section class="search-panel">
      <div class="input-wrapper">
        <div class="input-container">
          <input class="inputs" v-model="condition" @keyup.enter="loadData" placeholder="电站码/电站名称/联系人姓名/联系人手机号/电站地址" type="text">
          <Button type="success" @click="loadData" class="searchs">搜索</Button>
        </div>
      </div>
      <!--筛选-->
      <section class="filter-panel">
        <div class="filter-wrapper">
          <div class="city-filter">
            <div class="floatLeft">
              <div class="label">所在地点: </div>
              <div class="select-group">
                <area-select @on-city-update="(cityId) => {form.cid = cityId}"
                             @on-province-update="(provinceId) => {form.pid = provinceId}"></area-select>
              </div>
            </div>
            <div class="floatLeft">
              <div class="label">电站状态: </div>
              <Select style="width:200px" v-model="stationStatusCode" @on-change="changestatus">
                <Option v-for="item in statusList" :value="item.value" :key="item.value">{{ item.label }}</Option>
              </Select>
            </div>
          </div>
        </div>
      </section>
    </section>
    <!--table-->
    <section class="table-wrapper">
      <Table ref="selection" :columns="columns7" :data="data6"
              @on-select="onSelect" @on-select-cancel="onSelectCancel" @on-select-all="selectAll"></Table>
      <div style="margin: 30px 0 0 30px">
        <Button @click="handleSelectAll(true)" class="border-raudius4">全选</Button>
        <Button @click="handleSelectAll(false)" class="border-raudius4">取消全选</Button>
        <Button class="border-raudius4 bg-color" @click="deleteStation" v-if="showBtn('sys:station:del')">删除</Button>
      </div>
      <!--page-->
      <Page style="margin: 100px auto 0; width: 800px;text-align: center; padding-bottom: 100px" :current="tableParams.current" :page-size="tableParams.pageSize"
            :total="tableParams.total" placement="top" show-total
            show-elevator @on-change="onChangePage"></Page>
    </section>
  </div>
</template>
<style lang="less" rel="stylesheet/less">
  @import "../less/search";
  @import "../less/filter";
  @import "../less/table";

  .table-page {
    background-color: #ffffff;
    height: 40px;
    width: 90%;
    border: none;
    margin: 20px auto;
  }
  .table-wrapper {
    background: white;
    padding: 10px 0;
    .table {
      width: 100%;
    }
  }
  .floatLeft {
    display:block;
    float: left;
  }
  .border-raudius4 {
    border-radius: 4px;
  }
  .bg-color {
    background-color: #e27878;
    color: #ffffff;
    font-size: 14px;
    margin-left: 20px;
  }
  .ivu-btn:hover {
    color: #64d5b1;
    background-color: white;
    border-color: #64d5b1;
  }
</style>
<script type="text/ecmascript-6">
  import AreaSelect from '../components/common/area-select.vue'

  export default {
    components: {
      AreaSelect
    },
    data () {
      return {
        tableParams: {
          pageSize: 10,
          current: 1,
          total: 0
        },
        statusList: [
          {
            value: '',
            label: '全部'
          },
          {
            value: '0',
            label: '未绑定电表'
          },
          {
            value: '1',
            label: '正在发电'
          },
          {
            value: '2',
            label: '电表异常'
          }
        ],
        columns7: [
          {
            type: 'selection',
            width: 60,
            align: 'center'
          },
          {
            title: '电站码',
            key: 'stationCode'
          },
          {
            title: '电站名称',
            key: 'stationName'
          },
          {
            title: '电站类型',
            key: 'stationType'
          },
          {
            title: '地址',
            key: 'stationAddress'
          },
          {
            title: '装机容量',
            key: 'stationCapacity'
          },
          {
            title: '联系人',
            key: 'linkmanName'
          },
          {
            title: '联系电话',
            key: 'linkmanTelephone'
          },
          {
            title: '电站状态',
            key: 'stationStatus'
          },
          {
            title: '操作',
            key: 'action',
            width: 150,
            align: 'center',
            render: (h, params) => {
              let buttonSet = this.$store.state.user.user.buttonSet
              if (buttonSet.indexOf('sys:user:stationDetail') >= 0) {
                return h('div', [
                  h('Button', {
                    props: {
                      type: 'primary',
                      size: 'small'
                    },
                    style: {
                      marginRight: '5px',
                      border: '1px soild #3dcb9d',
                      color: '#3dcb9d',
                      backgroundColor: '#ffffff',
                      borderRadius: '3px'
                    },
                    on: {
                      click: () => {
                        this.show(params.index)
                      }
                    }
                  }, '电站详情')
                ])
              } else {
                return h('span', '')
              }
            }
          }
        ],
        data6: [],
        form: {
          pid: '',
          cid: ''
        },
        stationStatusCode: '',
        condition: '',
        list: [],
        provinceList: [],
        tableId: [],
        rowClick: (row) => {
          this.$router.push({name: 'StationDetail', query: {id: row.id}})
        },
        stationSelectId: ''
      }
    },
    watch: {
      'form.cid': function (val) {
        console.log(val)
        this.loadData()
      },
      'form.pid': function (val) {
        console.log(val)
        this.loadData()
      }
    },
    computed: {
      customParams () {
        let list = []
        Object.keys(this.form).forEach(key => {
          list.push({
            key: key,
            value: this.form[key]
          })
        })
        return list
      }
    },
    methods: { // 全选状态改变
      handleSelectAll (status) {
        this.$refs.selection.selectAll(status)
        if (!status) {
          this.stationSelectId = ''
        }
      },
      onSelect (selection) { // 获取勾选的值
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.stationCode)
        })
        this.stationSelectId = tableId.join(',')
        console.log(this.stationSelectId)
        return tableId
      },
      onSelectCancel (selection) {  // 获取取消勾选的值
        console.log(selection)
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.stationCode)
        })
        this.stationSelectId = tableId.join(',')
        console.log(this.stationSelectId)
        return tableId
      },
      selectAll (selection) { //  获取全选的值
        console.log(selection)
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.stationCode)
        })
        console.log(tableId)
        this.stationSelectId = tableId.join(',')
        console.log(this.stationSelectId)
        return tableId
      },
      deleteStation () { // 删除传递电站id字符串
        if (this.stationSelectId) {
          this.$Modal.confirm({
            title: '确认删除',
            content: '操作无法撤销 是否执行?',
            onOk: () => {
              this.$http.delete('/station/' + this.stationSelectId, {stationCodes: this.stationSelectId}).then(res => {
                if (res.code === 0) {
                  this.$Message.success('删除成功')
                  this.loadData()
                }
              })
            }
          })
        } else {
          this.$Message.error('请勾选删除项')
        }
      },
      show (index) {  // 点击改变路由跳转
        this.$router.push({name: 'StationDetail', query: {id: this.data6[index].id, stationCode: this.data6[index].stationCode}})
      },
      getRequestParams () {
        return Object.assign({}, this.form, {status: this.stationStatusCode}, {condition: this.condition})
      },
      onChangePage (page) {
        // 改变页码
        this.tableParams.current = page
        this.loadData()
      },
      loadData () {
        this.$nextTick(() => {
          this.$http.get('/station/page/' + this.tableParams.current, {params: {pid: this.form.pid, cid: this.form.cid, condition: this.condition, stationStatusCode: this.stationStatusCode}}).then(res => {
            this.data6 = res.vStationInfoStatusPage.records
            this.tableParams.total = res.vStationInfoStatusPage.total
            this.tableParams.current = res.vStationInfoStatusPage.current
            this.tableParams.pageSize = res.vStationInfoStatusPage.size
          })
        })
      },
      changestatus () {
        this.loadData()
      }
    },
    mounted () {
      this.loadData()
    }
  }
</script>
