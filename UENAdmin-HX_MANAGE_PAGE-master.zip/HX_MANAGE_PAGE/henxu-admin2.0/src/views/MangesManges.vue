<template>
  <div>
    <section class="search-panel">
      <div class="input-wrapper">
        <div class="input-container">
          <input class="inputs" v-model="condition" @keyup.enter="loadData" placeholder="账户/姓名/部门/电话" type="text">
          <Button @click="loadData" class="searchs ivu-btn-primary">搜索</Button>
        </div>
      </div>
      <!--筛选-->
      <section class="filter-panel">
        <div class="filter-wrapper">
          <div class="city-filter">
            <div class="label">管理员角色: </div>
            <Select style="width:200px" v-model="role">
              <Option v-for="item in roleList" :value="item.value" :key="item.value">{{ item.label }}</Option>
            </Select>
          </div>
        </div>
      </section>
    </section>
    <section class="table-wrapper">
      <div class="panel">
        <div class="content-t">管理员列表
          <div class="edit">
            <Button class="editbtn ivu-btn-primary" @click="addManage = true" v-if="showBtn('sys:sysUser:add')">新增管理员</Button>
          </div>
        </div>
      </div>
      <!--<Button type="primary" @click.native="$router.push({name: 'SystemNewBanner'})" class="new-push">新增Banner</Button>-->
      <!--<app-table ref="table" :api="$api.banner.list" :row-handle="rowHandle" :column="model"></app-table>-->
      <Table ref="selection" :columns="columns" :data="sysUserList"
             @on-select="onSelect" @on-select-cancel="onSelectCancel" @on-select-all="selectAll"></Table>
      <div style="margin: 30px 0 0 30px">
        <Button @click="handleSelectAll(true)" class="border-raudius4">全选</Button>
        <Button @click="handleSelectAll(false)" class="border-raudius4">取消全选</Button>
        <Button class="border-raudius4 bg-color" v-if="showBtn('sys:sysUser:del')" @click="deleteManagers">删除</Button>
      </div>
      <!--page-->
      <Page style="margin: 100px auto 0; width: 800px;text-align: center; padding-bottom: 100px" :current="tableParams.pages" :page-size="tableParams.size"
            :total="tableParams.total" placement="top" show-total
            show-elevator @on-change="onChangePage"></Page>
    </section>
    <!--新增管理员-->
    <Modal v-model="addManage" width="800" style="padding: 0">
      <p slot="header" style=" padding: 0">
        <span>新增管理员</span>
      </p>
      <div class="form">
        <Form ref="manage" :model="manage" :rules="ruleValidate" label-position="left" :label-width="120" style="width: 700px">
          <FormItem label="姓名：" prop="realName">
            <Input v-model="manage.realName" placeholder="请输入姓名" style="width: 250px"/>
          </FormItem>
          <FormItem label="所属部门：" prop="department">
            <Input v-model="manage.department" placeholder="请输入所属部门" style="width: 250px"/>
          </FormItem>
          <FormItem label="联系电话：" prop="telephone">
            <Input v-model="manage.telephone" placeholder="请输入联系电话" style="width: 250px"/>
          </FormItem>
          <FormItem label="账户名称：" prop="account">
            <Input v-model="manage.account" placeholder="请输入账户名称" style="width: 250px"/>
          </FormItem>
          <FormItem label="登录密码：" prop="password">
            <Input v-model="manage.password" placeholder="请输入登录密码" style="width: 250px"/>
          </FormItem>
        </Form>
      </div>
      <div slot="footer">
        <Button  @click="handleSubmit('manage')" class="checkBtn">确认</Button>
      </div>
    </Modal>
    <!--分配角色-->
    <Modal v-model="showPermissionSelect" title="分配角色" @on-ok="updateRole">
      <template>
        <RadioGroup v-for="(role, index) in selectRole" v-model="roleselect" vertical>
          <Radio :label="role.id">
            <span>{{role.role}}</span>
          </Radio>
        </RadioGroup>
      </template>
    </Modal>
  </div>
</template>
<style lang="less" rel="stylesheet/less">
  @import "../less/table";
  @import "../less/filter";
  @import "../less/search";

  .table-wrapper {
    background: white;
    padding: 10px 10px;
    .table {
      width: 100%;
    }
  }
  .border-raudius4 {
    border-radius: 4px;
  }
  .bg-color {
    background-color: #e27878;
    color: #ffffff;
    font-size: 14px;
    margin-left: 20px;
  }
  .new-push {
    margin: 10px 0;
  }
  .content-t {
    font-size: 16px;
    color: #333333;
    border-bottom: 2px solid #f0f0f0;
    padding: 20px;
    position: relative;
  }
  .edit {
    position: absolute;
    bottom: 14px;
    right: 50px;
  }
  .editbtn {
    background-color: #3dcb9d;
    border-radius: 4px;
    color: #ffffff;
    font-size: 14px;
    padding: 8px 30px;
  }
  .checkBtn {
    background-color: #3dcb9d;
    width: 130px;
    border: none;
    margin: 0 auto;
    border-radius: 3px;
    display: block;
    color: #ffffff;
    font-size: 16px;
  }
  .changebtn {
    font-size: 14px;
    color: #ffffff;
    background-color: #5ad3ac;
    border-radius: 3px;
  }
  .ivu-modal-header {
    background-color: #3dcb9d;
  }
  .ivu-modal-header-inner {
    color: #ffffff !important;
  }
  .ivu-modal-header p {
    color: #ffffff;
  }
</style>
<script type="text/ecmascript-6">

  export default{
    data () {
      const managerealName = (rule, value, callback) => {
        if (value === '') {
          return callback(new Error('请输入姓名'))
        } else {
          callback()
        }
      }
      const managedepartment = (rule, value, callback) => {
        if (value === '') {
          return callback(new Error('请输入所属部门'))
        } else {
          callback()
        }
      }
      const managetelephone = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入联系电话'))
        } else {
          let reg = /^(13[0-9]{9})|(18[0-9]{9})|(14[0-9]{9})|(17[0-9]{9})|(15[0-9]{9})$/
          if (reg.test(value) === false) {
            return callback(new Error('请输入正确的手机号码'))
          } else {
            callback()
          }
        }
      }
      const manageaccount = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入账户名称'))
        } else {
          callback()
        }
      }
      const managepassword = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入账户密码'))
        } else {
          if (value.length < 6 || value.length > 20) {
            callback(new Error('账户密码限制在6~20位'))
          } else {
            callback()
          }
        }
      }
      return {
        addManage: false,
        showPermissionSelect: false,
        selectRole: '',
        condition: '',
        tableParams: {
          size: 10,
          current: 1,
          total: 0
        },
        columns: [
          {
            type: 'selection',
            width: 60,
            align: 'center'
          },
          {
            title: '管理员ID',
            key: 'id'
          },
          {
            title: '账户名称',
            key: 'account'
          },
          {
            title: '姓名',
            key: 'realName'
          },
          {
            title: '所属部门',
            key: 'department'
          },
          {
            title: '联系电话',
            key: 'telephone'
          },
          {
            title: '管理员角色',
            key: 'role'
          },
          {
            title: '操作',
            key: 'action',
            width: 200,
            align: 'center',
            render: (h, params) => {
              let buttonSet = this.$store.state.user.user.buttonSet
              if (buttonSet.indexOf('sys:sysUser:role') >= 0) {
                return h('div', [
                  h('Button', {
                    props: {
                      size: 'small'
                    },
                    style: {
                      marginRight: '5px',
                      color: '#8bd5ff',
                      border: '1px solid #8bd5ff',
                      backgroundColor: '#ffffff',
                      fontSize: '16px',
                      width: '88px'
                    },
                    on: {
                      click: () => {
                        this.show(params.row)
                      }
                    }
                  }, '分配角色')
                ])
              } else {
                return h('span', '')
              }
            }
          }
        ],
        sysUserList: [],
        manage: {
          realName: '',
          department: '',
          telephone: '',
          account: '',
          password: ''
        },
        ruleValidate: {
          realName: [
            { validator: managerealName, trigger: 'blur' }
          ],
          department: [
            { validator: managedepartment, trigger: 'blur' }
          ],
          telephone: [
            { validator: managetelephone, trigger: 'blur' }
          ],
          account: [
            { validator: manageaccount, trigger: 'blur' }
          ],
          password: [
            { validator: managepassword, trigger: 'blur' }
          ]
        },
        roleselect: '',
        roleList: '',
        selectdeid: '',
        role: '',
        uid: ''
      }
    },
    watch: {
      roleselect () {
        console.log(this.roleselect)
      },
      role () {
        this.loadData()
      }
    },
    methods: {
      handleSubmit (name) { // 添加管理员
        this.$refs[name].validate((valid) => {
          if (valid) {
            this.$http.post('/sysUser', this.manage).then(res => {
              if (res.code === 0) {
                this.$Message.info('添加成功')
                this.addManage = false
                window.location.reload()
              } else {
                this.$Message.info('网络出错')
              }
            })
          } else {
            this.$Message.error('请把信息添加完整')
          }
        })
      },
      updateRole () { // 分配角色
        console.log(this.roleselect)
        if (this.roleselect) {
          this.$http.put('/sysUserRole', {uid: this.uid, rid: this.roleselect}).then(res => {
            if (res.code === 0) {
              this.$Message.info('保存成功')
              this.showPermissionSelect = false
              window.location.reload()
            }
          })
        } else {
          this.$Message.error('请选择角色进行分配')
        }
      },
      // 全选状态改变
      handleSelectAll (status) {
        this.$refs.selection.selectAll(status)
        if (!status) {
          this.selectdeid = ''
        }
      },
      onSelect (selection) { // 获取勾选的值
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.selectdeid = tableId.join(',')
        console.log(this.selectdeid)
      },
      onSelectCancel (selection) {  // 获取取消勾选的值
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.selectdeid = tableId.join(',')
        console.log(this.selectdeid)
      },
      selectAll (selection) { //  获取全选的值
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.selectdeid = tableId.join(',')
        console.log(this.selectdeid)
        return tableId
      },
      show (row) { // 点击分配角色事件
       // this.$router.push({name: 'NewsDetail', query: {id: row.id}})
        this.showPermissionSelect = true
        this.roleselect = row.rid
        this.uid = row.id
        this.$http.get('/sysRole/list').then(res => {
          this.selectRole = res.sysRoleList
        })
      },
      onChangePage (page) {
        // 改变页码
        this.tableParams.current = page
        this.loadData()
      },
      loadData () {
        this.$http.get('/sysUser/page/' + this.tableParams.current, {params: {condition: this.condition, role: this.role}}).then(res => {
          this.sysUserList = res.vSysUserRolePage.records
          this.tableParams.current = res.vSysUserRolePage.current
          this.tableParams.total = res.vSysUserRolePage.total
          this.tableParams.size = res.vSysUserRolePage.size
        })
      },
      deleteManagers () { // 删除
        if (this.selectdeid) {
          this.$Modal.confirm({
            title: '确认删除',
            content: '操作无法撤销 是否执行?',
            onOk: () => {
              this.$http.delete('/sysUser/' + this.selectdeid, {ids: this.selectdeid}).then(res => {
                if (res.code === 0) {
                  this.$Message.success('删除成功')
                  this.loadData()
                }
              })
            }
          })
        } else {
          this.$Message.error('请勾选删除项')
        }
      }
    },
    mounted () {
      this.$nextTick(() => {
        this.loadData()
        this.$http.get('/sysRole/iviewList').then(res => {
          if (res.code === 0) {
            this.roleList = res.roleList
          } else {
            this.$Message.error('系统出现错误，请联系管理员')
          }
        })
      })
    }
  }
</script>
