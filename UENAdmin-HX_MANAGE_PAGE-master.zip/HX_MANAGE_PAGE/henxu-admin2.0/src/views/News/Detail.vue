<template>
  <div>
    <section class="panel">
      <div class="newcont">资讯编辑</div>
      <Row class="base-info">
        <i-col :span="22">
          <div class="wrapper">
            <div class="label top">资讯缩略图: </div>
            <div class="value">
              <Row class="banner">
                <img-upload3 v-model="form.imageUrl" :max="1"></img-upload3>
              </Row>
            </div>
          </div>
        </i-col>
        <i-col :span="22">
          <div class="wrapper">
            <div class="label">资讯标题: </div>
            <div class="value">
              <i-input placeholder="标题" v-model="form.title"></i-input>
            </div>
          </div>
        </i-col>
        <i-col :span="22">
          <div class="wrapper">
            <div class="label">作者: </div>
            <div class="value">
              <i-input placeholder="作者" v-model="form.author"></i-input>
            </div>
          </div>
        </i-col>
        <i-col :span="22">
          <div class="wrapper">
            <div class="label">资讯内容: </div>
            <div class="value">
              <kind-editor v-model="form.content"></kind-editor>
              <Row style="padding: 10px 0">
                <Button type="primary" @click.native="save" v-if="showBtn('sys:news:add')">发布</Button>
                <Button type="primary" @click.native="goPreview">预览</Button>
              </Row>
            </div>
          </div>
        </i-col>
      </Row>
    </section>
    <Modal v-model="showHtmlPreview" :styles="{top: 0}" width="800" id="html-preview">
      <div class="preview" style="font-size: 16px;">
        <!--<div class="title">-->
        <!--<h2>{{form.title}}</h2>-->
        <!--<p>{{form.author}}</p>-->
        <!--</div>-->
        <div v-html="form.content"></div>
      </div>
      <div slot="footer">
        <Button type="success" @click.native="showHtmlPreview = false">关闭</Button>
      </div>
    </Modal>
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
  .panel {
    margin-bottom: 15px;
    background: white;
  }
  .newcont {
    background-color: #3bca9a;
    font-size: 16px;
    color: #ffffff;
    padding: 20px;
  }
  #html-preview {
    .preview {
      .title {
        margin-bottom: 15px;
        h2 {
          font-size: 18px;
          padding: 10px 0;
        }
      }
    }
  }

  .preview {
    padding: 10px 30px;
  }

  .base-info {
    background: white;
    padding: 15px;
    margin-top: 15px;
    .wrapper {
      display: flex;
      width: 100%;
      margin-bottom: 20px;
      .label {
        flex: 0 0 100px;
        font-size: 16px;
        text-align: right;
        padding-right: 15px;
        vertical-align: top;
        &.top {
          align-self: flex-start;
        }
      }
      .value {
        flex: 1;
      }
    }
  }
</style>
<script type="text/ecmascript-6">
  import KindEditor from '../../components/common/kind-editor.vue'
  export default {
    components: {
      KindEditor
    },
    data () {
      return {
        showType1: ['1', '2'],
        form: {
          title: '',
          author: '',
          content: '',
          clientId: '',
          imageUrl: ''
        },
        showHtmlPreview: false,
        thisRouter: this.$route.query.id
      }
    },
    watch: {
      showType1 () {
        this.form.showType = this.showType1
      }
    },
    methods: {
      goPreview () {
        this.showHtmlPreview = true
      },
      save () {
        if (!this.form.title) {
          this.$Notice.warning({
            title: '请填写标题',
            desc: '资讯标题必填'
          })
          return
        }
        if (!this.form.author) {
          this.$Notice.warning({
            title: '请填写作者',
            desc: '作者必填'
          })
          return
        }
        if (!this.form.content) {
          this.$Notice.warning({
            title: '请输入内容',
            desc: '资讯内容必填'
          })
          return
        }
        if (this.$route.query.id) {
          console.log(this.$route.query.id)
          this.$http.put('/news/' + this.thisRouter, Object.assign({}, this.form, this.$route.query)).then(res => {
            if (res.code === 0) {
              this.$Message.info('操作成功')
              this.$router.back()
            }
          })
        } else {
          this.$http.post('/news', Object.assign({}, this.form)).then(res => {
            if (res.code === 0) {
              this.$Message.info('操作成功')
              this.$router.back()
            }
          })
        }
      }
    },
    mounted () {
      if (this.$route.query.id) {
        this.$http.get('/news/' + this.thisRouter, this.$route.query).then(res => {
          this.form = res.infoNews
        })
      }
    }
  }
</script>
