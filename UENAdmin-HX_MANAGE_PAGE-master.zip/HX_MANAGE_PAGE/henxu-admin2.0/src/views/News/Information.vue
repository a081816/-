<template>
  <div>
    <section class="table-wrapper">
      <div class="panel">
        <div class="content-t">资讯列表
          <div class="edit">
            <router-link to="/News/Detail"><Button class="editbtn ivu-btn-primary" v-if="showBtn('sys:news:add')">新增资讯</Button></router-link>
          </div>
        </div>
      </div>
      <!--<Button type="primary" @click.native="$router.push({name: 'SystemNewBanner'})" class="new-push">新增Banner</Button>-->
      <!--<app-table ref="table" :api="$api.banner.list" :row-handle="rowHandle" :column="model"></app-table>-->
      <Table ref="selection" :columns="columns" :data="data"
             @on-select="onSelect" @on-select-cancel="onSelectCancel" @on-select-all="selectAll"></Table>
      <div style="margin: 30px 0 0 30px">
        <Button @click="handleSelectAll(true)" class="border-raudius4">全选</Button>
        <Button @click="handleSelectAll(false)" class="border-raudius4">取消全选</Button>
        <Button class="border-raudius4 bg-color" @click="deleteNew" v-if="showBtn('sys:news:del')">删除</Button>
      </div>
      <!--page-->
      <Page style="margin: 100px auto 0; width: 800px;text-align: center; padding-bottom: 100px" :current="tableParams.current" :page-size="tableParams.pageSize"
            :total="tableParams.total" placement="top" show-total
            show-elevator @on-change="onChangePage"></Page>
    </section>
  </div>
</template>
<style lang="less" rel="stylesheet/less">
  @import "../../less/table";

  .table-wrapper {
    background: white;
    padding: 10px 10px;
    .table {
      width: 100%;
    }
  }
  .border-raudius4 {
    border-radius: 4px;
  }
  .bg-color {
    background-color: #e27878;
    color: #ffffff;
    font-size: 14px;
    margin-left: 20px;
  }
  .new-push {
    margin: 10px 0;
  }
  .content-t {
    font-size: 16px;
    color: #333333;
    border-bottom: 2px solid #f0f0f0;
    padding: 20px;
    position: relative;
  }
  .edit {
    position: absolute;
    bottom: 14px;
    right: 50px;
  }
  .editbtn {
    background-color: #3dcb9d;
    border-radius: 4px;
    color: #ffffff;
    font-size: 14px;
    padding: 8px 30px;
  }
  .checkBtn {
    background-color: #3dcb9d;
    width: 130px;
    border: none;
    margin: 0 auto;
    border-radius: 3px;
    display: block;
    color: #ffffff;
    font-size: 16px;
  }
  .changebtn {
    font-size: 14px;
    color: #ffffff;
    background-color: #5ad3ac;
    border-radius: 3px;
  }
</style>
<script type="text/ecmascript-6">
  export default{
    data () {
      return {
        showEditbanner: false,
        newSelectId: '',
        tableParams: {
          pageSize: 10,
          current: 1,
          total: 0
        },
        columns: [
          {
            type: 'selection',
            width: 60,
            align: 'center'
          },
          {
            title: 'ID',
            key: 'id'
          },
          {
            title: '标题',
            key: 'title'
          },
          {
            title: '作者',
            key: 'author'
          },
          {
            title: '发布时间',
            key: 'updateTime'
          },
          {
            title: '操作',
            key: 'action',
            width: 200,
            align: 'center',
            render: (h, params) => {
              let buttonSet = this.$store.state.user.user.buttonSet
              if (buttonSet.indexOf('sys:news:edit') >= 0) {
                return h('div', [
                  h('Button', {
                    props: {
                      size: 'small'
                    },
                    style: {
                      marginRight: '5px',
                      color: '#8bd5ff',
                      border: '1px solid #8bd5ff',
                      backgroundColor: '#ffffff',
                      fontSize: '16px',
                      width: '88px'
                    },
                    on: {
                      click: () => {
                        this.show(params.row)
                      }
                    }
                  }, '编辑')
                ])
              } else {
                return h('span', '')
              }
            }
          }
        ],
        data: [],
        editRow: null,
        showEditModal: false
      }
    },
    methods: { // 全选状态改变
      handleSelectAll (status) {
        this.$refs.selection.selectAll(status)
        if (!status) {
          this.newSelectId = ''
        }
      },
      onSelect (selection) { // 获取勾选的值
        console.log(selection)
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.newSelectId = tableId.join(',')
        console.log(tableId)
      },
      onSelectCancel (selection) {  // 获取取消勾选的值
        console.log(selection)
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.newSelectId = tableId.join(',')
        console.log(tableId)
      },
      selectAll (selection) { //  获取全选的值
        console.log(selection)
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.newSelectId = tableId.join(',')
        console.log(tableId)
        return tableId
      },
      deleteNew () { // 删除传递电站id字符串
        if (this.newSelectId) {
          this.$Modal.confirm({
            title: '确认删除',
            content: '操作无法撤销 是否执行?',
            onOk: () => {
              this.$http.delete('/news/' + this.newSelectId).then(res => {
                if (res.code === 0) {
                  this.$Message.success('删除成功')
                  this.loadData()
                }
              })
            }
          })
        } else {
          this.$Message.error('请勾选删除项')
        }
      },
      show (row) {
        this.$router.push({name: 'NewsDetail', query: {id: row.id}})
      },
      getRequestParams () {
        return Object.assign({}, {
          current: this.tableParams.current - 1
        })
      },
      onChangePage (page) {
        // 改变页码
        this.tableParams.current = page
        this.loadData()
      },
      loadData () {
        this.$nextTick(() => { // Object.assign({}, this.getRequestParams())
          this.$http.get('/news/page/' + this.tableParams.current).then(res => {
            if (res.code === 0) {
              this.data = res.infoNewsPage.records
              this.tableParams.current = res.infoNewsPage.current
              this.tableParams.pageSize = res.infoNewsPage.size
              this.tableParams.total = res.infoNewsPage.total
            } else {
              this.$Message.info('网络出错')
            }
          })
        })
      }
    },
    mounted () {
      this.$nextTick(() => {
        this.loadData()
      })
    }
  }
</script>
