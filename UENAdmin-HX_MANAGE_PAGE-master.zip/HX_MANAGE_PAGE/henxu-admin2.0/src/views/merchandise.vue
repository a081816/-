<template>
  <div>
    <section class="panel">
      <Row style="display: flex">
        <i-col class="side" :span="8">
          <Row>
            <i-col :span="8" class="tab-item" @click.native="type=1" :class="{active: type===1}">商品方案</i-col>
            <i-col :span="8" class="tab-item" @click.native="type=2" :class="{active: type===2}">选配项目</i-col>
          </Row>
        </i-col>
        <i-col class="side right" :span="16">
          <template v-if="type == 1">
            <Button type="primary" @click="newBrand" v-if="showBtn('sys:product:planAdd')">新增方案</Button>
          </template>
          <template v-else>
            <Button type="primary" @click="newBrand" v-if="showBtn('sys:product:selectionAdd')">新增项目</Button>
          </template>
        </i-col>
      </Row>
    </section>
    <section class="panel device-list">
      <template v-if="type===1">
        <!--方案table-->
        <section class="table-wrapper">
          <Table ref="selection" :columns="columns" :data="data"
                 @on-select="onSelect" @on-select-cancel="onSelectCancel" @on-select-all="selectAll"></Table>
          <div style="margin: 30px 0 0 30px">
            <Button @click="handleSelectAll(true)" class="border-raudius4">全选</Button>
            <Button @click="handleSelectAll(false)" class="border-raudius4">取消全选</Button>
            <Button class="border-raudius4 bg-color" v-if="showBtn('sys:product:planDel')" @click="deleteProductProject">删除</Button>
          </div>
          <!--page-->
          <div class="table-page">
            <Page style="margin: 100px auto 0; width: 800px;text-align: center; padding-bottom: 100px"  :current="pageParams.page" :page-size="pageParams.pageSize"
                  :total="pageParams.total" placement="top" show-total
                  show-elevator @on-change="onChangePage"></Page>
          </div>
        </section>
      </template>
      <template v-else>
        <!--选配项目table-->
        <section class="table-wrapper">
          <Table ref="selection" :columns="columns2" :data="data2"
                 @on-select="onSelect1" @on-select-cancel="onSelectCancel1" @on-select-all="selectAll1"></Table>
          <div style="margin: 30px 0 0 30px">
            <Button @click="handleSelectAll1(true)" class="border-raudius4">全选</Button>
            <Button @click="handleSelectAll1(false)" class="border-raudius4">取消全选</Button>
            <Button class="border-raudius4 bg-color" v-if="showBtn('sys:product:selectionDel')" @click="deleteSelectionProject">删除</Button>
          </div>
          <!--page-->
          <div class="table-page">
            <Page style="margin: 100px auto 0; width: 800px;text-align: center; padding-bottom: 100px" :current="pageParams1.current" :page-size="pageParams1.pageSize"
                  :total="pageParams1.total" placement="top" show-total
                  show-elevator @on-change="onChangePage1"></Page>
          </div>
        </section>
      </template>
    </section>
    <!--新增、修改方案-->
    <Modal v-model="addPlan" width="800" style="padding: 0">
      <p slot="header" style=" padding: 0">
        <span>新增方案</span>
      </p>
      <div class="form">
        <Form ref="materialValidate" :model="materialValidate" label-position="left" :label-width="120" style="width: 700px">
          <FormItem label="方案名称：">
            <Input v-model="materialValidate.projectName" placeholder="请输入方案名称" style="width: 250px"/>
          </FormItem>
          <FormItem label="方案价格：">
            <Input v-model="materialValidate.price" placeholder="请输入方案价格" style="width: 250px"/>
          </FormItem>
          <FormItem label="适用装机容量：">
            <Input v-model="materialValidate.meterialInfo.capacity" placeholder="请输入适用装机容量" style="width: 250px"/>
          </FormItem>
          <FormItem label="逆变器：">
            <Row>
              <Col span="11">
              <FormItem prop="inverterBrand">
                <Input v-model="materialValidate.meterialInfo.inverterBrand" placeholder="请输入设备品牌" style="width: 250px" />
              </FormItem>
              </Col>
              <Col span="11" offset="1">
              <FormItem prop="inverterModel">
                <Input v-model="materialValidate.meterialInfo.inverterModel" placeholder="请输入设备型号" style="width: 250px"/>
              </FormItem>
              </Col>
            </Row>
          </FormItem>
          <FormItem label="电池板：">
            <Row>
              <Col span="11">
              <FormItem prop="BatteryBrand">
                <Input v-model="materialValidate.meterialInfo.solarPanelBrand" placeholder="请输入设备品牌" style="width: 250px"/>
              </FormItem>
              </Col>
              <Col span="11" offset="1">
              <FormItem prop="BatteryModel">
                <Input v-model="materialValidate.meterialInfo.solarPanelModel" placeholder="请输入设备型号" style="width: 250px"/>
              </FormItem>
              </Col>
            </Row>
          </FormItem>
          <FormItem label="其他材料：">
            <Input v-model="materialValidate.meterialInfo.otherMeterial" type="textarea" :autosize="{minRows: 4,maxRows: 5}" placeholder="其他材料" />
          </FormItem>
          <FormItem label="配选项目：">
            <CheckboxGroup v-model="checkboxnum">
              <template  v-for="item in checkboxList">
                <Checkbox :label="item.id">{{item.projectName}}</Checkbox>
              </template>
            </CheckboxGroup>
          </FormItem>
        </Form>
      </div>
      <div slot="footer">
        <Button  @click="handleSubmit('materialValidate')" class="checkBtn ivu-btn-primary">确认</Button>
      </div>
    </Modal>
    <!--新增项目-->
    <Modal v-model="addProject" width="800" style="padding: 0">
      <p slot="header" style=" padding: 0">
        <span>新增配选项目</span>
      </p>
      <div class="form">
        <Form ref="editProject" :model="editProject" :rules="ruleValidate" label-position="left" :label-width="120" style="width: 700px">
          <FormItem label="选配项目：" prop="projectName">
            <Input v-model="editProject.projectName" placeholder="选配项目" style="width: 250px"/>
          </FormItem>
          <FormItem label="价格：" prop="price">
            <Input v-model="editProject.price" placeholder="请输入项目金额" style="width: 250px"/>
          </FormItem>
        </Form>
      </div>
      <div slot="footer">
        <Button  @click="handleSubmit('editProject')" class="checkBtn ivu-btn-primary">确认</Button>
      </div>
    </Modal>

  </div>
</template>
<style lang="less" rel="stylesheet/less">
  @import "../less/table";

  #app #main-wrapper {
    width: 100%;
    overflow: hidden;
  }
  .table-page {
    display: block;
    width: 100%;
    background: white;
    margin-top: 20px;
    margin-bottom: 10px;
    padding: 10px;
  }
  table {
    tr {
      border-bottom: 1px dashed #ababab;
      &:last-child {
        border: none;
      }
    }
  }
  .device-list {
    .title {
      font-size: 18px;
      padding: 15px 15px 0 15px;
    }
  }
  .panel {
    background: white;
    margin-bottom: 15px;
    .side {
      align-self: center;
      &.right {
        text-align: right;
        padding-right: 20px;
      }
    }
    .tab-item {
      background: white;
      line-height: 30px;
      padding: 10px;
      font-size: 18px;
      text-align: center;
      cursor: pointer;
      position: relative;
      &:after {
        content: ' ';
        width: 1px;
        height: 20px;
        display: block;
        background: #c4c4c4;
        position: absolute;
        right: 0;
        top: 15px;
      }
      &:last-child {
        &:after {
          width: 0;
        }
      }
      &.active {
        background-color: #3dcb9d;
        color: white;
        &:after {
          width: 0;
        }
      }
    }
  }
  .checkBtn {
    background-color: #3dcb9d;
    width: 130px;
    border: none;
    margin: 0 auto;
    border-radius: 3px;
    display: block;
    color: #ffffff;
    font-size: 16px;
  }
  .ivu-modal-header {
    background-color: #3dcb9d !important;
  }
  .ivu-modal-header p {
    color: #ffffff !important;
  }
  .bg-color {
    background-color: #e27878;
    color: #ffffff;
    font-size: 14px;
    margin-left: 20px;
  }
</style>
<script type="text/ecmascript-6">
  export default {
    data () {
      const projectName = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入选配项目'))
        } else {
          callback()
        }
      }
      const price = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入项目金额'))
        } else {
          callback()
        }
      }
      const validateprojectName = (rule, value, callback) => {
        if (value.length === 0) {
          callback(new Error('请输入方案名称'))
        } else {
          callback()
        }
      }
      const validateprojectPrice = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入方案价格'))
        } else {
          callback()
        }
      }
      const validatecapacity = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入装机容量'))
        } else {
          callback()
        }
      }
      const validateinverterBrand = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入逆变器品牌'))
        } else {
          callback()
        }
      }
      const validateinverterModel = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入逆变器型号'))
        } else {
          callback()
        }
      }
      const validateBatteryBrand = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入电池板品牌'))
        } else {
          callback()
        }
      }
      const validateBatteryModel = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入电池板型号'))
        } else {
          callback()
        }
      }
      const validateothers = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入其他材料'))
        } else {
          callback()
        }
      }
      return {
        type: 1,
        addPlan: false,
        addProject: false,
        devices: [],
        editBrandIndex: null,
        newBrandName: '',
        brandName: '',
        showEditModal: false,
        showEditModal1: false,
        onEditDevice: null,
        planinfojson: null,
        meterialInfo: [],
        strplaninfo: null,
        pageParams: {
          pageSize: 10,
          current: 1,
          total: 0
        },
        pageParams1: {
          pageSize: 10,
          current: 1,
          total: 0
        },
        columns: [
          {
            type: 'selection',
            width: 60,
            align: 'center'
          },
          {
            title: '方案ID',
            key: 'id',
            width: '100'
          },
          {
            title: '方案',
            key: 'projectName',
            render: (h, params) => { // 根据值过滤
              const row = params.row.projectName
              return h('span', row)
            }
          },
          {
            title: '方案价格',
            key: 'price'
          },
          {
            title: '方案信息',
            key: 'meterialInfo',
            render: (h, params) => {
              const column = params.row.meterialInfo
              // return h('p', '装机容量：' + column.capacity + '电池板品牌' + column.solarPanelBrand)
              return h('div', [
                h('p', '适用装机容量：' + column.capacity + 'KW'),
                h('p', '电池板品牌：' + column.solarPanelBrand),
                h('p', '电池板型号：' + column.solarPanelModel),
                h('p', '逆变器品牌：' + column.inverterBrand),
                h('p', '逆变器型号：' + column.inverterModel),
                h('p', '其他材料：' + column.otherMeterial)
              ])
            }
          },
          {
            title: '选配项目',
            key: 'selectionProjectList',
            render: (h, params) => { // 根据值过滤
              const row = params.row.selectionProjectList
              let ProjectList = []
              for (let key in row) {
                ProjectList.push(row[key])
              }
              if (ProjectList.length > 0) {
                return h('ul', ProjectList.map(function (ProjectList) {
                  return h('li', ProjectList.projectName + '/' + ProjectList.price + '元')
                }))
              } else {
                return h('p', '暂无配选项目信息')
              }
            }
          },
          {
            title: '操作',
            key: 'action',
            width: 150,
            align: 'center',
            render: (h, params) => {
              let buttonSet = this.$store.state.user.user.buttonSet
              if (buttonSet.indexOf('sys:product:plan') >= 0) {
                return h('div', [
                  h('Button', {
                    props: {
                      type: 'primary',
                      size: 'small'
                    },
                    style: {
                      marginRight: '5px',
                      color: '#8bd5ff',
                      border: '1px solid #8bd5ff',
                      backgroundColor: '#ffffff',
                      fontSize: '16px',
                      width: '88px'
                    },
                    on: {
                      click: () => {
                        this.show(params.index)
                        this.materialValidate = params.row
                        let row = params.row.selectionProjectList
                        let ProjectList = []
                        if (row.length > 0) {
                          for (let key in row) {
                            ProjectList.push(row[key].id)
                          }
                        }
                        this.checkboxnum = ProjectList
                        this.materialValidate.checkbox = ProjectList
                        // console.log(this.materialValidate.checkbox)
                      }
                    }
                  }, '编辑')
                ])
              } else {
                return h('span', '')
              }
            }
          }
        ],
        data: [],
        columns2: [
          {
            type: 'selection',
            width: 60,
            align: 'center'
          },
          {
            title: '项目ID',
            key: 'id'
          },
          {
            title: '选配项目',
            key: 'projectName'
          },
          {
            title: '项目价格(元)',
            key: 'price'
          },
          {
            title: '操作',
            key: 'action',
            width: 150,
            align: 'center',
            render: (h, params) => {
              let buttonSet = this.$store.state.user.user.buttonSet
              if (buttonSet.indexOf('sys:product:selection') >= 0) {
                return h('div', [
                  h('Button', {
                    props: {
                      type: 'primary',
                      size: 'small'
                    },
                    style: {
                      marginRight: '5px',
                      color: '#8bd5ff',
                      border: '1px solid #8bd5ff',
                      backgroundColor: '#ffffff',
                      fontSize: '16px',
                      width: '88px'
                    },
                    on: {
                      click: () => {
                        this.addProject = true
                        this.editProject = params.row
                      }
                    }
                  }, '编辑')
                ])
              } else {
                return h('span', '')
              }
            }
          }
        ],
        data2: [],
        materialValidate: {
          projectName: '',
          price: '',
          meterialInfo: {
            capacity: '',
            solarPanelBrand: '',
            solarPanelModel: '',
            inverterBrand: '',
            inverterModel: '',
            otherMeterial: ''
          },
          checkbox: []
        },
        editProject: {
          id: '',
          projectName: '',
          price: ''
        },
        ruleValidate: {
          projectName: [
            { validator: projectName, trigger: 'blur' }
          ],
          price: [
            { validator: price, trigger: 'blur' }
          ]
        },
        ruleValidate1: {
          projectName: [
            { validator: validateprojectName, trigger: 'blur' }
          ],
          price: [
            { validator: validateprojectPrice, trigger: 'blur' }
          ],
          capacity: [
            { validator: validatecapacity, trigger: 'blur' }
          ],
          inverterBrand: [
            { validator: validateinverterBrand, trigger: 'blur' }
          ],
          inverterModel: [
            { validator: validateinverterModel, trigger: 'blur' }
          ],
          BatteryBrand: [
            { validator: validateBatteryBrand, trigger: 'blur' }
          ],
          BatteryModel: [
            { validator: validateBatteryModel, trigger: 'blur' }
          ],
          otherMeterial: [
            { validator: validateothers, trigger: 'blur' }
          ],
          checkbox: [
            { required: true, type: 'array', min: 1, message: '最少选择一个配选项目', trigger: 'change' }
          ]
        },
        productProjectSelectId: '',
        selectionProjectSelectId: '',
        checkboxList: [],
        checkboxnum: []
      }
    },
    watch: {
      type: 'loadData',
      pageParams: 'loadData',
      checkboxnum (vaule) {
        this.materialValidate.checkbox = vaule
        console.log(this.materialValidate.checkbox)
      }
    },
    methods: {
      handleSubmit (name) {
        if (name === 'materialValidate') {
          if (!this.materialValidate.projectName) {
            this.$Message.error('请填写方案名称')
            return
          }
          if (!this.materialValidate.price) {
            this.$Message.error('请填写方案价格')
            return
          }
          if (!this.materialValidate.meterialInfo.capacity) {
            this.$Message.error('请填写装机容量')
            return
          } else {
            let reg = /^[0-9]+.?[0-9]*$/
            if (reg.test(this.materialValidate.meterialInfo.capacity) === false) {
              this.$Message.error('装机容量只能填写数字')
              return
            }
          }
          if (!this.materialValidate.meterialInfo.inverterBrand) {
            this.$Message.error('请填写逆变器品牌')
            return
          }
          if (!this.materialValidate.meterialInfo.inverterModel) {
            this.$Message.error('请填写逆变器型号')
            return
          }
          if (!this.materialValidate.meterialInfo.solarPanelBrand) {
            this.$Message.error('请填写电池板品牌')
            return
          }
          if (!this.materialValidate.meterialInfo.solarPanelModel) {
            this.$Message.error('请填写电池板型号')
            return
          }
          if (!this.materialValidate.meterialInfo.otherMeterial) {
            this.$Message.error('请填写方案其他材料')
            return
          }
          console.log(this.materialValidate.checkbox.join(','))
          if (this.materialValidate.id) {
            this.$http.put('/product/' + this.materialValidate.id, this.getRequestParams()).then(res => {
              if (res.code === 0) {
                this.$Message.success('修改方案成功')
                this.addPlan = false
                this.loadData()
              }
            })
          } else {
            this.$http.post('/product', this.getRequestParams()).then(res => {
              if (res.code === 0) {
                this.$Message.success('添加方案成功')
                this.addPlan = false
                this.loadData()
              }
            })
          }
        } else {
          this.$refs[name].validate((valid) => {
            if (valid) {
              if (name === 'editProject') {
                console.log(this.editProject.id)
                if (this.editProject.id) {
                  this.$http.put('/selectionProject/' + this.editProject.id, Object.assign({}, this.editProject)).then(res => {
                    if (res.code === 0) {
                      this.$Message.success('操作成功!')
                      this.addProject = false
                      this.loadData1()
                    }
                  })
                } else {
                  this.$http.post('/selectionProject', Object.assign({}, this.editProject)).then(res => {
                    if (res.code === 0) {
                      this.$Message.success('操作成功!')
                      this.addProject = false
                      this.loadData1()
                    }
                  })
                }
              }
            } else {
              this.$Message.error('Fail!')
            }
          })
        }
      },
      // 获取请求参数
      getRequestParams () {
        return Object.assign({}, {
          id: this.materialValidate.id,
          selectionProjectIdList: this.materialValidate.checkbox.join(','),
          projectName: this.materialValidate.projectName,
          capacity: this.materialValidate.meterialInfo.capacity,
          price: this.materialValidate.price,
          solarPanelBrand: this.materialValidate.meterialInfo.solarPanelBrand,
          solarPanelModel: this.materialValidate.meterialInfo.solarPanelModel,
          inverterBrand: this.materialValidate.meterialInfo.inverterBrand,
          inverterModel: this.materialValidate.meterialInfo.inverterModel,
          otherMeterial: this.materialValidate.meterialInfo.otherMeterial
        })
      },
      // 删除选配项目
      deleteSelectionProject () {
        if (this.selectionProjectSelectId) {
          this.$Modal.confirm({
            title: '确认删除',
            content: '操作无法撤销 是否执行?',
            onOk: () => {
              this.$http.delete('/selectionProject/' + this.selectionProjectSelectId).then(res => {
                if (res.code === 0) {
                  this.$Message.success('删除成功')
                  this.loadData()
                }
              })
            }
          })
        } else {
          this.$Message.error('请勾选删除项')
        }
      },
      // 删除方案
      deleteProductProject () {
        if (this.productProjectSelectId) {
          this.$Modal.confirm({
            title: '确认删除',
            content: '操作无法撤销 是否执行?',
            onOk: () => {
              this.$http.delete('/product/' + this.productProjectSelectId).then(res => {
                if (res.code === 0) {
                  this.$Message.success('删除成功')
                  this.loadData()
                }
              })
            }
          })
        } else {
          this.$Message.error('请勾选删除项')
        }
      },
      // 全选状态改变
      handleSelectAll (status) {
        this.$refs.selection.selectAll(status)
        if (!status) {
          this.productProjectSelectId = ''
        }
      },
      handleSelectAll1 (status) {
        this.$refs.selection.selectAll(status)
        if (!status) {
          this.selectionProjectSelectId = ''
        }
      },
      onSelect (selection) { // 获取勾选的值
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.productProjectSelectId = tableId.join(',')
        console.log(this.productProjectSelectId)
      },
      onSelect1 (selection) { // 获取勾选的值
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.selectionProjectSelectId = tableId.join(',')
        console.log(this.selectionProjectSelectId)
      },
      onSelectCancel (selection) {  // 获取取消勾选的值
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.productProjectSelectId = tableId.join(',')
        console.log(this.productProjectSelectId)
      },
      onSelectCancel1 (selection) {  // 获取取消勾选的值
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.selectionProjectSelectId = tableId.join(',')
        console.log(this.selectionProjectSelectId)
      },
      selectAll (selection) { //  获取全选的值
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.productProjectSelectId = tableId.join(',')
        console.log(this.productProjectSelectId)
        return tableId
      },
      selectAll1 (selection) { //  获取全选的值
        let tableId = []
        Object(selection).forEach(key => {
          tableId.push(key.id)
        })
        this.selectionProjectSelectId = tableId.join(',')
        console.log(this.selectionProjectSelectId)
        return tableId
      },
      show (index) {
        this.addPlan = true
        this.getSelectProList()
      },
      getSelectProList () {
        this.$http.get('selectionProject/list').then(res => {
          if (res.code === 0) {
            this.checkboxList = res.selectionProjectList
          }
        })
      },
      show1 (params, index) {
        console.log(params)
        console.log(index)
      },
      onChangePage (page) {
        // 改变页码
        this.pageParams.current = page
        this.loadData()
      },
      onChangePage1 (page) {
        // 改变页码
        this.pageParams1.current = page
        this.loadData1()
      },
      newBrand () {
        if (this.type === 1) {
          this.addPlan = true
          this.getSelectProList()
          this.materialValidate = {
            projectName: '',
            price: '',
            meterialInfo: {
              capacity: '',
              solarPanelBrand: '',
              solarPanelModel: '',
              inverterBrand: '',
              inverterModel: '',
              otherMeterial: ''
            },
            checkbox: []
          }
          this.checkboxnum = []
        } else {
          this.addProject = true
          this.editProject = {
            id: '',
            projectName: '',
            price: ''
          }
        }
      },
      updateBrand (index, brandName) {
        this.$http.post(this.$api.brand.save, {
          brandName: brandName,
          type: this.type,
          id: this.devices[index].id
        }).then(res => {
          if (res.code === 200) {
            this.$Message.info('更新成功')
            this.editBrandIndex = null
          }
        })
      },
      loadData () {
        this.$http.get('/product/page/' + this.pageParams.current).then(res => {
          this.data = res.productProject4Page.records
          this.pageParams.total = res.productProject4Page.total
          this.pageParams.current = res.productProject4Page.current
          this.pageParams.pageSize = res.productProject4Page.size
        })
      },
      loadData1 () { // 选配项目
        this.$http.get('/selectionProject/page/' + this.pageParams1.current).then(res => {
          this.data2 = res.selectionProjectPage.records
          this.pageParams1.total = res.selectionProjectPage.total
          this.pageParams1.current = res.selectionProjectPage.current
          this.pageParams1.pageSize = res.selectionProjectPage.size
        })
      }
    },
    mounted () {
      this.loadData()
      this.loadData1()
    }
  }
</script>
