<template>
  <div>
    <section class="search-panel">
      <div class="input-wrapper">
        <div class="input-container">
          <input class="inputs" v-model="condition" @keyup.enter="loadData" placeholder="账号/真实姓名/地址/手机号" type="text">
          <Button type="success" @click="loadData" class="searchs">搜索</Button>
        </div>
      </div>
    </section>
    <!--table-->
    <section class="table-wrapper" style="padding-top: 50px">
      <Table :columns="columns" :data="data"></Table>
      <!--page-->
      <Page style="margin: 100px auto 0; width: 800px;text-align: center; padding-bottom: 100px" :current="tableParams.current" :page-size="tableParams.pageSize"
            :total="tableParams.total" placement="top" show-total
            show-elevator @on-change="onChangePage"></Page>
    </section>
  </div>
</template>
<style lang="less" rel="stylesheet/less">
  @import "../../less/search";
  @import "../../less/table";

  .table-page {
    background-color: #ffffff;
    height: 40px;
    width: 90%;
    border: none;
    margin: 20px auto;
  }
  .table-wrapper {
    background: white;
    .table {
      width: 100%;
    }
  }
  .floatLeft {
    display:block;
    float: left;
  }
  .border-raudius4 {
    border-radius: 4px;
  }
  .bg-color {
    background-color: #e27878;
    color: #ffffff;
    font-size: 14px;
    margin-left: 20px;
  }
</style>
<script type="text/ecmascript-6">
  import AreaSelect from '../../components/common/area-select.vue'

  export default {
    components: {
      AreaSelect
    },
    data () {
      return {
        payStatus: '',
        tableParams: {
          pageSize: 10,
          current: 1,
          total: 0
        },
        advanceList: [
          '未开始', '材料进场', '基础建筑', '支架安装', '光伏板安装', '直流接线', '电箱逆变器', '汇流箱安装', '交流辅线', '防雷接地测试', '并网验收'
        ],
        columns: [
          {
            title: '用户ID',
            key: 'id',
            width: '100'
          },
          {
            title: '用户姓名',
            key: 'realName',
            width: '200'
          },
          {
            title: '账号',
            key: 'account',
            width: '200'
          },
          {
            title: '联系电话',
            key: 'telephone',
            width: '150'
          },
          {
            title: '联系地址',
            key: 'address'
          },
          {
            title: '注册时间',
            key: 'registerTime',
            width: '200'
          },
          {
            title: '操作',
            key: 'action',
            width: 150,
            align: 'center',
            render: (h, params) => {
              let buttonSet = this.$store.state.user.user.buttonSet
              if (buttonSet.indexOf('sys:user:detail') >= 0) {
                return h('div', [
                  h('Button', {
                    props: {
                      type: 'primary',
                      size: 'small'
                    },
                    style: {
                      marginRight: '5px',
                      border: '1px soild #3dcb9d',
                      color: '#3dcb9d',
                      backgroundColor: '#ffffff',
                      borderRadius: '3px'

                    },
                    on: {
                      click: () => {
                        this.show(params.index)
                      }
                    }
                  }, '用户详情')
                ])
              } else {
                return h('span', '')
              }
            }
          }
        ],
        data: [],
        form: {
          status: '',
          provinceId: '',
          cityId: ''
        },
        condition: '',
        list: [],
        provinceList: [],
        tableId: [],
        rowClick: (row) => {
          this.$router.push({name: 'UserDetail', query: {id: row.id}})
        }
      }
    },
    watch: {
      form: {
        deep: true,
        handler: 'loadData'
      }
    },
    computed: {
      customParams () {
        let list = []
        Object.keys(this.form).forEach(key => {
          list.push({
            key: key,
            value: this.form[key]
          })
        })
        return list
      }
    },
    methods: {
      show (index) {  // 点击操作获取当前行的id
        this.$router.push({name: 'UserDetail', query: {id: this.data[index].id}})
      },
      onChangePage (page) {
        // 改变页码
        this.tableParams.current = page
        this.loadData()
      },
      loadData () {
        this.$nextTick(() => {
          this.$http.get('/user/info/page/' + this.tableParams.current, {params: {current: this.tableParams.current, condition: this.condition}}).then(res => {
            this.data = res.userPage.records
            this.tableParams.current = res.userPage.current
            this.tableParams.total = res.userPage.total
          })
        })
      }
    },
    mounted () {
      this.$nextTick(() => {
        this.loadData()
      })
    }
  }
</script>
