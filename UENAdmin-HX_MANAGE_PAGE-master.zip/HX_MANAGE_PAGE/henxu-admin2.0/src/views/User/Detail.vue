<template>
  <div>
    <!--电站基本信息-->
    <section class="panel">
      <div class="content-t">用户基本信息
        <!--<div class="edit1">
          <Button class="editbtn" @click="showPermissionSelect = true">分配权限</Button>
        </div>-->
      </div>
      <Row class="info-row bgf8fffd">
        <i-col :span="12">
          <div class="label">姓名</div>
          <template>
            <span class="showdetail">{{userInfo.realName}}</span>
          </template>
        </i-col>
        <i-col :span="12">
          <div class="label">联系电话</div>
          <template>
            <span class="showdetail">{{userInfo.telephone}}</span>
          </template>
        </i-col>
      </Row>
      <Row class="info-row">
        <i-col :span="12">
          <div class="label">地址</div>
          <template>
            <span class="showdetail">{{userInfo.address}}</span>
          </template>
        </i-col>
        <i-col :span="12">
          <div class="label">积分</div>
          <template>
            <span class="showdetail">{{userInfo.userPoint}}分</span>
          </template>
        </i-col>
      </Row>
      <Row class="info-row bgf8fffd">
        <i-col :span="12">
          <div class="label">关联电站码</div>
          <template>
            <span class="showdetail">{{userStationCode}}</span>
          </template>
        </i-col>
      </Row>
    </section>
    <!--关联电站-->
    <section class="panel" v-for="item in userStationList">
      <div class="content-t">关联电站
        <div class="edit1">
          <Button class="editbtn ivu-btn-primary" @click="changerouer(item.id, item.stationCode)" v-if="showBtn('sys:user:stationDetail')">查看电站</Button>
        </div>
      </div>
      <Row class="info-row bgf8fffd">
        <i-col :span="12">
          <div class="label">电站ID</div>
          <template>
            <span class="showdetail">{{item.id}}</span>
            <!--<span class="edit-btn" @click="showInverterSelect = true">修改</span>-->
          </template>
        </i-col>
        <i-col :span="12">
          <div class="label">建站地址</div>
          <template>
            <span class="showdetail">{{item.stationAddress}}</span>
            <!--<span class="edit-btn" @click="showBatterySelect = true">修改</span>-->
          </template>
        </i-col>
      </Row>
      <Row class="info-row">
        <i-col :span="12">
          <div class="label">装机容量</div>
          <template>
            <span class="showdetail">{{item.stationCapacity}}kw</span>
          </template>
        </i-col>
        <i-col :span="12">
          <div class="label">电站状态</div>
          <template>
            <span class="showdetail">{{item.stationStatus}}</span>
          </template>
        </i-col>
      </Row>
      <Row class="info-row bgf8fffd">
        <i-col :span="12">
          <div class="label">电站名称</div>
          <template>
            <span class="showdetail">{{item.stationName}}</span>
            <!--<span class="edit-btn" @click="showInverterSelect = true">修改</span>-->
          </template>
        </i-col>
        <i-col :span="12">
          <div class="label">电站类型</div>
          <template>
            <span class="showdetail">{{item.stationType}}</span>
            <!--<span class="edit-btn" @click="showBatterySelect = true">修改</span>-->
          </template>
        </i-col>
      </Row>
    </section>
    <!--交易记录-->
    <section class="table-wrapper">
      <div class="panel">
        <div class="content-t">交易记录
          <div class="editt">
            <Row>
              <i-col :span="12" style="text-align: center">
                <Date-picker type="daterange" placement="bottom-start" :value="[queryStartDtm, queryEndDtm]"
                             @on-change="changeDateRange" placeholder="选择日期"
                             style="width: 200px"></Date-picker>
                <Button type="primary" @click.native="loadRecordData">时间段查询</Button>
              </i-col>
              <i-col :span="12">
                <Date-picker type="year" placeholder="选择年" @on-change="changeYear" style="width: 200px"></Date-picker>
                <Button type="primary" @click.native="loadRecordData">年份查询</Button>
              </i-col>
            </Row>
          </div>
        </div>
      </div>
      <Table ref="selection" :columns="columns" :data="recordData"></Table>
      <!--page-->
        <Page style="margin: 100px auto 0; width: 800px;text-align: center; padding-bottom: 100px" :current="tableParams.current" :page-size="tableParams.pageSize"
              :total="tableParams.total" placement="top" show-total
              show-elevator @on-change="onChangePage"></Page>
    </section>
    <!--权限分配-->
    <Modal v-model="showPermissionSelect" title="分配权限" @on-ok="updateRole">
      <template>
        <RadioGroup v-model="selectRole" vertical>
          <Radio label="1">
            <Icon></Icon>
            <span>超级管理员</span>
          </Radio>
          <Radio label="2">
            <Icon></Icon>
            <span>后台管理员</span>
          </Radio>
          <Radio label="3">
            <Icon></Icon>
            <span>资讯管理员</span>
          </Radio>
        </RadioGroup>
      </template>
    </Modal>
  </div>
</template>
<style lang="less" rel="stylesheet/less">
  @import "../../less/table";

  .cards {
    height: 448px;
    box-sizing: border-box;
    margin-bottom: 10px;
    &.second {
      height: 380px;
    }
    .item {
      background: white;
      height: 100%;
      &.large {
        padding: 0 16px;
        box-sizing: inherit;
        background: transparent;
        .inner-container {
          width: 100%;
          height: 100%;
          background: white;
        }
      }
      &.business-database {
        .middle-wrapper {
          padding: 10px;
          height: 320px;
          .inner-container {
            background: #f6f6f6;
            position: relative;
            .info-box {
              width: 100%;
              align-self: center;
              flex: 1;
              padding-top: 20px;
              padding-left: 20px;
              text-align: left;
              .number {
                color: #ffd082;
                font-size: 22px;
              }
              .desc {
                color: #8b8b8b;
                font-size: 16px;
              }
            }
            .bg {
              position: absolute;
              right: 20px;
              bottom: 20px;
            }
          }
        }
        .card-group {
          height: 320px;
          padding: 10px;
          .inner-card {
            height: 140px;
            background: #f6f6f6;
            display: flex;
            padding: 10px;
            &:last-child {
              margin-top: 20px;
            }
            .img-wrapper {
              flex: 0 0 60px;
              align-self: center;
              margin-left: 20px;
              img {
                width: 100%;
                height: auto !important;
              }
            }
            .text {
              align-self: center;
              flex: 1;
              padding-right: 20px;
              text-align: right;
              .number {
                color: #ffd082;
                font-size: 22px;
              }
              .desc {
                color: #8b8b8b;
                font-size: 16px;
              }
            }
          }
        }
      }
      &:last-child {
        background: transparent;
        padding-right: 0;
      }
    }
  }
  .content-t {
    font-size: 16px;
    color: #333333;
    border-bottom: 2px solid #18b566;
    padding: 20px;
    position: relative;
  }
  .content-t1 {
    font-size: 16px;
    color: #333333;
    padding: 20px;
    border-bottom: 2px solid #f0f0f0;
    position: relative;
  }
  .bgf8fffd {
    background-color: #f8fffd;
  }
  .edit-btn {
    color: #90a2ca;
    padding: 0 10px;
    cursor: pointer;
  }
  .editt {
    position: absolute;
    bottom: 14px;
    right: 40px;
    width: 650px;
  }
  .edit1 {
    position: absolute;
    bottom: 14px;
    right: 50px;
  }
  .tabs {
    background: white;
    margin-bottom: 15px;
    .tab-item {
      padding: 10px 0;
      text-align: center;
      position: relative;
      color: #b2b2b2;
      font-size: 14px;
      cursor: pointer;
      &:after {
        content: ' ';
        width: 1px;
        height: 20px;
        display: block;
        position: absolute;
        right: 0;
        top: 10px;
        background: #d2d2d2;
      }
      &:last-child {
        &:after {
          width: 0;
        }
      }
      &.active {
        background: #3dcb9d;
        color: white;
        &:after {
          width: 0;
        }
      }
    }
  }
  .editbtn {
    background-color: #3dcb9d;
    border-radius: 4px;
    color: #ffffff;
    font-size: 14px;
    padding: 8px 30px;
  }
  .table-wrapper {
    background: white;
    margin-bottom: 20px;
  }
  .info-row {
    border-bottom: 1px solid #f2f2f2;
    padding: 10px 15px;
    font-size: 16px;
    color: #b6b6b6;
    .label {
      width: 200px;
      display: inline-block;
      color: #999999;
    }
    .showdetail {
      color: #666666;
    }
  }
  .panel {
    background: white;
    margin-bottom: 30px;
  }
  .info-list {
    width: 100%;
    padding: 15px;
    .info-group {
      font-size: 18px;
      li {
        color: #b6b6b6;
        padding: 15px 0;
        border-bottom: 1px solid #dedede;
        width: 100%;
        &:last-child {
          border: none;
        }
        .label {
          width: 40%;
          display: inline-block;
        }
        .value {
          width: 60%;
          display: inline;
        }
      }
      &.without-border {
        li {
          padding: 3px 0;
          border: none;
        }
      }
    }
  }
  .ivu-modal-header {
    background-color: #3dcb9d;
  }
  .ivu-modal-header-inner {
    color: #ffffff !important;
  }
</style>
<script type="text/ecmascript-6">

  export default {
    data () {
      return {
        busying: false,
        showPermissionSelect: false,
        selectRole: '1',
        tableParams: {
          current: 1,
          pageSize: 10,
          total: 0
        },
        columns: [
          {
            title: '订单编号',
            key: 'orderCode'
          },
          {
            title: '交易状态',
            key: 'transactionStatus',
            filter: {
              '0': '交易成功',
              '1': '交易失败'
            },
            render: (h, params) => { // 根据值过滤
              const row = params.row.transactionStatus
              const column = params.column.filter
              return h('span', column[row])
            }
          },
          {
            title: '交易方式',
            key: 'transactionType'
          },
          {
            title: '交易金额',
            key: 'amount'
          },
          {
            title: '交易时间',
            key: 'transactionTime'
          }
        ],
        recordData: [],
        queryEndDtm: '',
        queryStartDtm: '',
        queryYear: '',
        activeRouteId: '5',
        userInfo: '',
        userStationList: [],
        userStationCode: '',
        userAccount: ''
      }
    },
    computed: {
    },
    watch: {
    },
    methods: {
      changerouer (idNum, stationCodeNum) {
        this.$router.push({name: 'StationDetail', query: {id: idNum, stationCode: stationCodeNum}})
      },
      changeYear (year) {
        this.queryYear = year
        this.changeDateRange([year + '-01-01', year + '-12-30'])
      },
      changeDateRange (time) {
        if (time && time.length === 2 && time[0] && time[1]) {
          this.queryStartDtm = time[0]
          this.queryEndDtm = time[1]
        } else {
          this.queryStartDtm = null
          this.queryEndDtm = null
        }
      },
      updateRole () {
        this.$http.post(this.$api.user.save, this.user).then(res => {
          if (res.code === 200) {
            this.$Message.info('保存成功')
            this.showPermissionSelect = false
          }
        })
      },
      onChangePage (page) {
        // 改变页码
        this.tableParams.current = page
        this.loadRecordData()
      },
      useInfoData () {
        this.$http.get('/user/' + this.$route.query.id, {params: {id: this.$route.query.id}}).then(res => {
          if (res.code === 0) {
            this.userInfo = res.user
            this.userStationList = res.userStationList
            this.userAccount = res.user.account
            let thisUserStationCode = []
            Object(this.userStationList).forEach(key => {
              thisUserStationCode.push(key.stationCode)
            })
            this.userStationCode = thisUserStationCode.join(',')
            this.loadRecordData()
          }
        })
      },
      loadRecordData () {
        if (this.userAccount) {
          this.$http.get('/transactionRecord/page/' + this.tableParams.current, {params: {current: this.tableParams.current, account: this.userAccount, startDate: this.queryStartDtm, endDate: this.queryEndDtm}}).then(res => {
            if (res.code === 0) {
              this.recordData = res.transactionRecordPage.records
              this.tableParams.current = res.transactionRecordPage.current
              this.tableParams.pageSize = res.transactionRecordPage.size
              this.tableParams.total = res.transactionRecordPage.total
            }
          })
        }
      }
    },
    mounted () {
      this.useInfoData()
    }
  }
</script>
