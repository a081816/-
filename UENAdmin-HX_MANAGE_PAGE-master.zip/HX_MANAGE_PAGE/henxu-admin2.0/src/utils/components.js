/**
 * Created by Deboy on 2017/7/5.
 */
import Vue from 'vue'
import PanelHeader from '../components/common/panel-header.vue'
import AppTable from '../components/common/app-table.vue'
import ImgUpload from '../components/common/img-upload.vue'
import ImgUpload2 from '../components/common/img-upload2.vue'
import ImgUpload3 from '../components/common/img-upload3.vue'
import ImgPreview from '../components/common/img-preview.vue'
import VideoPreview from '../components/common/video-preview.vue'
import VideoUpload from '../components/common/video-upload.vue'
import ReleTableModal from '../components/common/rele-table-modal.vue'
import Editor from '../components/common/editor.vue'
// import KindEditor from '../components/common/kind-editor.vue'
import AreaSelect from '../components/common/area-select.vue'

Vue.component('PanelHeader', PanelHeader)
Vue.component('AppTable', AppTable)
Vue.component('ImgUpload', ImgUpload)
Vue.component('ImgPreview', ImgPreview)
Vue.component('ReleTableModal', ReleTableModal)
Vue.component('VideoUpload', VideoUpload)
Vue.component('VideoPreview', VideoPreview)
Vue.component('Editor', Editor)
// Vue.component('KindEditor', KindEditor)
Vue.component('AreaSelect', AreaSelect)
Vue.component('ImgUpload2', ImgUpload2)
Vue.component('ImgUpload3', ImgUpload3)
