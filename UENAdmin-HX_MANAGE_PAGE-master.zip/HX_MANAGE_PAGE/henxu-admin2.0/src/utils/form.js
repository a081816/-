/**
 * Created by Deboy on 2017/4/1.
 */
function install (Vue) {
  const form = {
    /**
     * 获取无限层次的值 eg: a = {b: {c: {e: 123}}} getDeepValue(a, 'a.b.c.e') = 123 不要直接用这个 用 getRowValue
     * @param data
     * @param path
     * @returns {*}
     */
    getDeepValue: (data, path) => {
      if (!path) return
      let targets = path.split('.')
      let currentData = data
      for (let i = 0; i < targets.length; i++) {
        if (!currentData) break
        currentData = currentData[targets[i]] || null
      }
      return currentData
    },
    /**
     * 获取table/form中某个字段的值
     * @param rowData
     * @param fieldInfo
     * @returns {*}
     */
    getRowValue: (rowData, fieldInfo) => {
      let field = fieldInfo.displayField
      if (!field) {
        return
      }
      if (field.indexOf('.') < 0 && field.indexOf('&') < 0 && field.filter === null) {
        return rowData[field]
      } else if (fieldInfo.filter) {
        if (fieldInfo.vue && fieldInfo.vue.validType === 'array') {
          let valArray = []
          if (rowData[field]) {
            let data = rowData[field]
            if (typeof rowData[field] === 'number') {
              data = rowData[field].toString()
            }
            valArray = data.split(',') || []
          }
          let arr = []
          Object.keys(fieldInfo.filter).forEach((key) => {
            if (valArray.indexOf(key) >= 0) {
              arr.push(fieldInfo.filter[key])
            }
          })
          return arr.join(', ')
        } else {
          return fieldInfo.filter[rowData[field]]
        }
      } else {
        if (field.indexOf('&') >= 0) {
          let fields = field.split('&')
          let returnStr = ''
          fields.forEach((singleField) => {
            returnStr += form.getDeepValue(rowData, singleField)
          })
          return returnStr
        } else {
          if (rowData) {
            return form.getDeepValue(rowData, field)
          } else {
            return null
          }
        }
      }
    },
    /**
     * 拆分用指定符号(默认逗号)分割的字符串为数组
     * @param rowData
     * @param fieldInfo
     * @param separator
     * @returns {*}
     */
    strToArr: (rowData, fieldInfo, separator = ',') => {
      let value = form.getRowValue(rowData, fieldInfo)
      if (value) {
        return value.split(separator)
      } else {
        return []
      }
    },
    /**
     * 根据model生成表单校验规则
     * @param model
     * @returns {{}}
     */
    generateValidateRule (model) {
      let rule = {}
      model.forEach((field) => {
        if (field.required) {
          rule[field.field] = []
          rule[field.field].push({
            required: true,
            message: field.title + '不能为空',
            trigger: (field.xtype === 'select' ? 'change' : 'blur'),
            type: field.vue && field.vue.validType || 'string'
          })
          // 如果字段本身有校验规则 那就加上
          if (field.validateRule) {
            rule[field.field].push(field.validateRule)
          }
        }
      })
      return rule
    }
  }
  Vue.prototype.$form = form
}

export default install
