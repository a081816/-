let mixin = {
  computed: {
    isBusy () {
      return this.$store.getters.isLoading
    }
  }
}
export default mixin
