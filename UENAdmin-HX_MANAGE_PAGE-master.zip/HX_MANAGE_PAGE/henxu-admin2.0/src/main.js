// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './vuex'
import http from './http'
import apiDefined from './http/api-defined'
import form from './utils/form'
import BaseMixin from './utils/mixin'
import iView from 'iview'
import './less/theme.less'
// import 'iview/dist/styles/iview.css'
Vue.use(iView)
Vue.use(http)
Vue.use(apiDefined)
Vue.use(form)
Vue.mixin(BaseMixin)
require('./utils/components')
Vue.config.productionTip = false
Vue.prototype.showBtn = function (name) { // 按钮权限的全局函数
  let buttonSet = this.$store.state.user.user.buttonSet
  if (buttonSet.indexOf(name) >= 0) {
    return true
  } else {
    return false
  }
}
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: {App}
})
