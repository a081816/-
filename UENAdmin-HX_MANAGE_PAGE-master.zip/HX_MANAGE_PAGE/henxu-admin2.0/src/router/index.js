import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'index',
      component: require('../views/Home.vue')
    },
    {
      path: '/Station',
      name: 'station',
      component: require('../views/Station.vue')
    },
    {
      path: '/Station/Detail',
      name: 'StationDetail',
      component: require('../views/Station/Detail.vue')
    },
    {
      path: '/Order',
      name: 'order',
      component: require('../views/Order.vue')
    },
    {
      path: '/Order/Detail',
      name: 'OrderDetail',
      component: require('../views/Order/Detail.vue')
    },
    {
      path: '/User/User',
      name: 'user',
      component: require('../views/User/User.vue')
    },
    {
      path: '/User/Detail',
      name: 'UserDetail',
      component: require('../views/User/Detail.vue')
    },
    {
      path: '/Banner',
      name: 'banner',
      component: require('../views/Banner.vue')
    },
    {
      path: '/merchandise',
      name: 'product',
      component: require('../views/merchandise.vue')
    },
    {
      path: '/News/Detail',
      name: 'NewsDetail',
      component: require('../views/News/Detail.vue')
    },
    {
      path: '/News/Information',
      name: 'news',
      component: require('../views/News/Information.vue')
    }, {
      path: '/RoleManages',
      name: 'role',
      component: require('../views/RoleManages.vue')
    }, {
      path: '/MangesManges',
      name: 'manager',
      component: require('../views/MangesManges.vue')
    },
    {
      path: '/System/System',
      name: 'param',
      component: require('../views/System/System.vue')
    },
    {
      path: '/System/Detail',
      name: 'SystemDetail',
      component: require('../views/System/Detail.vue')
    }
  ]
})
