<template>
  <div id="app">
    <div id="main-wrapper" v-if="isLogin">
      <app-aside id="app-aside" :class="{'folded': isFolded}" :folded="isFolded" shadow :style="fullScreen"></app-aside>
      <div id="right-aside" :style="fullScreen">
        <app-header @on-folded="isFolded=!isFolded" :is-folded="isFolded" shadow id="app-header"></app-header>
        <div id="app-container">
          <router-view></router-view>
        </div>
        <footer id="app-footer"></footer>
      </div>
    </div>
    <div v-else> <!--v-else-->
      <login></login>
    </div>
    <img-preview v-model="imgPreview.show" :url="imgPreview.url"></img-preview>
    <video-preview v-model="videoPreview.show" :url="videoPreview.url"></video-preview>
    <img src="/static/ripple.gif" v-if="isBusy" class="loading-gif" alt="">
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import AppAside from './components/layout/app-aside.vue'
  import AppHeader from './components/layout/app-header.vue'
  import Login from './components/layout/login.vue'

  export default {
    name: 'app',
    components: {
      AppAside,
      AppHeader,
      Login
    },
    data () {
      return {
        isFolded: false,
        needLogin: false
      }
    },
    computed: {
      ...mapGetters([
        'breadcrumbs',
        'imgPreview',
        'videoPreview',
        'isLogin'
      ]),
      fullScreen: {
        cache: false,
        get () {
          return {
            height: window.document.body.clientHeight + 20 + 'px',
            width: '100%'
          }
        }
      }
    }
  }
</script>

<style lang="less">
  @import "./less/base";
  table{
    font-size: 14px;
  }
  .panel{
    margin-bottom: 30px !important;
  }
  .link {
    cursor: pointer;
    color: #90a2ca;
  }

  .loading-gif {
    position: fixed;
    top: 10px;
    left: 50%;
    transform: translateX(-50%);
    width: 50px;
    height: 50px;
    z-index: 9999999;
  }

  .edit-btn {
    cursor: pointer;
    color: #90a2ca;
  }

  #app {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #2c3e50;
    background: #f6f6f6;
    #main-wrapper {
      width: 100%;
      display: flex;
      #app-aside {
        flex: 0 0 250px;
        overflow: auto;
        background: white;
        &.folded {
          flex: 0 0 80px;
        }
        .ivu-menu {
          height: 100% !important;
        }
      }
      #right-aside {
        display: flex;
        flex-direction: column;
        width: 100%;
        #app-header {
          flex: 0 0 70px;
          line-height: 70px;
          background: white;
          align-self: center;
          width: 100%;
        }
        #app-container {
          flex: 1;
          overflow-y: auto;
          margin: 30px;
        }
      }
    }
  }
</style>
