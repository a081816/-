import Axios from 'axios'
import Qs from 'qs'
import iView from 'iview'
import store from '../vuex'

function install (Vue) {
  Axios.defaults.baseURL = (process.env.NODE_ENV !== 'production' ? '/api' : '') + '/manage'
  Axios.defaults.headers = {
    'Content-Type': 'application/x-www-form-urlencoded'
  }
  Axios.defaults.timeout = 60000
  // Axios.defaults.withCredentials = true
  Axios.interceptors.request.use((request) => {
    if (!request.data) {
      request.data = {}
    }
    // request.method = 'POST'
    if (request.url.toUpperCase().indexOf('UPLOAD') < 0) {
      iView.LoadingBar.start()
      store.dispatch('openLoading')
      // 如果post的data 为 null 就赋值为一个对象
      if (!request.data) {
        request.data = {}
      }
      // 再转换成数据库的格式 发送
      // 遍历参数 如果有 undefined 的就删除这个参数
      for (let params in request.data) {
        if (request.data[params] === undefined || request.data[params] === '' || request.data[params] === null) {
          delete request.data[params]
        }
      }
      // 登录校验
      if (store.getters.userInfo && store.getters.userInfo.token) {
        request.headers.token = store.getters.userInfo.token
      }
      // 删除get参数 上一步已经合并为POST数据了 不需要重复的数据传输
      // delete request.params
      if ((!request.data.removeFormat && request.url.indexOf('save') < 0) || request.url.indexOf('qualificationsServer/saveBatch') >= 0) {
        for (let params in request.data) {
          if (typeof request.data[params] === 'object') {
            delete request.data[params]
          }
        }
        request.data = Qs.stringify(request.data)
      } else {
        request.headers['Content-Type'] = 'application/json'
      }
    }
    return request
  }, (error) => {
    console.log(error)
  })
  // Add a response interceptor
  Axios.interceptors.response.use((response) => {
    iView.LoadingBar.finish()
    store.dispatch('closeLoading')
    switch (response.data.code) {
      case 0:
        return Promise.resolve(response.data)
      case 999:
        iView.Message.info('请先登录')
        store.commit('LOGOUT')
        window.location.reload()
        return Promise.reject(response.data)
      default:
        iView.Message.error(response.data.msg)
        return Promise.reject(response.data)
    }
  }, (error) => {
    console.log(error)
    // Do something with response error
    iView.LoadingBar.error()
    store.dispatch('closeLoading')
    console.log(error)
    if (JSON.stringify(error).indexOf('404') > 0) {
      iView.Notice.error({
        title: '系统错误',
        desc: '系统出现错误，请联系管理员',
        duration: 5
      })
    } else {
      iView.Notice.error({
        title: '网络错误',
        desc: '网络出错，如果多次出现，请联系管理员或者稍后再试',
        duration: 5
      })
    }
    return Promise.reject(error)
  })
  Vue.prototype.$http = Axios
  Vue.prototype.axios = Axios
}

export default install
