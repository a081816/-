function install (Vue) {
  const api = {
    fileUpload: (process.env.NODE_ENV !== 'production' ? '/api' : '') + '/server/upload/upload',
    fileUpload4KindEditor: (process.env.NODE_ENV !== 'production' ? '/api' : '') + '/server/upload/upload4KindEditor',
    fileUpload2: '/upload/upload',
    user: {
      list: 'user/findAll',
      select: 'user/select',
      save: 'user/save',
      delete: 'user/delete'
    },
    province: {
      list: 'province/findAll'
    },
    station: {
      list: 'station/findAll',
      select: 'station/select',
      delete: 'station/delete',
      save: 'station/save'
    },
    ammeter: {
      list: 'ammeter/findAll',
      select: 'ammeter/select',
      delete: 'ammeter/delete',
      save: 'ammeter/save',
      relieveStation: 'ammeter/relieveStation'
    },
    order: {
      list: 'order/findAll',
      select: 'order/select',
      save: 'order/save',
      delete: 'order/delete'
    },
    recharge: {
      list: 'billRecharge/findAll',
      select: 'billRecharge/select',
      save: 'billRecharge/save',
      delete: 'billRecharge/delete'
    },
    withdraw: {
      list: 'billWithdrawals/findAll',
      select: 'billWithdrawals/select',
      save: 'billWithdrawals/save',
      delete: 'billWithdrawals/delete'
    },
    refund: {
      list: 'billRefund/findAll',
      select: 'billRefund/select',
      save: 'billRefund/save',
      delete: 'billRefund/delete'
    },
    billOrder: {
      list: 'billOrder/findAll',
      select: 'billOrder/select',
      save: 'billOrder/save',
      delete: 'billOrder/delete'
    },
    feedback: {
      list: 'feedback/findAll',
      select: 'feedback/select',
      save: 'feedback/save',
      delete: 'feedback/delete'
    },
    push: {
      list: 'push/findAll',
      select: 'push/select',
      save: 'push/save',
      delete: 'push/delete'
    },
    banner: {
      list: 'banner/findAll',
      select: 'banner/select',
      save: 'banner/save',
      delete: 'banner/delete'
    },
    systemConfig: {
      list: 'systemConfig/findAll',
      select: 'systemConfig/select',
      save: 'systemConfig/save',
      delete: 'systemConfig/delete'
    },
    server: {
      list: 'server/findAll',
      select: 'server/select',
      save: 'server/save',
      delete: 'server/delete'
    },
    qualification: {
      list: 'qualifications/findAll',
      select: 'qualifications/select',
      save: 'qualifications/save',
      delete: 'qualifications/delete'
    },
    subsidy: {
      list: 'subsidy/findAll',
      select: 'subsidy/select',
      save: 'subsidy/save',
      delete: 'subsidy/delete'
    },
    device: {
      list: 'devide/findBrand',
      select: 'devide/select',
      save: 'devide/save',
      delete: 'devide/delete',
      findAll: 'devide/findAll'
    },
    news: {
      list: 'news/findAll',
      select: 'news/select',
      save: 'news/save',
      delete: 'news/delete',
      ConstrSave: 'news/ConstrSave'
    },
    apolegamy: {
      list: 'apolegamy/findAll',
      select: 'apolegamy/select',
      save: 'apolegamy/save',
      delete: 'apolegamy/delete'
    },
    brand: {
      save: 'brand/save',
      delete: 'brand/delete'
    },
    InvSolar: {
      solarsave: 'InvSolar/solarsave',
      solardelete: 'InvSolar/solardelete'
    },
    construction: {
      save: 'construction/newsave',
      delete: 'construction/delete',
      findAll: 'construction/findAll',
      findOne: 'construction/findOne'
    },
    productionDetail: {
      findOne: 'productionDetail/findOne',
      save: 'productionDetail/save'
    }
  }
  Vue.prototype.$api = api
}
export default install
