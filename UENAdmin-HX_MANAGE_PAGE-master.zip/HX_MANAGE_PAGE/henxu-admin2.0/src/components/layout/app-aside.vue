<template>
  <div style="height: 100%;">
    <Menu ref="menu" width="auto" @on-select="changeMenu" :active-name="activeRouteId">
      <router-link to="/">
        <div class="layout-logo-left">
          恒旭<template> | 管理系统</template>
        </div>
      </router-link>
      <template v-for="(menu,index) in tmpMenus">
        <template v-if="showMuen(menu.routeName)">
          <Menu-item :name="menu.id">
            <template v-if="menu.showitem">
              <img class="icon" :src="`/static/icon/${menu.icon}.png`" alt="" style="vertical-align: middle;">
              <template>{{menu.menuName}}</template>
            </template>
            <template v-else>
              <img class="icon" :src="`/static/icon/${menu.iconActive}.png`" alt="" style="vertical-align: middle;">
              <template>{{menu.menuName}}</template>
            </template>
          </Menu-item>
        </template>
      </template>
    </Menu>
  </div>
</template>
<style scoped lang="less">
  .layout-logo-left {
    height: 70px;
    line-height: 60px;
    font-size: 20px;
    font-weight: 600;
    text-align: center;
    color: #18b566;
  }

  .icon {
    vertical-align: -8%;
    padding: 0 8px;
  }
  .ivu-menu-item-selected{
    color: #ffffff !important;
    background-color:#3dcba4;
    border: none !important;
  }
  .ivu-menu-item-selected:hover {
    background-color: #3dcba4 !important;

  }
</style>
<script>
  export default {
    props: {
      folded: {
        type: Boolean,
        default () {
          return false
        }
      }
    },
    data () {
      return {
        relMenus: [],
        role: {},
        tmpMenus: [
          {
            id: '0',
            menuName: '系统首页',
            routeName: 'index',
            icon: 'home1',
            iconActive: 'home1-active',
            showitem: false
          },
          {
            id: '1',
            menuName: '电站管理',
            routeName: 'station',
            icon: 'home2',
            iconActive: 'home2-active',
            showitem: true,
            detail: 'StationDetail'
          },
          {
            id: '2',
            menuName: '订单管理',
            routeName: 'order',
            icon: 'home3',
            iconActive: 'home3-active',
            showitem: true,
            detail: 'OrderDetail'
          },
          {
            id: '3',
            menuName: '商品管理',
            routeName: 'product',
            icon: 'home4',
            iconActive: 'home4-active',
            showitem: true
          },
          {
            id: '4',
            menuName: '轮播图设置',
            routeName: 'banner',
            icon: 'home5',
            iconActive: 'home5-active',
            showitem: true
          },
          {
            id: '5',
            menuName: '用户管理',
            routeName: 'user',
            icon: 'home6',
            iconActive: 'home6-active',
            showitem: true,
            detail: 'UserDetail'
          },
          {
            id: '6',
            menuName: '资讯管理',
            routeName: 'news',
            icon: 'home7',
            iconActive: 'home7-active',
            showitem: true,
            detail: 'NewsDetail'
          },
          {
            id: '7',
            menuName: '系统参数',
            routeName: 'param',
            icon: 'home8',
            iconActive: 'home8-active',
            showitem: true
          },
          {
            id: '8',
            menuName: '角色管理',
            routeName: 'role',
            icon: 'home9',
            iconActive: 'home9-active',
            showitem: true
          },
          {
            id: '9',
            menuName: '管理员管理',
            routeName: 'manager',
            icon: 'home10',
            iconActive: 'home10-active',
            showitem: true
          }
        ],
        activeRouteId: '',
        activeRouteIdNum: '',
        showitem: ''
      }
    },
    computed: {
      allRoute () {
        let recursionFunc = (routes) => {
          let list = []
          routes.forEach(route => {
            let cloneRoute = JSON.parse(JSON.stringify(route))
            delete cloneRoute.children
            list.push(cloneRoute)
            if (route.children && route.children.length > 0) {
              list = [...recursionFunc(route.children), ...list]
            }
          })
          return list
        }
        return recursionFunc(this.tmpMenus)
      }
    },
    watch: {
      folded (val) {
        if (val) {
          this.activeRouteId = ''
        } else {
          this.updateActiveMenu()
        }
      },
      '$route' (val) {
        this.$nextTick(() => {
          this.updateActiveMenu()
        })
      },
      activeRouteId () {
        this.$nextTick(() => {
          this.$refs.menu.updateActiveName()
        })
      }
    },
    methods: {
      showMuen (name) {
        let userMuen = this.$store.state.user.user.menuSet
        if (userMuen.indexOf(name) >= 0) {
          return true
        } else {
          return false
        }
      },
      findRoute (id) {
        let routes = this.allRoute.filter(route => {
          return route.id === id
        })
        return routes && routes[0]
      },
      changeMenu (id) {
        let route = this.findRoute(id)
        this.$router.push({name: route.routeName})
        let tmpMenusList = this.tmpMenus
        for (let i in tmpMenusList) {
          tmpMenusList[i].showitem = true
        }
        this.tmpMenus[id].showitem = false
      },
      updateActiveMenu () {
        let activeRouteName = this.$route.name
        let activeRouteId = ''
        let findActiveRoute = false
        this.tmpMenus.forEach((menu) => {
          menu.showitem = true
          if (findActiveRoute) {
            return
          }
          if (menu.routeName === activeRouteName) {
            activeRouteId = menu.id
            findActiveRoute = true
            menu.showitem = false
          }
          if (menu.detail) {
            if (menu.detail === activeRouteName) {
              activeRouteId = menu.id
              findActiveRoute = true
              menu.showitem = false
            }
          }
        })
        this.activeRouteId = activeRouteId
      }
    },
    mounted () {
      this.updateActiveMenu()
      this.$nextTick(() => { // 刷新页面根据路由id修改相应图标
        this.activeRouteIdNum = this.activeRouteId
        if (this.activeRouteIdNum && this.activeRouteIdNum !== 0) {
          let tmpMenusList = this.tmpMenus
          tmpMenusList[0].showitem = true
          tmpMenusList[this.activeRouteIdNum].showitem = false
        }
      })
    }
  }
</script>
