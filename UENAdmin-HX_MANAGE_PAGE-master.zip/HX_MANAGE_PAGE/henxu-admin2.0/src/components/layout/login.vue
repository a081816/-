<template>
  <div>
    <div id="login">
      <div class="login_bg" :style ="note"></div>
      <div class="login-warpper">
        <div class="header">
          <strong class="title">恒旭后台管理系统</strong>
          <p>Management System</p>
        </div>
        <Form ref="form" @keyup.enter.native="handleSubmit('form')" :model="form" :rules="ruleCustom">
          <Form-item prop="account">
            <Input type="text" placeholder="请输入账户" v-model="form.account"></Input>
          </Form-item>
          <Form-item prop="password">
            <Input type="password" placeholder="请输入密码" v-model="form.password"></Input>
          </Form-item>
          <Form-item prop="verificationCode">
            <Row>
              <Col span="16">
              <Input type="text" placeholder="验证码" v-model="form.verificationCode"></Input>
              </Col>
              <Col span="8">
              <img class="code" :src="codeUrl" @click="refreshCode" alt="">
              </Col>
            </Row>
          </Form-item>
        </Form>
        <Button type="primary" :loading="$store.getters.isLoading" long @click="handleSubmit('form')">提交</Button>
        <p class="icp">粤ICP备14053933号-4</p>
      </div>
    </div>
  </div>
</template>
<style lang='less' rel="stylesheet/less">
  #login {
    width: 100%;
    height: 100%;
    position: fixed;
    .login-warpper {
      height: 340px;
      width: 300px;
      background: rgba(70, 76, 91, 0.5);
      /*background: rgba(255, 255, 255, 0.5);*/
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      border-radius: 10px;
      box-shadow: 0 -15px 30px #f5f5f5;
      padding: 15px 25px 10px 25px;
      color: white;
      .code {
        height: 32px;
        width: 100%;
      }
      .header {
        text-align: center;
        margin-bottom: 15px;
        .title {
          font-size: 20px;
        }
      }
      .icp {
        text-align: center;
        padding: 10px 0;
      }
    }
    .login_bg {
      width: 100%;
      height:100%;
      position: absolute;
      top:0;
      left:0;
    }
  }
  @-webkit-keyframes pulse{
    0%{-webkit-transform:scale(1)}
    50%{-webkit-transform:scale(1.2)}
    100%{-webkit-transform:scale(1)}
  }
</style>
<script type="text/ecmascript-6">

  export default {
    data () {
      return {
        note: {
          backgroundImage: 'url(' + require('../../../static/6.jpg') + ')',
          backgroundRepeat: 'no-repeat',
          animation: 'pulse 20s .2s ease both infinite',
          backgroundSize: 'cover'
        },
        form: {
          account: '',
          password: '',
          verificationCode: ''
        },
        ruleCustom: {
          account: [
            {required: true, message: '账号不能为空', trigger: 'blur'}
          ],
          password: [
            {required: true, message: '密码不能为空', trigger: 'blur'}
          ],
          verificationCode: [
            {required: true, message: '验证码不能为空', trigger: 'blur'}
          ]
        },
        codeUrl: ''
      }
    },
    methods: {
      refreshCode () {
        let baseUrl = (process.env.NODE_ENV !== 'production' ? '/api' : '') + 'manage/verificationcode'
        baseUrl += ('?rand=' + Math.random(1))
        this.codeUrl = baseUrl
      },
      handleSubmit (name) {
        if (this.$store.getters.isLoading) {
          return
        }
        this.$refs[name].validate((valid) => {
          if (valid) {
            this.$http.post('/session/web', this.form).then(res => {
              this.$store.commit('SET_USER_INFO', Object.assign({}, res.sysUserDto, res.sysUserDto))
              // window.sessionStorage.setItem('user', JSON.stringify(res.sysUserDto))
              this.$Message.success('登录成功!')
            }).catch(e => {
              // 打印一下错误
              console.log(e)
            })
          } else {
            this.$Message.error('表单验证失败!')
          }
        })
      },
      handleReset (name) {
        this.$refs[name].resetFields()
      }
    },
    mounted () {
      this.refreshCode()
    }
  }
</script>
