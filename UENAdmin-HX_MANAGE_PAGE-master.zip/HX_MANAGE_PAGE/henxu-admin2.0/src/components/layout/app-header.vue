<template>
  <div class="header-wrapper">
    <div class="left-action">
      <a @click="$router.back()">返回上一页</a>
      <!--<img class="icon" @click="$router.back()" src="~@/assets/common/icon31.png" alt="">-->
    </div>
    <div class="right-action">
      <p>
        <img class="headimg" v-if="user && user.headimg" src="/static/logo.png" alt="">
        <img class="headimg" v-else :src="require('@/assets/common/headimg.png')" alt="">
      </p>
      <p class="username with-right-border">{{helloLabel}} , {{user && user.sysUser.realName}}</p>
      <p class="personal-info-btn with-right-border link">
        <img class="icon" :src="require('@/assets/common/personal-card.png')" alt="">
        <router-link :to="{name: 'UserDetail', query: {id: user && user.sysUser.id}}">个人资料</router-link>
      </p>
      <p class="logout-btn" @click="logout">退出</p>
    </div>
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
  .header-wrapper {
    display: flex;
    width: 100%;
    padding: 0 50px;
    .left-action {
      flex: 0 0 200px;
      .icon {
        line-height: 70px;
        vertical-align: middle;
        position: relative;
        &:first-child {
          padding-right: 10px;
          &:after {
            height: 22px;
            width: 2px;
            position: absolute;
            right: 0;
            top: (70-22)/2px;
            display: block;
            background: #e3e3e3;
            content: '';
          }
        }
        &:last-child {
          padding-left: 10px;
        }
      }
    }
    .right-action {
      flex: 1;
      text-align: right;
      line-height: 70px;

      .headimg {
        height: 60px;
        padding: 10px 0;
        border-radius: 50%;
        display: inline-flex;
        vertical-align: middle;
      }
      p {
        display: inline-block;
        line-height: 70px;
        padding: 0 5px;
        font-size: 16px;
        position: relative;
        color: #616161;
        &.with-right-border {
          &:after {
            height: 22px;
            width: 2px;
            position: absolute;
            right: -3px;
            top: (70-22)/2px;
            display: block;
            background: #e3e3e3;
            content: '';
          }
        }
        &.personal-info-btn {
          img {
            vertical-align: -5%;
          }
        }
        &.link {
          cursor: pointer;
        }
        a {
          color: #616161;
        }
        &.logout-btn {
          cursor: pointer;
        }
      }
    }
  }
</style>
<script type="text/ecmascript-6">
  export default {
    props: {
      isFolded: Boolean
    },
    data () {
      return {}
    },
    computed: {
      user () {
        return this.$store.getters.userInfo
      },
      helloLabel () {
        let now = new Date()
        let hour = now.getHours()
        if (hour < 6) {
          return '凌晨好'
        } else if (hour < 9) {
          return '早上好'
        } else if (hour < 12) {
          return '上午好'
        } else if (hour < 14) {
          return '中午好'
        } else if (hour < 17) {
          return '下午好'
        } else if (hour < 19) {
          return '傍晚好'
        } else if (hour < 22) {
          return '晚上好'
        } else {
          return '夜里好'
        }
      }
    },
    methods: {
      logout () {
        // this.$store.commit('LOGOUT')
        this.$http.delete('/session/web').then(res => {
          if (res.code === 0) {
            window.sessionStorage.removeItem('user')
            // window.location.reload()
            window.location.href = 'http://hx.u-en.cn'
          }
        }).catch(e => {
          // 打印一下错误
          console.log(e)
          window.sessionStorage.removeItem('user')
          window.location.reload()
        })
      }
    }
  }
</script>
