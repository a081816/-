<template>
  <div>
    <Modal title="选择服务商资质" :value="isModalShow" @on-cancel="() => {isModalShow = false}" @on-ok="save">
      <Transfer
        :data="source"
        :target-keys="target"
        :render-format="getRenderText"
        :titles="['优能资质', '服务商资质']"
        @on-change="onChange"></Transfer>
    </Modal>
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
</style>
<script type="text/ecmascript-6">
  export default {
    props: {
      initQualifications: {
        type: Array
      },
      show: {
        type: Boolean,
        twoWay: true
      }
    },
    data () {
      return {
        list: [],
        target: [],
        isModalShow: this.show
      }
    },
    computed: {
      source () {
        return this.list.map(item => {
          return {key: item.id, label: item.text}
        })
      }
    },
    watch: {
      isModalShow (val) {
        if (!val) {
          this.$emit('update:show', val)
        }
      },
      show (val) {
        this.isModalShow = val
      }
    },
    methods: {
      initTargetKey () {
        if (this.initQualifications) {
          this.target = this.initQualifications.map(item => item.qualificationsId)
        }
      },
      getRenderText (item) {
        return item.label
      },
      onChange (newTargetKeys, direction, moveKeys) {
        this.target = newTargetKeys
      },
      save () {
        let list = []
        this.list.forEach((item) => {
          if (this.target.indexOf(item.id) >= 0) {
            list.push(item)
          }
        })
        this.$emit('on-confirm', list)
      }
    },
    mounted () {
      this.$http.post(this.$api.qualification.list).then(res => {
        this.list = res.data.content
      })
      this.$nextTick(() => {
        this.initTargetKey()
      })
    }
  }
</script>
