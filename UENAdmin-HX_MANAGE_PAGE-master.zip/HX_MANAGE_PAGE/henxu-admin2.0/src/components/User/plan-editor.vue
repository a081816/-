<template>
  <div>
    <section class="panel" v-if="plans">
      <Row style="display: flex" class="plan-list">
        <i-col style="align-self: center" :span="16">
          <Row>
            <template v-for="(plan, index) in plans">
              <i-col class="plan-item" @click.native="selectSomePlan(plan)"
                     :class="{'active': selectPlan && selectPlan.id === plan.id}" span="4">
                {{`方案${['一', '二', '三', '四', '五'][index]}`}}
              </i-col>
            </template>
          </Row>
        </i-col>
        <i-col style="align-self: center;text-align: right" :span="8">
          <Button type="primary" @click.native="showPlanEdit = true" v-if="selectPlan && selectPlan.id"
                  style="width: 100px">
            修改方案
          </Button>
          <Button type="error" @click.native="deletePlan" v-if="selectPlan && selectPlan.id" style="width: 100px">删除方案
          </Button>
          <Button type="primary" @click.native="addPlan" v-if="plans.length < 4" style="width: 100px">添加方案</Button>
        </i-col>
      </Row>
    </section>
    <section class="panel" v-if="selectPlan && selectPlan.id">
      <Row style="font-size: 15px;padding: 15px 0">
        <router-link :to="{name: 'palnDetail', query: {serverId: this.serverId}}"><Button type="primary">编辑商品详情</Button></router-link>
      </Row>
      <panel-header :icon="require('@/assets/icons/cailiao.png')">设备材料</panel-header>
      <div class="table-wrapper">
        <table class="order-detail">
          <thead>
          <tr>
            <th>设备名称</th>
            <th>设备品牌</th>
            <th>设备型号</th>
            <th>质保年份</th>
            <th>保修年份</th>
            <th>转化效率</th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="plan in currentPlans">
            <td>{{plan.deviceName}}</td>
            <td>{{plan.deviceBrand}}</td>
            <td>{{plan.deviceSpec}}</td>
            <td>{{plan.deviceShelfLife}}</td>
            <td>{{plan.WarrantyYear}}</td>
            <td>{{plan.conversionEfficiency}}</td>
          </tr>
          </tbody>
        </table>
        <Row style="font-size: 15px;padding: 15px 0">
          方案单价: <span style="color: #9b9b9b">{{selectPlan.unitPrice}} 元/kw</span> 最低购买千瓦数: <span style="color: #a1a1a1">{{selectPlan.minPurchase}}</span>
        </Row>
        <Row style="font-size: 15px;padding: 15px 0">
          方案名称: <span style="color: #9b9b9b">{{selectPlan.planName}}</span>
        </Row>
        <Row style="padding-top: 30px; font-size: 16px; color: #2baee9">方案图片：</Row>
        <Row style="padding-top: 20px; text-align: center"><img :src="selectPlan.planImgUrl" width="80%"></Row>
      </div>
    </section>
    <Modal title="编辑方案" v-model="showPlanEdit" @on-cancel="backPlan" @on-ok="save">
      <Row v-if="selectPlan">
        <i-col style="margin-bottom: 15px" :span="24">
          <Row>
            <i-col style="line-height: 30px" :span="6">方案名称<span style="color: red">*</span>: </i-col>
            <i-col :span="18">
              <i-input v-model="selectPlan.planName"></i-input>
            </i-col>
          </Row>
        </i-col>
        <i-col style="margin-bottom: 15px" :span="24">
          <Row>
            <i-col style="line-height: 30px" :span="6">电池板: </i-col>
            <i-col :span="14">
              <i-input
                :value="selectPlan.solarPanel.brandName + '/' + selectPlan.solarPanel.model"
                disabled></i-input>
            </i-col>
            <i-col :span="4">
              <Button style="width: 100%" @click.native="showBatterySelect = true">选择</Button>
            </i-col>
          </Row>
        </i-col>
        <i-col style="margin-bottom: 15px" :span="24">
          <Row>
            <i-col style="line-height: 30px" :span="6">电池板保质期(年): </i-col>
            <i-col :span="18">
              <i-input v-model="selectPlan.solarPanel.boardYear"></i-input>
            </i-col>
          </Row>
        </i-col>
        <i-col style="margin-bottom: 15px" :span="24">
          <Row>
            <i-col style="line-height: 30px" :span="6">电池板保修期(年): </i-col>
            <i-col :span="18">
              <i-input v-model="selectPlan.solarPanel.qualityAssurance"></i-input>
            </i-col>
          </Row>
        </i-col>
        <i-col style="margin-bottom: 15px" :span="24">
          <Row>
            <i-col style="line-height: 30px" :span="6">电池板转化率: </i-col>
            <i-col :span="18">
              <i-input v-model="selectPlan.solarPanel.conversionEfficiency"></i-input>
            </i-col>
          </Row>
        </i-col>
        <i-col style="margin-bottom: 15px" :span="24">
          <Row>
            <i-col style="line-height: 30px" :span="6">逆变器: </i-col>
            <i-col :span="14">
              <i-input
                :value="selectPlan.inverter.brandName + '/'  +  selectPlan.inverter.model"
                disabled></i-input>
            </i-col>
            <i-col :span="4">
              <Button style="width: 100%" @click.native="showInverterSelect = true">选择</Button>
            </i-col>
          </Row>
        </i-col>
        <i-col style="margin-bottom: 15px" :span="24">
          <Row>
            <i-col style="line-height: 30px" :span="6">逆变器保质期(年): </i-col>
            <i-col :span="18">
              <i-input v-model="selectPlan.inverter.boardYear"></i-input>
            </i-col>
          </Row>
        </i-col>
        <i-col style="margin-bottom: 15px" :span="24">
          <Row>
            <i-col style="line-height: 30px" :span="6">逆变器保修期(年): </i-col>
            <i-col :span="18">
              <i-input v-model="selectPlan.inverter.qualityAssurance"></i-input>
            </i-col>
          </Row>
        </i-col>
        <i-col style="margin-bottom: 15px" :span="24">
          <Row>
            <i-col style="line-height: 30px" :span="6">其他材料: </i-col>
            <i-col :span="14">
              <OtherMaterial v-model="selectPlan.materialJson"></OtherMaterial>
            </i-col>
          </Row>
        </i-col>
        <i-col style="margin-bottom: 15px" :span="24">
          <Row>
            <i-col style="line-height: 30px" :span="6">最低购买千瓦数: </i-col>
            <i-col :span="18">
              <i-input v-model="selectPlan.minPurchase"></i-input>
            </i-col>
          </Row>
        </i-col>
        <i-col style="margin-bottom: 15px" :span="24">
          <Row>
            <i-col style="line-height: 30px" :span="6">元/千瓦: </i-col>
            <i-col :span="18">
              <i-input v-model="selectPlan.unitPrice"></i-input>
            </i-col>
          </Row>
        </i-col>
      </Row>
      <!--<i-col style="margin-bottom: 15px" :span="24">
        <Row>
          <i-col :span="6">方案适合类型：</i-col>
          <i-col :span="18">
            <radio-group v-model="radioType">
              <radio :label="1">居民</radio>
              <radio :label="2">工业</radio>
              <radio :label="3">商业</radio>
              <radio :label="4">农业</radio>
            </radio-group>
          </i-col>
        </Row>
      </i-col>-->
      <Row v-if="selectPlan">
        <img-upload2 v-model="selectPlan.planImgUrl" :max="1"></img-upload2>
      </Row>
    </Modal>
    <ReleTableModal v-model="showBatterySelect" :row="deviceModel" @change-select="updateBattery"></ReleTableModal>
    <ReleTableModal v-model="showInverterSelect" :row="inverterModel" @change-select="updateInverter"></ReleTableModal>
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
  @import "../../less/table";

  .panel {
    background: white;
    margin-bottom: 15px;
    .plan-list {
      .plan-item {
        padding: 10px 0;
        font-size: 16px;
        line-height: 30px;
        text-align: center;
        color: #aaaaaa;
        cursor: pointer;
        position: relative;
        &:after {
          content: ' ';
          width: 1px;
          height: 20px;
          position: absolute;
          right: 0;
          display: block;
          top: 15px;
          background: #aaaaaa;
        }
        &:last-child {
          &:after {
            width: 0;
          }
        }
        &.active {
          background: #90a2ca;
          color: white;
          &:after {
            width: 0;
          }
        }
      }
    }
  }

</style>
<script type="text/ecmascript-6">
  import DeviceModel from '../../assets/models/device'
  import OtherMaterial from './other-material'

  export default {
    components: {
      OtherMaterial
    },
    props: {
      serverId: {
        type: [Number, String],
        default () {
          return ''
        }
      },
      plans: {
        type: Array,
        default () {
          return []
        }
      }
    },
    computed: {
      currentPlans () {
        if (this.selectPlan) {
          let batteryBoard = {
            deviceName: this.selectPlan.solarPanel.brandName,
            deviceBrand: this.selectPlan.solarPanel.brandName,
            deviceSpec: this.selectPlan.solarPanel.model,
            // 质保
            deviceShelfLife: this.selectPlan.solarPanel.boardYear,
            WarrantyYear: this.selectPlan.solarPanel.qualityAssurance,
            conversionEfficiency: this.selectPlan.solarPanel.conversionEfficiency
          }
          let inverter = {
            deviceName: this.selectPlan.inverter.brandName,
            deviceBrand: this.selectPlan.inverter.brandName,
            deviceSpec: this.selectPlan.inverter.model,
            // 质保
            deviceShelfLife: this.selectPlan.inverter.boardYear,
            WarrantyYear: this.selectPlan.inverter.qualityAssurance
          }
          let others = []
          let otherDevices = []
          if (this.selectPlan.materialJson) {
            try {
              others = JSON.parse(this.selectPlan.materialJson)
            } catch (e) {
              console(e)
            }
          }
          others.forEach((other) => {
            if (!other.children) {
              otherDevices.push({
                deviceName: other.devideName,
                deviceBrand: '/',
                deviceSpec: '/',
                // 质保
                deviceShelfLife: '/',
                WarrantyYear: '/',
                conversionEfficiency: '/'
              })
            } else {
              other.children.forEach(subOther => {
                otherDevices.push({
                  deviceName: other.devideName + '---' + subOther.devideName,
                  deviceBrand: '/',
                  deviceSpec: '/',
                  // 质保
                  deviceShelfLife: '/',
                  WarrantyYear: '/',
                  conversionEfficiency: '/'
                })
              })
            }
          })
          return [batteryBoard, inverter, ...otherDevices]
        } else {
          return []
        }
      }
    },
    data () {
      return {
        deviceModel: {
          title: '电池板',
          selectUrl: 'InvSolar/solarfindAll?zlevel=2&type=1',
          one: DeviceModel
        },
        inverterModel: {
          title: '逆变器',
          selectUrl: 'InvSolar/solarfindAll?zlevel=2&type=3',
          one: DeviceModel
        },
        selectPlan: null,
        showPlanEdit: false,
        showBatterySelect: false,
        showInverterSelect: false,
        clonePlans: null,
        radioType: 1
      }
    },
    methods: {
      selectSomePlan (plan) {
        this.selectPlan = plan
      },
      addPlan () {
        this.showPlanEdit = true
        this.selectPlan = {
          solarPanel: {
            planName: '',
            brandName: '',
            model: '',
            boardYear: '',
            qualityAssurance: '',
            id: '',
            conversionEfficiency: ''
          },
          inverter: {
            brandName: '',
            model: '',
            boardYear: '',
            qualityAssurance: '',
            id: ''
          },
          materialJson: '[]',
          minPurchase: '',
          unitPrice: '',
          serverId: this.serverId,
          planImgUrl: ''
        }
      },
      updateBattery (device) {  // 电池板
        this.selectPlan.solarPanel.brandName = device.brandName
        this.selectPlan.solarPanel.model = device.model
        this.selectPlan.solarPanel.id = device.id
      },
      backPlan () {
        this.$emit('on-update-plans', this.clonePlans)
        if (this.clonePlans) {
          this.clonePlans.forEach((plan) => {
            if (plan.id === this.selectPlan.id) {
              this.selectPlan = plan
              return
            }
          })
        }
        window.location.reload()
      },
      updateInverter (device) { // 逆变器
        this.selectPlan.inverter.brandName = device.brandName
        this.selectPlan.inverter.model = device.model
        this.selectPlan.inverter.id = device.id
      },
      save () {
        if (!this.selectPlan.planName) {
          this.$Message.info('请填写方案名称')
          return
        }
        if (!this.selectPlan.solarPanel.brandName) {
          this.$Message.info('请选择电池板')
          return
        }
        if (!this.selectPlan.solarPanel.boardYear) {
          this.$Message.info('请填写电池板保质期')
          return
        }
        if (!this.selectPlan.solarPanel.qualityAssurance) {
          this.$Message.info('请填写电池板保修期')
          return
        }
        if (!this.selectPlan.solarPanel.conversionEfficiency) {
          this.$Message.info('请填写电池板转化率')
          return
        }
        if (!this.selectPlan.inverter.brandName) {
          this.$Message.info('请选择逆变器')
          return
        }
        if (!this.selectPlan.inverter.boardYear) {
          this.$Message.info('请填写逆变器保质期')
          return
        }
        if (!this.selectPlan.inverter.qualityAssurance) {
          this.$Message.info('请填写逆变器保修期')
          return
        }
        if (this.selectPlan.materialJson === '[]') {
          this.$Message.info('请选择其他材料')
          return
        }
        if (!this.selectPlan.minPurchase) {
          this.$Message.info('请填写最低购买千瓦数')
          return
        }
        if (!this.selectPlan.unitPrice) {
          this.$Message.info('请填写价格')
          return
        }
        if (!this.selectPlan.planImgUrl) {
          this.$Message.info('请上传方案图片')
          return
        }
        this.$http.post('serverPlan/newsave', this.selectPlan).then(res => {
          if (res.code === 200) {
            this.$Message.success('保存成功!')
            window.location.reload()
          }
        })
      },
      deletePlan () {
        this.$Modal.confirm({
          title: '确认删除',
          content: '操作无法撤销 是否执行?',
          onOk: () => {
            this.$http.post('serverPlan/newdelete', {id: this.selectPlan.id}).then(res => {
              if (res.code === 200) {
                this.$Message.success('删除成功!')
                window.location.reload()
              }
            })
          }
        })
      }
    },
    mounted () {
      this.$nextTick(() => {
        if (this.plans && this.plans.length > 0) {
          this.selectSomePlan(this.plans[0])
          this.clonePlans = JSON.parse(JSON.stringify(this.plans))
        }
      })
    }
  }
</script>

