<template>
  <div>
    <Checkbox-group v-model="selectMaterial">
      <template v-for="material in list">
        <Checkbox :label="material.id">
          <span>{{material.devideName}}
            <template v-if="material.children">
              <ul style="margin-left: 30px;color: #999">
                <li v-for="m in material.children">{{m.devideName}}</li>
              </ul>
            </template>
          </span>
        </Checkbox>
        <br>
      </template>
    </Checkbox-group>
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
</style>
<script type="text/ecmascript-6">
  export default {
    props: {
      value: {
        type: String
      }
    },
    watch: {
      value: 'initSelectMaterial',
      selectMaterial (val) {
        if (this.list && this.list.length > 0) {
          let ms = []
          this.list.forEach((material) => {
            if (val.indexOf(material.id) >= 0) {
              ms.push(material)
            }
          })
          this.$emit('input', JSON.stringify(ms))
        }
      }
    },
    data () {
      return {
        list: [],
        selectMaterial: []
      }
    },
    methods: {
      initSelectMaterial () {
        let selects = []
        if (this.value) {
          let list = JSON.parse(this.value) || []
          list.forEach((item) => {
            if (item.id) {
              selects.push(item.id)
            }
          })
        }
        this.selectMaterial = selects
      }
    },
    mounted () {
      this.$http.post('InvSolar/solarfindAll', {zlevel: 2, type: 2}).then(res => {
        this.list = res.data
      })
      this.$nextTick(() => {
        this.initSelectMaterial()
      })
    }
  }
</script>
