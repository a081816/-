<template>
  <div class="content">
    <div class="content_t">
      <p>最新订单</p>
      <div class="more" v-if="showBtn('sys:index:orderMore')">
        <router-link to="/Order">查看更多>></router-link>
      </div>
    </div>
    <div class="content_b">
      <Table :columns="columns1" :data="orderList" @on-row-click="rowClick"></Table>
    </div>
  </div>
</template>
<style lang="less" rel="stylesheet/less">
  @import "../../less/table";

  .cards2 {
    box-sizing: border-box;
    margin-top: 30px;
    .content {
      background-color: #ebfff9;
      padding-bottom: 36px;
      box-sizing: border-box;
      .content_t {
        box-sizing: border-box;
        height: 60px;
        padding: 20px;
        color: #ffffff;
        font-size: 16px;
        background-color: #3dcb9d;
        position: relative;
        .more {
          position: absolute;
          top: 20px;
          right: 20px;
          a {
            color: #ffffff;
          }
        }
      }
      .content_b {
        background-color: #ffffff;
        .ivu-table-row {
          cursor: pointer;
        }
      }
    }
  }
  tr.ivu-table-row-hover td{
    background-color: #ebfff9;
  }
</style>
<script type="text/ecmascript-6">

  export default {
    data () {
      return {
        columns1: [
          {
            title: '订单码',
            key: 'orderCode'
          },
          {
            title: '联系人',
            key: 'linkmanName'
          },
          {
            title: '联系电话',
            key: 'linkmanTelephone'
          },
          {
            title: '装机容量(KW)',
            key: 'orderPrice'
          }
        ],
        orderList: []
      }
    },
    methods: {
      rowClick (row) {
        let buttonSet = this.$store.state.user.user.buttonSet
        let uesrPres = 'sys:index:orderMore'
        if (buttonSet.indexOf(uesrPres) >= 0) {
          this.$router.push({name: 'OrderDetail', query: {orderCode: row.orderCode}})
        } else {
          this.$Message.error('您无权查看订单详细信息')
        }
      },
      initData () {
        this.$http.get('/index/order/new').then(res => {
          this.orderList = res.orderList
        })
      }
    },
    mounted () {
      this.initData()
    }
  }
</script>
