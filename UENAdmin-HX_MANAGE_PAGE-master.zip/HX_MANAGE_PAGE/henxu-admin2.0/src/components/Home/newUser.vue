<template>
  <div class="content">
    <div class="content_t">
      <p>最新用户</p>
      <div class="more" v-if="showBtn('sys:index:userMore')">
        <router-link to="/User/User">查看更多>></router-link>
      </div>
    </div>
    <div class="content_b">
      <Table :columns="columns" :data="userList" @on-row-click="rowClick"></Table>
    </div>
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
  .cards2 {
    box-sizing: border-box;
    margin-top: 30px;
    .content {
      background-color: #ebfff9;
      padding-bottom: 36px;
      box-sizing: border-box;
      .content_t {
        box-sizing: border-box;
        height: 60px;
        padding: 20px;
        color: #ffffff;
        font-size: 16px;
        background-color: #3dcb9d;
        position: relative;
        .more {
          position: absolute;
          top: 20px;
          right: 20px;
          a {
            color: #ffffff;
          }
        }
      }
      .content_b {
        background-color: #ffffff;
      }
    }
  }
</style>
<script type="text/ecmascript-6">

  export default {
    data () {
      return {
        columns: [
          {
            title: '姓名',
            key: 'realName',
            render: (h, params) => {
              console.log(params.row)
              if (params.row.realName) {
                return h('div', [
                  h('span', params.row.realName)
                ])
              } else {
                return h('div', [
                  h('span', params.row.nickName)
                ])
              }
            }
          },
          {
            title: '账号',
            key: 'account'
          },
          {
            title: '联系电话',
            key: 'telephone'
          },
          {
            title: '注册时间',
            key: 'registerTime'
          }
        ],
        userList: []
      }
    },
    methods: {
      initData () {
        // 用户列表
        this.$http.get('index/user/new').then(res => {
          this.userList = res.userList
        })
      },
      rowClick (row) {
        let buttonSet = this.$store.state.user.user.buttonSet
        let uesrPres = 'sys:index:userMore'
        if (buttonSet.indexOf(uesrPres) >= 0) {
          this.$router.push({name: 'UserDetail', query: {id: row.id}})
        } else {
          this.$Message.error('您无权查看用户详细信息')
        }
      }
    },
    mounted () {
      this.initData()
    }
  }
</script>
