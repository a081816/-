<template>
  <div class="content">
    <div class="content_t">
      <p>最新故障</p>
      <!--<div class="more">
        <a href="#"> 查看更多>></a>
      </div>-->
    </div>
    <div class="content_b">
      <Table :columns="columns1" :data="stationStatusVoList"  @on-row-click="rowClick"></Table>
    </div>
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
  .cards2 {
    box-sizing: border-box;
    margin-top: 30px;
    .content {
      border-radius: 4px;
      background-color: #ebfff9;
      padding-bottom: 36px;
      box-sizing: border-box;
      .content_t {
        border-radius: 4px 4px 0 0;
        box-sizing: border-box;
        height: 60px;
        padding: 20px;
        color: #ffffff;
        font-size: 16px;
        background-color: #3dcb9d;
        position: relative;
        .more {
          position: absolute;
          top: 20px;
          right: 20px;
          a {
            color: #ffffff;
          }
        }
      }
      .content_b {
        background-color: #ffffff;
      }
    }
  }
</style>
<script type="text/ecmascript-6">

  export default {
    data () {
      return {
        columns1: [
          {
            title: '电站码',
            key: 'stationCode'
          },
          {
            title: '电站名称',
            key: 'stationName'
          },
          {
            title: '发生时间',
            key: 'recordTime'
          },
          {
            title: '故障原因',
            key: 'statusCodeDesc'
          }
        ],
        stationStatusVoList: []
      }
    },
    methods: {
      initData () {
        this.$http.get('index/status/new').then(res => {
          this.stationStatusVoList = res.stationStatusVoList
        })
      },
      rowClick (row) {
        let buttonSet = this.$store.state.user.user.buttonSet
        let uesrPres = 'sys:index:stationMore'
        if (buttonSet.indexOf(uesrPres) >= 0) {
          this.$router.push({name: 'StationDetail', query: {id: row.id, stationCode: row.stationCode}})
        } else {
          this.$Message.error('您无权查看电站中的故障信息')
        }
      }
    },
    mounted () {
      this.initData()
    }
  }
</script>
