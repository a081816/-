<template>
  <div>
    <Row v-if="searchable" style="margin-bottom: 20px">
      <i-col style="float: right">
        <i-input style='width: 250px' v-model="query" @keyup.enter.native="loadData" placeholder=""></i-input>
        <Button style="width: 80px" type="primary" @click.native="loadData">搜索</Button>
      </i-col>
    </Row>
    <i-table :height="580" @on-row-click="onRowClick" @on-sort-change="onChangeSort" :width="tableWidth"
             @on-selection-change="onSelectionChange"
             :columns="iColumn"
             :data="data"></i-table>
    <div class="table-page">
      <Page style="float: right" :current="tableParams.page" :page-size="tableParams.pageSize"
            :total="tableParams.total"
            @on-change="onChangePage" @on-page-size-change="onPageSizeChange" placement="top" show-total show-sizer
            show-elevator></Page>
    </div>
  </div>
</template>
<style lang="less">
  .table-page {
    display: block;
    height: 30px;
    width: 100%;
    margin-top: 20px;
  }

  .ivu-table-wrapper {
    border: none;
  }

  .ivu-table th {
    border: none;
    border-bottom: 1px solid black;
    background-color: white;
  }

  .ivu-table:before, .ivu-table:after {
    background: white;
  }

  .ivu-table td {
    border-bottom-style: dashed;
  }
</style>

<script>
  export default {
    props: {
      noInit: {
        type: Boolean,
        default () {
          return false
        }
      },
      showInsert: {
        type: Boolean,
        default () {
          return true
        }
      },
      insertAction: {
        type: Function,
        default () {
          return () => {
          }
        }
      },
      onRowClick: {
        type: Function,
        default () {
          return (row) => {
          }
        }
      },
      column: {
        type: Array
      },
      rowHandle: {
        type: Array,
        default () {
          return []
        }
      },
      tableHandle: {
        type: Array,
        default () {
          return []
        }
      },
      customParams: {
        type: [Array],
        default () {
          return []
        }
      },
      api: {
        type: String
      },
      searchable: {
        type: Boolean,
        default () {
          return false
        }
      }
    },
    data () {
      return {
        tableParams: {
          pageSize: 10,
          page: 1,
          total: 0
        },
        sortParams: {
          sortUp: 'desc',
          sortBy: 'id'
        },
        sortParams1: {
          sortUp: 'desc',
          sortBy: 'rowId'
        },
        data: [],
        selection: [],
        query: null,
        tableWidth: '',
        showFieldsDisplaySetting: false,
        displayColumns: [],
        displayFields: [],
        // 真正显示的数据列
        iColumn: [],
        innerParams: [],
        userId: ''
      }
    },
    computed: {
      searchFields () {
        let placeholder = '输入以下信息搜索: '
        this.column.forEach(row => {
          if (row.searchable) {
            placeholder += `${row.title}、`
          }
        })
        return placeholder.substring(0, placeholder.length - 1)
      }
    },
    watch: {
      displayFields: 'renderDisplayColumns',
      column: 'initDisplayFields',
      displayColumns: 'initIColumns',
      sortParams: 'loadData'
    },
    methods: {
      onChangeSort (sort) {
        this.sortParams = {
          sortUp: sort.order === 'asc' ? 'asc' : 'desc',
          sortBy: sort.key
        }
      },
      initIColumns () {
        // 如果表格的批量操作方法不为空 才有前面的多选框
        let iColumn = this.tableHandle && this.tableHandle.length > 0 ? [
          {
            type: 'selection',
            width: 60,
            align: 'center'
          }
        ] : []
        this.displayColumns.forEach((col, index) => {
          // 将field字段转换为key
          let val = col
          val.key = val.field
          val.sortable = val.sort ? 'custom' : false
          if (val.filter) {
            /* val.filters = []

            Object.keys(val.filter).forEach(filterKey => {
              val.filters.push({label: val.filter[filterKey], value: filterKey})
            })
            val.filterMethod = function (value, row) {
              // use this scope
              'use strict'
              return row[this.key] && row[this.key].toString().indexOf(value.toString()) > -1
            } */
            // TODO 调用接口获取最新的数据 需要和后端商讨是否可行 暂时用旧方案
            /* val.filterRemote = function (value, row) {
              console.log(value, row)
            } */
          }
          // 给字段定宽 但是效果不好看 由于光伏没有表格字段是特别多的 所以可以去掉
          /* if (val.vue && val.vue.columnWidth) {
            val.width = val.vue.columnWidth
          } else if (val.filter || val.sort) {
            val.width = (val.title.length + 2) * 30
          } else {
            val.width = val.title.length * 30
          } */
          let rowRender = null
          switch (val.xtype) {
            case 'custom':
              rowRender = (h, params) => {
                return val.customRender(h, params)
              }
              break
            case 'link':
              rowRender = (h, params) => {
                const row = params.row
                const column = params.column
                if (row[column['field']]) {
                  return h('router-link', {
                    style: {
                      width: '100%'
                    },
                    props: {
                      to: {name: 'editForm', query: {table: column['linkTable'] || '', id: row[column['field']]}}
                    }
                  }, row[column['field']])
                } else {
                  return h('span', '')
                }
              }
              break
            // 如果是图片类型
            case 'img':
              rowRender = (h, params) => {
                const row = params.row
                const column = params.column
                if (row[column['field']]) {
                  return h('img', {
                    style: {
                      height: '60px'
                    },
                    attrs: {
                      src: row[column['field']] || 'error'
                    },
                    on: {
                      click: () => {
                        this.showImg(row[column['field']])
                      }
                    }
                  })
                } else {
                  return h('span', '')
                }
              }
              break
            default:
              rowRender = (h, params) => {
                const row = params.row
                const column = params.column
                return h('span', this.$form.getRowValue(row, column))
              }
              break
          }
          val.render = rowRender
          iColumn.push(val)
        })
        // 添加行操作
        let rowHandler = this.rowHandle
        if (rowHandler.length > 0) {
          iColumn.push({
            title: '操作',
            key: 'action',
            width: rowHandler.length * 70,
            render: (h, params) => {
              const rowIndex = params.index
              let actions = []
              rowHandler.forEach((val, index) => {
                actions.push(h('Button', {
                  props: {
                    type: val.type || 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '10px',
                    padding: '5px'
                  },
                  on: {
                    click: (e) => {
                      this.runAction(index, rowIndex, e)
                    }
                  }
                }, val.name))
              })
              return h('div', actions)
            }
          })
        }
        this.iColumn = iColumn
      },
      closeDisplaySetting () {
        this.showFieldsDisplaySetting = false
      },
      initDisplayFields () {
        let fields = []
        this.column.forEach(field => {
          if (field.isShow) {
            fields.push(field.field)
          }
        })
        this.displayFields = fields
      },
      renderDisplayColumns () {
        let displayFields = JSON.parse(JSON.stringify(this.displayFields))
        let displayColumns = []
        this.column.forEach(field => {
          if (displayFields.indexOf(field.field) >= 0) {
            displayColumns.push(field)
          }
        })
        this.displayColumns = displayColumns
        this.initIColumns()
      },
      getTableWidth () {
        this.tableWidth = this.$el.clientWidth
      },
      // 获取请求参数
      getRequestParams () {
        let customParams = {}
        if (this.customParams) {
          this.customParams.forEach(param => {
            if (typeof param === 'function') {
              // 将表格实例传递给他
              let newParam = param(this)
              customParams[newParam.key] = newParam.value
            } else {
              customParams[param.key] = param.value
            }
          })
        }
        return Object.assign({}, {
          page: this.tableParams.page - 1,
          size: this.tableParams.pageSize,
          query: this.query,
          sort: `${this.sortParams.sortBy},${this.sortParams.sortUp}`
        }, customParams)
      },
      getRequestParams1 () {
        let customParams = {}
        if (this.customParams) {
          this.customParams.forEach(param => {
            if (typeof param === 'function') {
              // 将表格实例传递给他
              let newParam = param(this)
              customParams[newParam.key] = newParam.value
            } else {
              customParams[param.key] = param.value
            }
          })
        }
        return Object.assign({}, {
          page: this.tableParams.page - 1,
          size: this.tableParams.pageSize,
          query: this.query,
          sort: `${this.sortParams1.sortBy},${this.sortParams1.sortUp}`
        }, customParams)
      },
      onSelectionChange (selection) {
        this.selection = selection
      },
      // 获取参数 然后请求接口
      loadData () {
        if (!this.api) {
          this.$Message.error('API地址没有填写')
        } else { // 电站管理，订单管理多传一个managerId参数
          if (this.api === 'station/findAll' || this.api === 'order/findAll') {
            this.data = []
            this.$http.post(this.api, Object.assign({}, this.getRequestParams(), {managerId: this.$store.getters.userInfo.id})).then(res => {
              this.data = res.data.content
              this.tableParams.total = res.data.totalElements
            })
          } else if (this.api === 'devConf/findAll') {
            this.data = []
            this.$http.post(this.api, Object.assign({}, this.getRequestParams1())).then(res => {
              this.data = res.data.content
              this.tableParams.total = res.data.totalElements
            })
          } else {
            this.data = []
            this.$http.post(this.api, this.getRequestParams()).then(res => {
              this.data = res.data.content
              this.tableParams.total = res.data.totalElements
            })
          }
        }
      },
      runAction (index, rowIndex, e) {
        // 执行行操作
        this.rowHandle[index]['action'](this.data[rowIndex], e)
      },
      onChangePage (page) {
        // 改变页码
        this.tableParams.page = page
        this.loadData()
      },
      onPageSizeChange (pageSize) {
        // 改变每页显示数量
        this.tableParams.pageSize = pageSize
        this.loadData()
      },
      // 调用vuex的图片预览 在app组件中声明了 直接调用即可
      showImg (img) {
        this.$store.dispatch('openPreview', img)
      }
    },
    mounted () {
      this.$nextTick(() => {
        this.getTableWidth()
      })
      this.initDisplayFields()
      if (!this.noInit) {
        this.loadData()
      }
    }
  }
</script>
