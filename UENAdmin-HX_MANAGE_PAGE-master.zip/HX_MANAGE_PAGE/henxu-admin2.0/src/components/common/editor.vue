<template>
  <div id="editor-wrapper">
    <div id="editor" class="editor" :style="{height: (height || 600) + 'px'}"></div>
    <div class="tips" style="color: red;font-size: 16px">
      注意 这里的字号 为了规范化 全部由前端样式决定(方便移动和PC兼容) 根据标签去定制样式 而不是写死大小 目前编辑器默认的字体大小是 16px 请注意!
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  const E = require('wangeditor')
  import UUID from 'uuid'
  const id = UUID.v1()
  export default{
    props: ['value', 'height'],
    data () {
      return {
        id: id,
        editor: null,
        content: this.value
      }
    },
    watch: {
      value (val) {
        this.editor.txt.html(val)
      }
    },
    methods: {},
    mounted () {
      this.$nextTick(() => {
        let editor = new E('#editor')
        editor.customConfig.onchange = (html) => {
          // onchange 事件中更新数据
          this.$emit('input', html)
        }
        editor.customConfig.uploadImgServer = this.$api.fileUpload
        editor.customConfig.uploadFileName = 'file'
        editor.customConfig.zIndex = 100
        editor.customConfig.uploadImgHooks = {
          before: function (xhr, editor, files) {
            // 图片上传之前触发
            // xhr 是 XMLHttpRequst 对象，editor 是编辑器对象，files 是选择的图片文件
          },
          success: function (xhr, editor, result) {
            // 图片上传并返回结果，图片插入成功之后触发
            // xhr 是 XMLHttpRequst 对象，editor 是编辑器对象，result 是服务器端返回的结果
          },
          fail: function (xhr, editor, result) {
            // 图片上传并返回结果，但图片插入错误时触发
            // xhr 是 XMLHttpRequst 对象，editor 是编辑器对象，result 是服务器端返回的结果
            this.$Notice.error({
              title: '插入失败',
              desc: '网络繁忙，如果多次出现，请联系管理员',
              duration: 5
            })
          },
          error: function (xhr, editor) {
            this.$Notice.error({
              title: '上传失败',
              desc: '网络繁忙，如果多次出现，请联系管理员',
              duration: 5
            })
          },
          timeout: function (xhr, editor) {
            this.$Notice.error({
              title: '上传超时',
              desc: '网络出错，如果多次出现，请联系管理员',
              duration: 5
            })
          },
          // result 必须是一个 JSON 格式字符串！！！否则报错
          customInsert: function (insertImg, result, editor) {
            insertImg(result.data[0])
          }
        }
        editor.create()
        this.editor = editor
      })
    }
  }
</script>
<style lang="less" scoped>
  #editor-wrapper {
    z-index: 9 !important;
    font-size: 16px;
  }
</style>
<style lang="less">
  .w-e-text-container{
    height: 550px!important;
  }
</style>
