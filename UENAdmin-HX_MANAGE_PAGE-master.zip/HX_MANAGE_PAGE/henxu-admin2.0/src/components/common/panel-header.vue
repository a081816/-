<template>
  <div class="header-wrapper" :style="{background: themeColor.bgColor}">
    <img :src="icon" alt="">
    <span class="title" :style="{color: themeColor.textColor}"><slot></slot></span>
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
  @import "../../less/theme";
  .header-wrapper {
    font-size: 16px;
    background: @mainColor;
    line-height: 45px;
    height: 45px;
    padding: 0 5px;
    color: white;
    img {
      vertical-align: -5%;
      padding: 0 10px;
      height: 16px;
    }
  }
</style>
<script type="text/ecmascript-6">
  export default{
    props: {
      icon: {
        type: String
      },
      theme: {
        type: String,
        default () {
          return 'light'
        }
      }
    },
    computed: {
      themeColor () {
        let config = {
          dark: {
            bgColor: '#90a2ca',
            textColor: 'white'
          },
          light: {
            bgColor: 'white',
            textColor: '#90a2ca'
          }
        }
        return config[this.theme]
      }
    }
  }
</script>
