<template>
  <div>
    <section class="panel" style="height: 150px">
      <panel-header :icon="require('@/assets/icons/xiugai.png')">
        <span style="padding-right: 10px; font-weight: bold; color: red">{{typeLabel}}</span>新增图片
      </panel-header>
      <row>
        <i-col :span="22" style="font-size: 16px; color: #2baee9; padding-top: 10px">
          支持多文件同时选择上传，每张图片大小 2M 以内,支持的格式有：jpeg、gif、png、bmp</i-col>
        <i-col :span="22" style="font-size: 16px; color: red; padding-top: 10px">
          注意：上传完成所选图片之后，请点击保存</i-col>
      </row>
    </section>
    <section class="panel">
      <Upload
        ref="upload"
        :on-success="handleSuccess"
        :max-size="2048"
        :on-error="handleFormatError"
        :on-exceeded-size="handleMaxSize"
        :before-upload="handleBeforeUpload"
        :multiple="true"
        accept="image/jpeg,image/gif,image/png,image/bmp"
        type="drag"
        :action="$api.fileUpload"
      >
        <div style="padding: 20px 0">
          <Icon type="ios-cloud-upload" size="52" style="color: #3399ff"></Icon>
          <p>点击或将文件拖拽到这里上传</p>
        </div>
      </Upload>
    </section>
      <Row style="padding: 10px 0">
        <Button type="primary" @click.native="save">保存</Button>
      </Row>
  </div>
</template>
<script type="text/ecmascript-6">

  export default {
    data () {
      return {
        defaultList: [],
        max: 10
      }
    },
    computed: {
      typeLabel () {
        return ['', '自建房类别', '别墅类别', '工商类别'][parseInt(this.$route.query.type)]
      }
    },
    methods: {
      save () {
        this.$http.post(this.$api.news.ConstrSave, Object.assign({}, {imgUrls: this.defaultList.toString()}, this.$route.query)).then(res => {
          if (res.code === 200) {
            this.$Message.success('保存成功!')
            this.$router.back()
          }
        })
      },
      handleSuccess (res, file) {
        // 因为上传过程为实例，这里模拟添加 url
        if (res.data && res.code === 200) {
          file.url = res.data
         // this.updateValue()
          this.defaultList.push(file.url)
        } else {
          this.$Notice.warning({
            title: '上传失败',
            desc: res.data.data
          })
        }
      },
      handleFormatError (file) {
        this.$Notice.warning({
          title: '文件格式不正确',
          desc: '文件 ' + file.name + ' 格式不正确'
        })
      },
      handleMaxSize (file) {
        this.$Notice.warning({
          title: '超出文件大小限制',
          desc: '文件 ' + file.name + ' 太大，不能超过 2 M。'
        })
      },
      handleBeforeUpload (file) {
        if (file.type === 'image/png' || file.type === 'image/gif' || file.type === 'image/jpeg' || file.type === 'image/bmp') {
        } else {
          this.$Notice.warning({
            title: '文件格式不正确',
            desc: '文件 ' + file.name + ' 格式不正确'
          })
          return false
        }
      }
    }
  }
</script>
<style>
  .upload-list {
    display: inline-block;
    width: 100px;
    height: 100px;
    text-align: center;
    line-height: 100px;
    border: 1px solid transparent;
    border-radius: 4px;
    overflow: hidden;
    background: #fff;
    position: relative;
    box-shadow: 0 1px 1px rgba(0, 0, 0, .2);
    margin-right: 4px;
  }

  .upload-list img {
    width: 100%;
    height: 100%;
  }

  .upload-list-cover {
    display: none;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, .6);
  }

  .upload-list:hover .upload-list-cover {
    display: block;
  }

  .upload-list-cover i {
    color: #fff;
    font-size: 20px;
    cursor: pointer;
    margin: 0 2px;
  }

  .video-player {
    width: 100%;
    height: 100%;
    position: fixed;
  }
  .panel {
    margin-bottom: 15px;
    background: white;
    padding: 15px
  }
</style>
