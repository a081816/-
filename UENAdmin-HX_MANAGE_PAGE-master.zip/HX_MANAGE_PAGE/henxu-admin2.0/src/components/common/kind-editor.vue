<template>
  <div id="editor-wrapper">
    <div :id="id" class="editor" :style="{height: (height || 500) + 'px'}"></div>
  </div>
</template>
<script type="text/ecmascript-6">
//  import 'kindeditor'
  import UUID from 'uuid'

  const id = UUID.v1()
  export default {
    props: ['value', 'height'],
    data () {
      return {
        id: id,
        editor: null,
        content: this.value,
        isInit: false
      }
    },
    watch: {
      content (val) {
        if (val) {
          this.$emit('input', val)
        }
      },
      value (val) {
        this.$nextTick(() => {
          if (!this.isInit) {
            this.isInit = true
            this.editor && this.editor.html(val)
          }
        })
      }
    },
    methods: {
      initEditor () {
        if (!this.editor) {
          let K = window.KindEditor
          let options = {
            uploadJson: this.$api.fileUpload4KindEditor,
            filePostName: 'file',
            allowMediaUpload: false,
            allowFlashUpload: false,
            zIndex: 100,
            afterUpload: (url) => {
             // window.alert(url)
              console.log(url)
            },
            afterChange: () => {
              this.content = this.editor && this.editor.html()
            }
          }
          this.editor = K.create('#' + id, options)
          if (this.editor && this.value) {
            this.editor.html(this.value)
          }
        }
      }
    },
    created () {
      this.$nextTick(() => {
        this.initEditor()
      })
    },
    mounted () {
      this.$nextTick(() => {
        this.initEditor()
      })
    }
  }
</script>
<style lang="less" scoped>
  #editor-wrapper {
    z-index: 9 !important;
    font-size: 16px;
  }
</style>
<style lang="less">
  .w-e-text-container {
    height: 550px !important;
  }
</style>
