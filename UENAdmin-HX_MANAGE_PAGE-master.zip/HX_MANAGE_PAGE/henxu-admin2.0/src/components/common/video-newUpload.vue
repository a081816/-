<template>
  <div>
    <section class="panel">
      <panel-header :icon="require('@/assets/icons/xiugai.png')">
        <span style="padding-right: 10px; font-weight: bold; color: red">{{typeLabel}}</span>
        <span v-if="this.$route.query.id">编辑</span>
        <span v-else>新增</span>
      </panel-header>
      <Row class="base-info">
        <i-col :span="22">
          <div class="wrapper">
            <div class="label top">展示图片: </div>
            <div class="value">
              <Row class="banner">
                <img-upload2 v-model="form.imgUrl" :max="1"></img-upload2>
              </Row>
            </div>
          </div>
        </i-col>
        <i-col :span="22">
          <div class="wrapper">
            <div class="label top">视频上传: </div>
            <div class="value">
              <video-upload :max="1" v-model="form.videoUrl"></video-upload>
            </div>
          </div>
        </i-col>
      </Row>
    </section>
    <section class="panel" style="padding: 15px 30px;">
      <Row style="padding: 10px 0">
        <Button type="primary" @click.native="save">发布</Button>
      </Row>
    </section>
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
  .panel {
    margin-bottom: 15px;
    background: white;
  }

  #html-preview {
    .preview {
      .title {
        margin-bottom: 15px;
        h2 {
          font-size: 18px;
          padding: 10px 0;
        }
      }
    }
  }

  .preview {
    padding: 10px 30px;
  }

  .base-info {
    background: white;
    padding: 15px;
    .wrapper {
      display: flex;
      width: 100%;
      margin-bottom: 20px;
      .label {
        flex: 0 0 100px;
        align-self: center;
        font-size: 16px;
        text-align: right;
        padding-right: 15px;
        &.top {
          align-self: flex-start;
        }
      }
      .value {
        flex: 1;
      }
    }
  }
</style>
<script type="text/ecmascript-6">

  export default {
    props: {
      activeType: {
        default () {
          return []
        }
      }
    },
    data () {
      return {
        form: {
          imgUrl: '',
          videoUrl: ''
        }
      }
    },
    computed: {
      typeLabel () {
        return ['', '自建房类别', '别墅类别', '工商类别'][parseInt(this.$route.query.type)]
      }
    },
    methods: {
      save () {
        if (!this.form.imgUrl) {
          this.$Message.info('请上传展示图片')
          return
        }
        if (this.form.videoUrl) {
          if (!this.form.imgUrl) {
            this.$Message.info('请上传展示图片')
            return
          }
        }
        this.$http.post(this.$api.news.ConstrSave, Object.assign({}, {imgUrl: this.form.imgUrl, videoUrl: this.form.videoUrl}, this.$route.query)).then(res => {
          if (res.code === 200) {
            this.$Message.info('操作成功')
            this.$router.back()
          }
        })
      }
    },
    mounted () {
      if (this.$route.query.id) {
        this.$http.post(this.$api.construction.findOne, {id: this.$route.query.id}).then(res => {
          this.form = res.data
        })
      }
    }
  }
</script>
