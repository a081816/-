<template>
  <div>
    <div class="upload-list">
      <!--已经上传的文件列表-->
      <div class="item" v-for="(item, index) in fileList">
        <img :src="item">
        <div class="cover">
          <Icon type="ios-eye-outline" @click.native="handleView(item)"></Icon>
          <Icon type="ios-trash-outline" @click.native="handleRemove(index - 1)"></Icon>
        </div>
      </div>
      <!--正在上传的文件列表-->
      <div class="item" v-for="item in uploading">
        <Progress class="progress" :percent="item.progress" hide-info></Progress>
      </div>
      <div class="action" v-if="uploading.length <= 0 && fileList.length < max">
        <img class="upload-action" style="height: 100px;width: auto;display: inline;"
             :src="require('@/assets/icons/tu.png')"
             alt="">
        <input type="file" id="upload-file" :multiple="multiple" @change="selectFile">
      </div>
      <div class="tips"
           style="margin-left: 15px;align-self: center;text-align:left;color: #c4c4c4;font-size: 16px;line-height: 20px">
        <p>图片格式要求:</p>
        <p>图片只能以bmp、jpeg、jpg、gif 格式上传 , 大小 2M 以内，宽300像素，高150像素</p>
      </div>
    </div>
  </div>
</template>
<style lang="less" scoped="">
  .action {
    position: relative;
    margin-left: 5px;
    .upload-action {
      z-index: 0;
    }
    #upload-file {
      z-index: 1;
      position: absolute;
      opacity: 0;
      top: 0;
      left: 0;
      height: 100px;
      width: 156px;
    }
  }

  .upload-list {
    display: flex;
    width: 100%;
    height: 100px;
    border: none;
    border-radius: 0;
    .item {
      display: inline-block;
      height: 100px;
      width: 100px;
      position: relative;
      margin-left: 5px;
      img {
        width: 100%;
        height: 100%;
        z-index: -1;
      }
      .cover {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        font-size: 18px;
        color: red;
        z-index: 1;
        &:after {
          width: 100px;
          height: 100px;
          position: absolute;
          left: -35px;
          top: -35px;
          content: ' ';
          background: rgba(255, 255, 255, 0.2);
          z-index: -1;
        }
      }
      .progress {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 2;
      }
    }
  }
</style>

<script type="text/ecmascript-6">
  import UUID from 'uuid'

  export default {
    props: {
      value: {
        type: String
      },
      multiple: {
        type: Boolean,
        default () {
          return false
        }
      },
      returnStr: {
        type: Boolean,
        default () {
          return true
        }
      },
      max: {
        type: Number,
        default () {
          return 1
        }
      },
      // kb
      size: {
        type: Number,
        default () {
          return 2048
        }
      },
      allowFormat: {
        type: Array,
        default () {
          return ['bmp', 'jpg', 'jpeg', 'png']
        }
      },
      disabled: {
        type: Boolean,
        default () {
          return false
        }
      }
    },
    data () {
      return {
        fileList: [],
        uploading: [],
        visible: false
      }
    },
    watch: {
      fileList (val) {
        this.$emit('input', this.returnStr ? (val.length > 0 ? val.join(',') : '') : val)
      },
      value (val) {
        this.$nextTick(() => {
          this.initFileList(val)
        })
      },
      uploading: 'handleUpload'
    },
    methods: {
      handleUpload (uploadList) {
        if (uploadList.length >= 0) {
          uploadList.forEach((file, index) => {
            if (file.status !== 'wait') {
              return
            }
            let formData = new FormData()
            formData.append('files', file.file)
            this.uploading[index].status = 'uploading'
            this.$http.post('/upload/news', formData, {
              onUploadProgress: (progressEvent) => {
                this.uploading[index].progress = Math.round((progressEvent.loaded * 100) / progressEvent.total)
              }
            }).then(res => {
              if (res.code === 0) {
                this.fileList.push(res.urls[0])
              }
              this.uploading.splice(index, 1)
            })
          })
        }
      },
      selectFile (file) {
        let el = document.getElementById('upload-file')
        let reader = new FileReader()
        if (this.checkFileNumber(el.files.length)) {
          for (let i = 0; i < el.files.length; i++) {
            let file = el.files[i]
            if (!this.checkFileSize(file)) {
              this.handleMaxSize(file)
              return false
            }
            if (!this.checkFileFormat(file)) {
              this.handleFormatError(file)
              return false
            }
            reader.readAsDataURL(file)
            reader.onload = () => {
              this.uploading.push({
                id: UUID.v1(),
                status: 'wait',
                base64: reader.result,
                file: file,
                progress: 0
              })
            }
            reader.onerror = (error) => {
              console.log('Error: ', error)
            }
          }
        }
      },
      checkFileSize (file) {
        return file.size / 1000 <= this.size
      },
      checkFileFormat (file) {
        const fileFormat = file.name.split('.').pop().toLocaleLowerCase()
        return this.allowFormat.some(item => item.toLocaleLowerCase() === fileFormat)
      },
      checkFileNumber (fileNum) {
        if (fileNum + this.fileList.length > this.max) {
          this.$Message.error(`最多上传 ${this.max} 张`)
          return false
        }
        return true
      },
      initFileList (fileListStr = null) {
        if (fileListStr) {
          this.fileList = fileListStr.split(',') || []
        } else {
          this.fileList = []
        }
      },
      handleView (url) {
        this.$store.dispatch('openPreview', url)
      },
      handleRemove (index) {
        this.$Modal.confirm({
          title: '二次确认',
          content: '该删除操作无法撤销 是否执行?',
          onOk: () => {
            this.fileList.splice(index, 1)
          }
        })
      },
      handleSuccess (url) {
        this.fileList.push(url)
      },
      handleFormatError (file) {
        this.$Notice.warning({
          title: '文件格式不正确',
          desc: '文件' + file.name + `格式不正确，请上传 ${this.allowFormat.join('、')} 格式的图片。`
        })
      },
      handleMaxSize (file) {
        this.$Notice.warning({
          title: '超出文件大小限制',
          desc: '文件 ' + file.name + ' 太大，不能超过 2M。'
        })
      }
    },
    mounted () {
      this.$nextTick(() => {
        if (this.value && this.returnStr) {
          this.initFileList(this.value)
        }
      })
    }
  }
</script>
