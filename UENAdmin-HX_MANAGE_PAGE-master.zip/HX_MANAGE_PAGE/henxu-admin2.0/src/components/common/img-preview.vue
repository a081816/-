<template>
  <div>
    <Modal v-model="showModal" :width="800" style="z-index: 10000; position: absolute">
      <img style="width: 100%" :src="url" alt="">
      <div slot="footer">
        <Button type="success" size="large" long @click="showModal = false">关闭</Button>
      </div>
    </Modal>
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
</style>
<script type="text/ecmascript-6">
  export default{
    props: [
      'value',
      'url'
    ],
    data () {
      return {
        showModal: this.value
      }
    },
    watch: {
      showModal (val) {
        if (!val) {
          this.$store.dispatch('closePreview')
        } else {
          this.$emit('input', val)
        }
      },
      value (val) {
        this.showModal = val
      }
    }
  }
</script>
