<template>
  <div class="wrapper">
    <img class="icon" src="~@/assets/Home/tree.png" alt="">
    <p class="text">全网植树量</p>
    <p class="text"><span class="number">{{this.transformRate.plantTreesPrm}}</span><span class="unit">棵</span></p>
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
  .wrapper {
    text-align: center;
    height: 219px;
    background: #a1d1a1;
    margin-bottom: 10px;
    .icon {
      margin: 0 auto;
      width: 80%;
      padding: 15px;
    }
    .text {
      font-size: 16px;
      color: white;
      .number {
        font-size: 30px;
      }
      .unit {
        font-size: 14px;
        margin-left: 5px;
        vertical-align: text-bottom;
      }
    }
  }
</style>
<script type="text/ecmascript-6">
  export default {
    props: {
      kwh: {
        type: Number,
        default () {
          return 0
        }
      },
      realValue: {
        type: Number,
        default () {
          return -1
        }
      }
    },
    data () {
      return {
        transformRate: 0
      }
    },
    computed: {
      count () {
        if (this.realValue > -1) {
          return this.realValue
        } else {
          return (this.kwh * this.transformRate).toFixed(2)
        }
      },
      user () {
        return this.$store.getters.userInfo
      }
    },
    mounted () {
      this.$http.post('homePage/energyConservation', {userId: this.$store.getters.userInfo.id}).then(res => {
        this.transformRate = res.data
      })
    }
  }
</script>
