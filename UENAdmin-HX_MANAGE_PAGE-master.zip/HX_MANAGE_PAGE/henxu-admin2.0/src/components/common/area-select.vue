<template>
  <div>
    <Select filterable v-model="provinceId" placement="bottom" placeholder="省份" style="width:150px;margin-right: 10px">
      <Option v-for="(item, index) in provinceList" :value="item.id" :key="index">{{ item.province }}</Option>
    </Select>
    <Select filterable v-model="cityId" placement="bottom" placeholder="城市" style="width:150px">
      <Option v-for="(item, index) in cityList" :value="item.id" :label="item.city"
              :key="index">{{item.city}}
      </Option>
    </Select>
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
</style>
<script type="text/ecmascript-6">
  export default{
    props: {
      initProvinceId: {
        type: [Number, String],
        default () {
          return null
        }
      },
      initCityId: {
        type: [Number, String],
        default () {
          return null
        }
      }
    },
    data () {
      return {
        provinceList: [],
        cityList: [],
        provinceId: this.initProvinceId || null,
        cityId: this.initCityId || null
      }
    },
    watch: {
      initProvinceId (val) {
        this.provinceId = val
      },
      initCityId (val) {
        this.cityId = val
      },
      provinceId (val) {
        this.$emit('on-province-update', val)
        let provinces = this.provinceList.filter((province) => {
          return province.id === val
        })
        this.$emit('on-province-update-full-value', provinces[0])
        let pid = val
        this.$http.get('/area/city/list/' + pid).then(res => {
          this.cityList = res.areaCityList
        })
      },
      cityId (val) {
        this.$emit('on-city-update', val)
        let citys = this.cityList.filter((city) => {
          return city.id === val
        })
        console.log(citys)
        this.$emit('on-city-update-full-value', citys[0])
      }
    },
    methods: {
      loadProvinceList () {
        this.$http.get('/area/province/list').then(res => {
          this.provinceList = res.areaProvinceList
          console.log(this.provinceList)
          window.sessionStorage.setItem('area', JSON.stringify(res.areaProvinceList))
        })
      }
    },
    mounted () {
      let cache = window.sessionStorage.getItem('area') || ''
      if (cache) {
        try {
          this.provinceList = JSON.parse(cache)
        } catch (e) {
          this.loadProvinceList()
        }
      } else {
        this.loadProvinceList()
      }
    }
  }
</script>
