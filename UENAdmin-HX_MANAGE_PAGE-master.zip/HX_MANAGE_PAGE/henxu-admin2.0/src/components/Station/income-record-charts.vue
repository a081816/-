<template>
  <div id="income-record-charts">
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
  .home-charts {
    width: 100%;
    height: 100%;
  }
</style>
<script type="text/ecmascript-6">
  const echarts = require('echarts')
  const theme = require('@/assets/echarts-theme.json')
  export default {
    props: {
      data: {
        type: Object,
        default () {
          return {}
        }
      }
    },
    data () {
      return {
        xArea: [],
        // 国家补贴
        sear1: [],
        // 政府补贴
        sear2: [],
        // 节省电费
        sear3: [],
        // 出售电费
        sear4: [],
        myChart: null
      }
    },
    watch: {
      data: 'initData',
      sear1: 'renderCharts',
      sear2: 'renderCharts',
      sear3: 'renderCharts',
      sear4: 'renderCharts'
    },
    methods: {
      initData (val) {
        if (val && this.data.list && this.data.list.length > 0) {
          let xArea = []
          let sear1 = []
          let sear2 = []
          let sear3 = []
          let sear4 = []
          this.data.list.forEach((column) => {
            xArea.push(`第${column.year}年`)
            sear1.push(column.countrySub)
            sear2.push(column.areaSub)
            sear3.push(column.saveTol)
            sear4.push(column.sellTol)
          })
          this.xArea = xArea
          this.sear1 = sear1
          this.sear2 = sear2
          this.sear3 = sear3
          this.sear4 = sear4
          this.renderCharts()
        } else {
          return []
        }
      },
      renderCharts () {
        echarts.registerTheme('macarons', theme)
        if (!this.myChart) {
          this.myChart = echarts.init(document.getElementById('income-record-charts'), 'macarons')
        }
        // 绘制图表
        this.myChart.setOption({
          title: {
            text: `25年总收益 ${this.data && this.data.tolMoneyOf25Year} 元`,
            textStyle: {
              color: '#8da3ca'
            }
          },
          dataZoom: {
            xAxisIndex: 0,
            filterMode: 'weakFilter'
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {            // 坐标轴指示器，坐标轴触发有效
              type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            }
          },
          legend: {
            data: ['国家补贴', '政府补贴', '节省电费', '出售电费']
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: {
            type: 'category',
            data: this.xArea
          },
          yAxis: {
            type: 'value',
            name: '元',
            axisLabel: {
              formatter: '{value}'
            }
          },
          series: [
            {
              name: '国家补贴',
              type: 'bar',
              stack: '总量',
              label: {
                normal: {
                  show: false,
                  position: 'inside'
                }
              },
              itemStyle: {
                normal: {
                  color: '#ff6465'
                }
              },
              data: this.sear1
            },
            {
              name: '政府补贴',
              type: 'bar',
              stack: '总量',
              label: {
                normal: {
                  show: false,
                  position: 'inside'
                }
              },
              itemStyle: {
                normal: {
                  color: '#8da3ca'
                }
              },
              data: this.sear2
            },
            {
              name: '节省电费',
              type: 'bar',
              stack: '总量',
              label: {
                normal: {
                  show: false,
                  position: 'inside'
                }
              },
              itemStyle: {
                normal: {
                  color: '#a1d1a1'
                }
              },
              data: this.sear3
            },
            {
              name: '出售电费',
              type: 'bar',
              stack: '总量',
              label: {
                normal: {
                  show: false,
                  position: 'inside'
                }
              },
              itemStyle: {
                normal: {
                  color: '#facd66'
                }
              },
              data: this.sear4
            }
          ]
        })
      }
    },
    mounted () {
      this.$nextTick(() => {
        this.initData(this.data)
      })
    }
  }
</script>
