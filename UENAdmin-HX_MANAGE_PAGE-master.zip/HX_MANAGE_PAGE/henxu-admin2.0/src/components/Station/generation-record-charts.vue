<template>
  <div id="generation-record-charts">
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
  .home-charts {
    width: 100%;
    height: 100%;
  }
</style>
<script type="text/ecmascript-6">
  const echarts = require('echarts')
  const theme = require('@/assets/echarts-theme.json')
  export default{
    props: {
      dataList: {
        default () {
          return []
        }
      }
    },
    data () {
      return {
        xArea: [],
        realKwh: [],
        myChart: null,
        stationId: null
      }
    },
    watch: {
      dataList: 'initData',
      xArea: 'renderCharts',
      realKwh: 'renderCharts'
    },
    methods: {
      initData (val) {
        if (val && this.dataList) {
          let xArea = []
          let realKwh = []
          this.dataList.forEach((column) => {
            xArea.push(column.recordTime)
            realKwh.push(column.kwh)
          })
          this.xArea = xArea
          this.realKwh = realKwh
          this.renderCharts()
        } else {
          return []
        }
      },
      renderCharts () {
        echarts.registerTheme('macarons', theme)
        if (!this.myChart) {
          this.myChart = echarts.init(document.getElementById('generation-record-charts'), 'macarons')
        }
        // 绘制图表
        this.myChart.setOption({
          dataZoom: {
            xAxisIndex: 0,
            filterMode: 'weakFilter'
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'line'
            }
          },
          toolbox: {
            feature: {
              dataView: {show: true, readOnly: false},
              magicType: {show: true, type: ['line', 'bar']},
              restore: {show: true},
              saveAsImage: {show: true}
            }
          },
          legend: {
            data: ['实际发电量']
          },
          xAxis: [
            {
              type: 'category',
              data: this.xArea,
              name: '时间',
              axisPointer: {
                type: 'shadow'
              }
            }
          ],
          yAxis: [
            {
              type: 'value',
              name: '发电量(kwh)',
              min: 0,
              axisLabel: {
                formatter: '{value} kwh'
              }
            }
          ],
          series: [
            {
              name: '实际发电量',
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#9ed39f'
                }
              },
              data: this.realKwh
            }
          ]
        }, true)
        // 作用域 this 取不到 用ES6的建投函数可以避免这个问题
        this.myChart.on('click', (params) => {
          this.$emit('on-click', {stationCode: this.$route.query.stationCode, elecType: '1', date: params.name})
        })
      }
    },
    mounted () {
      this.$nextTick(() => {
        this.initData(this.dataList)
      })
    }
  }
</script>
