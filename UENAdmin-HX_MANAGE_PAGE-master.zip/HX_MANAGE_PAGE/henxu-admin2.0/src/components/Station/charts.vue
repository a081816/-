<template>
  <div id="home-charts">
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
  .home-charts {
    width: 100%;
    height: 100%;
  }
</style>
<script type="text/ecmascript-6">
  const echarts = require('echarts')
  const theme = require('@/assets/echarts-theme.json')
  export default{
    data () {
      return {}
    },
    methods: {},
    mounted () {
      echarts.registerTheme('macarons', theme)
      let myChart = echarts.init(document.getElementById('home-charts'), 'macarons')
      // 绘制图表
      myChart.setOption({
        dataZoom: {
          xAxisIndex: 0,
          filterMode: 'weakFilter'
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            crossStyle: {
              color: '#999'
            }
          }
        },
        toolbox: {
          feature: {
            dataView: {show: true, readOnly: false},
            magicType: {show: true, type: ['line', 'bar']},
            restore: {show: true},
            saveAsImage: {show: true}
          }
        },
        legend: {
          data: ['蒸发量', '降水量', '平均温度']
        },
        xAxis: [
          {
            type: 'category',
            data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
            axisPointer: {
              type: 'shadow'
            }
          }
        ],
        yAxis: [
          {
            type: 'value',
            name: 'kwh',
            min: 0,
            max: 250,
            interval: 50,
            axisLabel: {
              formatter: '{value} kwh'
            }
          }
        ],
        series: [
          {
            name: '实际发电量',
            type: 'bar',
            itemStyle: {
              normal: {
                color: '#9ed39f'
              }
            },
            data: [2.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3]
          },
          {
            name: '计划发电量',
            type: 'line',
            itemStyle: {
              normal: {
                color: '#ff5b57'
              }
            },
            lineStyle: {
              normal: {
                color: '#ff5b57'
              }
            },
//            yAxisIndex: 1,
            data: [10.0, 20.2, 30.3, 40.5, 60.3, 100.2, 200.3, 230.4, 230.0, 160.5, 120.0, 60.2]
          }
        ]
      })
    }
  }
</script>
