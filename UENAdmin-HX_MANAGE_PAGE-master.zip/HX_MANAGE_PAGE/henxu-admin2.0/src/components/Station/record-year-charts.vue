<template>
  <div id="generation-record-charts">
  </div>
</template>
<style scoped lang="less" rel="stylesheet/less">
  .home-charts {
    width: 100%;
    height: 100%;
  }
</style>
<script type="text/ecmascript-6">
  const echarts = require('echarts')
  const theme = require('@/assets/echarts-theme.json')
  export default{
    props: {
      dataList: {
        default () {
          return []
        }
      }
    },
    data () {
      return {
        xArea: [],
        realKwh: [],
        myChart: null,
        stationId: null
      }
    },
    watch: {
      dataList: 'initData',
      xArea: 'renderCharts',
      realKwh: 'renderCharts',
      wantKwh: 'renderCharts'
    },
    methods: {
      initData (val) {
        if (val && this.dataList.list) {
          let xArea = []
          let realKwh = []
          this.dataList.list.forEach((column) => {
            xArea.push(column.createDtm)
            realKwh.push(column.kwh)
          })
          this.xArea = xArea
          this.realKwh = realKwh
          this.renderCharts()
        } else {
          return []
        }
      },
      renderCharts () {
        echarts.registerTheme('macarons', theme)
        if (!this.myChart) {
          this.myChart = echarts.init(document.getElementById('generation-record-charts'), 'macarons')
        }
        // 绘制图表
        this.myChart.setOption({
          dataZoom: {
            xAxisIndex: 0,
            filterMode: 'weakFilter'
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'cross',
              crossStyle: {
                color: '#999'
              }
            }
          },
          legend: {
            data: ['实际发电量']
          },
          xAxis: [
            {
              type: 'category',
              data: this.xArea,
              axisPointer: {
                type: 'shadow'
              }
            }
          ],
          yAxis: [
            {
              type: 'value',
              name: 'kwh',
              min: 0,
              axisLabel: {
                formatter: '{value} kwh'
              }
            }
          ],
          series: [
            {
              name: '实际发电量',
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#9ed39f'
                }
              },
              data: this.realKwh
            }
          ]
        })
      }
    },
    mounted () {
      this.$nextTick(() => {
        this.initData(this.dataList)
      })
    }
  }
</script>
