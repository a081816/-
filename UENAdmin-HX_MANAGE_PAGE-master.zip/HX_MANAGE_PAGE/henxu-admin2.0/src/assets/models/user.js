/**
 * Created by Deboy on 2017/7/5.
 */
export default [
  {
    displayField: 'id',
    edit: true,
    field: 'id',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: 'ID',
    vue: {
      columnWidth: 50
    },
    xtype: 'text'
  },
  {
    displayField: 'userName',
    edit: true,
    field: 'userName',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '用户名',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'phone',
    edit: true,
    field: 'phone',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '手机号',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  },
  /* {
    displayField: 'sex',
    edit: true,
    field: 'sex',
    filter: {
      '0': '未知',
      '1': '男',
      '2': '女'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '性别',
    vue: {
      columnWidth: 80
    },
    xtype: 'text'
  }, */ {
    displayField: 'fullAddressText',
    edit: true,
    field: 'fullAddressText',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '联系地址',
    vue: {
      columnWidth: 300
    },
    xtype: 'text'
  }, {
    displayField: 'email',
    edit: true,
    field: 'email',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '邮箱',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  }, {
    displayField: 'privilegeCodeInit',
    edit: true,
    field: 'privilegeCodeInit',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '优惠码',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  }, {
    displayField: 'privilegeCode',
    edit: true,
    field: 'privilegeCode',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '使用优惠码',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  }, {
    displayField: 'createDtm',
    edit: true,
    field: 'createDtm',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '注册时间',
    vue: {
      columnWidth: 250
    },
    xtype: 'text'
  }
]
