/**
 * Created by Deboy on 2017/7/5.
 */
export default [
  {
    displayField: 'tradeNo',
    edit: true,
    field: 'tradeNo',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '退款单号',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  },
  {
    displayField: 'realName',
    edit: true,
    field: 'realName',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '持卡人',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'money',
    edit: true,
    field: 'money',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '退款金额',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'bankCardNum',
    edit: true,
    field: 'bankCardNum',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '银行卡号',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'bankName',
    edit: true,
    field: 'bankName',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '银行支行',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  }, {
    displayField: 'applyDtm',
    edit: true,
    field: 'applyDtm',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '申请时间',
    vue: {
      columnWidth: 200
    },
    xtype: 'text'
  }, {
    displayField: 'status',
    edit: true,
    field: 'status',
    filter: {
      '0': '申请中',
      '1': '退款成功',
      '2': '退款失败'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '退款状态',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'remark',
    edit: true,
    field: 'remark',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '备注',
    vue: {
      columnWidth: 200
    },
    xtype: 'text'
  }
]
