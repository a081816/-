/**
 * Created by Deboy on 2017/7/5.
 */
export default [
  {
    displayField: 'tradeNo',
    edit: true,
    field: 'tradeNo',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '支付单号',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  },
  {
    displayField: 'money',
    edit: true,
    field: 'money',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '支付金额',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'user.userName',
    edit: true,
    field: 'userName',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '用户名',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'createDtm',
    edit: true,
    field: 'createDtm',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '支付时间',
    vue: {
      columnWidth: 200
    },
    xtype: 'text'
  },
  {
    displayField: 'status',
    edit: true,
    field: 'status',
    filter: {
      '0': '支付成功',
      '1': '支付失败'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '支付状态',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'remark',
    edit: true,
    field: 'remark',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '备注',
    vue: {
      columnWidth: 200
    },
    xtype: 'text'
  }
]
