/**
 * Created by Deboy on 2017/7/5.
 */
export default [
  {
    displayField: 'id',
    edit: true,
    field: 'id',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '电站ID',
    vue: {
      columnWidth: 80
    },
    xtype: 'text'
  },
  {
    displayField: 'ammeterCode',
    edit: true,
    field: 'ammeterCode',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '电站码',
    vue: {
      columnWidth: 80
    },
    xtype: 'text'
  },
  {
    displayField: 'devConfCode',
    edit: true,
    field: 'devConfCode',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '回路地址',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  },
  {
    displayField: 'kwh',
    edit: true,
    field: 'kwh',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '每日发电量kwh',
    vue: {
      columnWidth: 250
    },
    xtype: 'text'
  },
  {
    displayField: 'createDtm',
    edit: true,
    field: 'createDtm',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '创建时间',
    vue: {
      columnWidth: 200
    },
    xtype: 'datetime'
  }
]
