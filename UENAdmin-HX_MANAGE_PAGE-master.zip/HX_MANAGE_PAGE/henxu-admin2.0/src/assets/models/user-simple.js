/**
 * Created by Deboy on 2017/7/5.
 */
export default [
  {
    displayField: 'id',
    edit: true,
    field: 'id',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: 'id',
    vue: {
      columnWidth: 50
    },
    xtype: 'text'
  },
  {
    displayField: 'nickName',
    edit: true,
    field: 'nickName',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '昵称',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  },
  {
    displayField: 'userName',
    edit: true,
    field: 'userName',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '用户名',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'phone',
    edit: true,
    field: 'phone',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '手机号码',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  },
  {
    displayField: 'sex',
    edit: true,
    field: 'sex',
    filter: {
      '0': '未知',
      '1': '男',
      '2': '女'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '性别',
    vue: {
      columnWidth: 80
    },
    xtype: 'text'
  }, {
    displayField: 'createDtm',
    edit: true,
    field: 'createDtm',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '注册时间',
    vue: {
      columnWidth: 250
    },
    xtype: 'text'
  }
]
