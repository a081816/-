/**
 * Created by Deboy on 2017/7/5.
 */
export default [
  {
    displayField: 'orderCode',
    edit: true,
    field: 'text',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '订单号',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  },
  {
    displayField: 'user.userName',
    edit: true,
    field: 'text',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '用户名',
    vue: {
      columnWidth: 100
    },
    xtype: 'text'
  },
  {
    displayField: 'addressText',
    edit: true,
    field: 'text',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '所在地点',
    vue: {
      columnWidth: 250
    },
    xtype: 'text'
  },
  {
    displayField: 'status',
    edit: true,
    field: 'text',
    filter: {
      '0': '申请中',
      '1': '施工中',
      '2': '并网发电'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '订单状态',
    vue: {
      columnWidth: 120
    },
    xtype: 'select'
  },
  {
    displayField: 'isPay',
    edit: true,
    field: 'isPay',
    filter: {
      '0': '未支付',
      '1': '已支付'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: true,
    title: '支付状态',
    vue: {
      columnWidth: 120
    },
    customRender: (h, row) => {
      let data = row.row
      let label = ''
      switch (data.status) {
        case 0:
          label = data.applyIsPay ? '已支付' : '未支付'
          break
        case 1:
          label = data.buildIsPay ? '已支付' : '未支付'
          break
        case 2:
          label = data.gridConnectedIsPay ? '已支付' : '未支付'
          break
      }
      return h('span', {}, label)
    },
    xtype: 'custom'
  },
  {
    displayField: 'totalPrice',
    edit: true,
    field: 'totalPrice',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: true,
    title: '订单总额',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'factoragePrice',
    edit: true,
    field: 'factoragePrice',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: true,
    title: '优能服务费',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  }
  // {
  //   displayField: 'id',
  //   edit: true,
  //   field: 'text',
  //   filter: null,
  //   isShow: true,
  //   relTable: null,
  //   required: true,
  //   sort: true,
  //   title: '利润金额',
  //   vue: {
  //     columnWidth: 120
  //   },
  //   xtype: 'text'
  // }
]
