/**
 * Created by Deboy on 2017/7/5.
 */
export default [
  {
    displayField: 'id',
    edit: true,
    field: 'text',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '序号',
    vue: {
      columnWidth: 80
    },
    xtype: 'text'
  },
  {
    displayField: 'author',
    edit: true,
    field: 'author',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '作者',
    vue: {
      columnWidth: 100
    },
    xtype: 'text'
  },
  {
    displayField: 'browseCount',
    edit: true,
    field: 'browseCount',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '浏览数',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'clientId',
    edit: true,
    field: 'clientId',
    filter: {
      '0': '手机设备',
      '1': '电脑设备'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '使用设备',
    vue: {
      columnWidth: 150
    },
    xtype: 'select'
  },
  {
    displayField: 'content',
    edit: true,
    field: 'content',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '内容',
    vue: {
      columnWidth: 250
    },
    xtype: 'html'
  },
  {
    displayField: 'imgUrl',
    edit: true,
    field: 'imgUrl',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '图片地址',
    vue: {
      columnWidth: 200
    },
    xtype: 'img'
  },
  {
    displayField: 'title',
    edit: true,
    field: 'title',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '标题',
    vue: {
      columnWidth: 200
    },
    xtype: 'img'
  },
  {
    displayField: 'type',
    edit: true,
    field: 'type',
    filter: {
      '0': '资讯',
      '1': '动态',
      '2': '视频',
      '3': '服务商公告'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '类型',
    vue: {
      columnWidth: 200
    },
    xtype: 'img'
  },
  {
    displayField: '视频地址',
    edit: true,
    field: 'type',
    filter: {
      '0': '资讯',
      '1': '动态',
      '2': '视频',
      '3': '服务商公告'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '类型',
    vue: {
      columnWidth: 200
    },
    xtype: 'video'
  },
  {
    displayField: '操作',
    edit: true,
    field: 'type',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '类型',
    vue: {
      columnWidth: 200
    },
    customRender: (h, row) => {
    },
    xtype: 'custom'
  }
]
