/**
 * Created by Deboy on 2017/7/5.
 */
export default [
  {
    displayField: 'stationCode',
    edit: true,
    field: 'stationCode',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '发生时间',
    vue: {
      columnWidth: 80
    },
    xtype: 'text'
  },
  {
    displayField: 'dAddr',
    edit: true,
    field: 'dAddr',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '故障原因',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  },
  {
    displayField: 'dType',
    edit: true,
    field: 'dType',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '持续时间(分)',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  }
]
