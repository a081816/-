/**
 * Created by Deboy on 2017/7/5.
 */
export default [
  {
    displayField: 'id',
    edit: true,
    field: 'id',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '省市',
    vue: {
      columnWidth: 250
    },
    customRender (h, row) {
      return h('span', {}, row.row.provinceText + row.row.cityText)
    },
    xtype: 'custom'
  },
  {
    displayField: 'type',
    edit: true,
    field: 'type',
    filter: {
      '1': '居民',
      '2': '工业',
      '3': '商业',
      '4': '农业'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '类型',
    vue: {
      columnWidth: 100
    },
    xtype: 'text'
  },
  {
    displayField: 'sunCount',
    edit: true,
    field: 'sunCount',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '城市日照量',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  },
  {
    displayField: 'usePrice',
    edit: true,
    field: 'usePrice',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '用电价格',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'sellPrice',
    edit: true,
    field: 'sellPrice',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '售电价格',
    vue: {
      columnWidth: 100
    },
    xtype: 'text'
  }, {
    displayField: 'sellProportion',
    edit: true,
    field: 'sellProportion',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '出售电量比',
    vue: {
      columnWidth: 100
    },
    customRender (h, row) {
      return h('span', {}, row.row.sellProportion * 100 + '%')
    },
    xtype: 'custom'
  }
]
