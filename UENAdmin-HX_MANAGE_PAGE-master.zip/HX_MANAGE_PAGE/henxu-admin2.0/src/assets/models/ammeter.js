/**
 * Created by Deboy on 2017/7/5.
 */
export default [
  {
    displayField: 'id',
    edit: true,
    field: 'text',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '序号',
    vue: {
      columnWidth: 80
    },
    xtype: 'text'
  },
  {
    displayField: 'station.stationName',
    edit: true,
    field: 'stationId',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '已绑定电站',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  },
  {
    displayField: 'cAddr',
    edit: true,
    field: 'cAddr',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '采集器码',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'cityText&provinceText',
    edit: true,
    field: 'cityId',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '所在地',
    vue: {
      columnWidth: 150
    },
    xtype: 'custom',
    customRender: (h, column) => {
      return h('span', {}, column.row.provinceText + column.row.cityText)
    }
  },
  {
    displayField: 'addressText',
    edit: true,
    field: 'addressText',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '详细地址',
    vue: {
      columnWidth: 250
    },
    xtype: 'text'
  },
  {
    displayField: 'outfactoryDtm',
    edit: true,
    field: 'outfactoryDtm',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '出厂日期',
    vue: {
      columnWidth: 200
    },
    xtype: 'datetime'
  }
]
