/**
 * Created by Deboy on 2017/7/5.
 */
export default [
  {
    displayField: 'id',
    edit: true,
    field: 'id',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '序号',
    vue: {
      columnWidth: 80
    },
    xtype: 'text'
  },
  {
    displayField: 'companyName',
    edit: true,
    field: 'companyName',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '服务商名称',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'personInCharge',
    edit: true,
    field: 'personInCharge',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '项目负责人',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  },
  {
    displayField: 'salesmanPhone',
    edit: true,
    field: 'salesmanPhone',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '业务员电话',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  },
  {
    displayField: 'tolCapacityOfYn',
    edit: true,
    field: 'tolCapacityOfYn',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: true,
    title: '累积光伏装机容量',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  }, {
    displayField: 'canWithstand',
    edit: true,
    field: 'canWithstand',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: true,
    title: '能承接规模',
    vue: {
      columnWidth: 300
    },
    xtype: 'text'
  }, {
    displayField: 'companyAssets',
    edit: true,
    field: 'companyAssets',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: true,
    title: '注册资本',
    vue: {
      columnWidth: 250
    },
    xtype: 'text'
  }, {
    displayField: 'registeredDtm',
    edit: true,
    field: 'registeredDtm',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: true,
    title: '注册时间',
    vue: {
      columnWidth: 250
    },
    xtype: 'text'
  }, {
    displayField: 'type',
    edit: true,
    field: 'type',
    filter: {
      '0': '未认证',
      '1': '已认证'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '认证状态',
    vue: {
      columnWidth: 140
    },
    xtype: 'text'
  }
]
