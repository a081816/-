/**
 * Created by Deboy on 2017/7/5.
 */
export default [
  {
    displayField: 'tradeNo',
    edit: true,
    field: 'tradeNo',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '充值单号',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  },
  {
    displayField: 'user.userName',
    edit: true,
    field: 'userName',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '用户名',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  }, {
    displayField: 'status',
    edit: true,
    field: 'status',
    filter: {
      '0': '充值成功',
      '1': '充值失败'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '充值状态',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  }, {
    displayField: 'payWay',
    edit: true,
    field: 'payWay',
    filter: {
      '2': '微信',
      '3': '支付宝',
      '4': '银联',
      '5': '快付通'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '支付方式',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  }, {
    displayField: 'money',
    edit: true,
    field: 'money',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: true,
    title: '充值金额',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  }, {
    displayField: 'createDtm',
    edit: true,
    field: 'createDtm',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '交易时间',
    vue: {
      columnWidth: 200
    },
    xtype: 'text'
  },
  {
    displayField: 'remark',
    edit: true,
    field: 'remark',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '备注',
    vue: {
      columnWidth: 200
    },
    xtype: 'text'
  }
]
