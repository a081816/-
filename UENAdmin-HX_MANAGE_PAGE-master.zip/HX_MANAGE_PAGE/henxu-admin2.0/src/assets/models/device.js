/**
 * Created by Deboy on 2017/7/5.
 */
export default [
  {
    displayField: 'id',
    edit: true,
    field: 'text',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '序号',
    vue: {
      columnWidth: 80
    },
    xtype: 'text'
  },
  {
    displayField: 'brandName',
    edit: true,
    field: 'brandName',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '设备品牌',
    vue: {
      columnWidth: 100
    },
    xtype: 'text'
  },
  {
    displayField: 'model',
    edit: true,
    field: 'model',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '设备型号',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'type',
    edit: true,
    field: 'type',
    filter: {
      '1': '电池板',
      '3': '逆变器',
      '2': '其他材料'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '类型',
    vue: {
      columnWidth: 200
    },
    xtype: 'select'
  }
]
