/**
 * Created by Deboy on 2017/7/5.
 */
export default [
  {
    displayField: 'id',
    edit: true,
    field: 'text',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: 'ID',
    vue: {
      columnWidth: 50
    },
    xtype: 'text'
  },
  {
    displayField: 'stationCode',
    edit: true,
    field: 'stationCode',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '电站码',
    vue: {
      columnWidth: 140
    },
    xtype: 'text'
  },
  {
    displayField: 'stationName',
    edit: true,
    field: 'stationName',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '电站名',
    vue: {
      columnWidth: 100
    },
    xtype: 'text'
  },
  {
    displayField: 'type',
    edit: true,
    field: 'type',
    filter: {
      '1': '居民',
      '2': '工业',
      '3': '商业',
      '4': '农业'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '电站类型',
    vue: {
      columnWidth: 100
    },
    xtype: 'text'
  },
  {
    displayField: 'linkMan',
    edit: true,
    field: 'linkMan',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '联系人',
    vue: {
      columnWidth: 100
    },
    xtype: 'text'
  },
  {
    displayField: 'linkPhone',
    edit: true,
    field: 'linkPhone',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '联系电话',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'cityText',
    edit: true,
    field: 'cityText',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '城市',
    vue: {
      columnWidth: 80
    },
    xtype: 'text'
  },
  {
    displayField: 'capacity',
    edit: true,
    field: 'capacity',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: true,
    title: '装机容量',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'status',
    edit: true,
    field: 'status',
    filter: {
      '0': '未绑定电表',
      '1': '正在发电',
      '2': '电表异常'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '电站状态',
    vue: {
      columnWidth: 90
    },
    xtype: 'text'
  },
  {
    displayField: 'server.companyName',
    edit: true,
    field: 'server_id',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '服务商',
    vue: {
      columnWidth: 80
    },
    xtype: 'text'
  }
]
