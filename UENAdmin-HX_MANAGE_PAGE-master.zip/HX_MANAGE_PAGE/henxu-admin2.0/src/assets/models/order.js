/**
 * Created by Deboy on 2017/7/5.
 */
export default [
  {
    displayField: 'id',
    edit: true,
    field: 'id',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: 'ID',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  },
  {
    displayField: 'orderCode',
    edit: true,
    field: 'text',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '订单号',
    vue: {
      columnWidth: 150
    },
    xtype: 'text'
  },
  {
    displayField: 'linkMan',
    edit: true,
    field: 'linkMan',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '联系人',
    vue: {
      columnWidth: 100
    },
    xtype: 'text'
  },
  {
    displayField: 'linkPhone',
    edit: true,
    field: 'linkPhone',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '联系人手机号',
    vue: {
      columnWidth: 100
    },
    xtype: 'text'
  },
  {
    displayField: 'capacity',
    edit: true,
    field: 'capacity',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: true,
    title: '装机容量',
    vue: {
      columnWidth: 250
    },
    xtype: 'text'
  },
  {
    displayField: 'status',
    edit: true,
    field: 'text',
    filter: {
      '0': '申请中',
      '1': '施工中',
      '2': '并网发电'
    },
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '订单状态',
    vue: {
      columnWidth: 120
    },
    xtype: 'select'
  },
  {
    displayField: 'serverName',
    edit: true,
    field: 'serverName',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '服务商',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'totalPrice',
    edit: true,
    field: 'totalPrice',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: true,
    title: '订单金额',
    vue: {
      columnWidth: 120
    },
    xtype: 'text'
  },
  {
    displayField: 'createDtm',
    edit: true,
    field: 'createDtm',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: true,
    title: '下单时间',
    vue: {
      columnWidth: 90
    },
    xtype: 'date'
  },
  {
    displayField: 'privilegeCode',
    edit: true,
    field: 'privilegeCode',
    filter: null,
    isShow: true,
    relTable: null,
    required: true,
    sort: false,
    title: '使用优惠码',
    vue: {
      columnWidth: 90
    },
    xtype: 'date'
  }
]
